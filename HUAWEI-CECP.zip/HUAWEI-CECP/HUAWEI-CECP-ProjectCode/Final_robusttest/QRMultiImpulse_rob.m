function [capacityMulti,timePrecoder,capacityMultiImperfect,chanEstNMSEMulti_rob,NMSEMultiImpulseTimeDenoise_rob,multiEstChan,multiRealChan] = QRMultiImpulse_rob(HtimeToep,HtimeToepImperfect,Hfreq,HfreqImperfect,totalL,SysPara,sch_tag)
%UNTITLED5 此处显示有关此函数的摘要
%   此处显示详细说明
global  Rx subcarriersK SNR P pointSeq Hdesired Qzf
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
weightLen = SysPara.weightLen; % ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 minimum FIR Length
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio
channEstError=SysPara.channEstError;


Hdesired = cell(P,1);
Qzf = cell(P,1);
timePrecoder = zeros(weightLen * Tx, P*Nds);
centerPoint = ceil((weightLen + tapsN-1)/2); % Find the central Impulse Point
if totalL == 1
    leftPoint = 0;
    rightPoint = 0;
else
    leftPoint = floor((totalL-1)/2);
    rightPoint = ceil((totalL-1)/2);
end
pointSeq = [centerPoint - leftPoint:centerPoint + rightPoint]; % Multiple Responses Reservation Set

% [Q,R] = qr(HtimeToep'); % T^H = QR
% R1 = R(1:Rx*P*(weightLen + tapsN-1),:); % Squeeze Operation

[R] = generalized_blockQR(HtimeToep,weightLen,Rx*P);
% tmp = HtimeToep'/ R1 * inv(R1)'; % Eq.16

si=size(R,1);
nonezerospace=tapsN/(weightLen+tapsN-1);
% a = sum(channEstError)*Rx;
% a=SNR;
a = sum(channEstError)/subcarriersK*tapsN*Tx;
tmp = HtimeToep'*inv(R'*R+a*eye(si)); 
% d=diag(inv(R'*R));

% inv(R1'*R1);
for uu = 1:P
    % Rnew = R;
    Hdesireduu = [];
    counter = [];
    for nn = 1:length(pointSeq)
        Hdesireduu = [Hdesireduu;HtimeToep((pointSeq(nn)-1)*Rx*P + 1 + (uu-1)*Rx : (pointSeq(nn)-1)*Rx*P + uu*Rx,:)]; % Extract Desired Channels
        counter = [counter,(pointSeq(nn)-1)*Rx*P + 1 + (uu-1)*Rx : (pointSeq(nn)-1)*Rx*P + uu*Rx]; % Record The Index
    end
    Qzfuu = tmp(:, counter);
    % ExtractionTemp = Rnew(:, counter); % Extract Operation
    % Rnew(:, counter) = []; % Extract Operation
    % Rnew = [Rnew,ExtractionTemp]; % Shift Operation
    % [Q2,~] = qr(Rnew);
    % Qzfuu = Q1*Q2(:,end-length(pointSeq)*Rx+1:end);

    Hdesired{uu} = Hdesireduu;
    Qzf{uu} = Qzfuu;
end




%% Manifold Optimization for maximizing channel capacity
Tinitial = randn(length(pointSeq)*Rx*P,Nds) + 1j*randn(length(pointSeq)*Rx*P,Nds);
Tinitial = Tinitial/norm(Tinitial,'fro');
[capacityManifoldCGMethod,T] = MFGradDesMulti(Tinitial,SysPara);
capacityMulti = capacityManifoldCGMethod(end);
%% Return Time Precoder
impulseShape=cell(2,1);
for uu = 1:P
    timePrecoder(:,(uu-1)*Nds + [1:Nds]) = Qzf{uu} * ((Qzf{uu}'*Qzf{uu})^(-1/2))*T((uu-1)*length(pointSeq)*Rx + [1:length(pointSeq)*Rx],:);
    impulseShape{uu} = HtimeToepImperfect * Qzf{uu}*((Qzf{uu}'*Qzf{uu})^(-1/2))* T((uu-1)*length(pointSeq)*Rx + [1:length(pointSeq)*Rx],:);

end
% for uu = 1:P
%     timePrecoder(:,(uu-1)*Nds + [1:Nds]) = Qzf{uu} * T((uu-1)*length(pointSeq)*Rx + [1:length(pointSeq)*Rx],:);
%     impulseShape{uu} = HtimeToepImperfect * Qzf{uu} * T((uu-1)*length(pointSeq)*Rx + [1:length(pointSeq)*Rx],:);
% end

%% DMRS
[chanEstNMSEMulti_rob,NMSEMultiImpulseTimeDenoise_rob,multiEstChan,multiRealChan] = lsChannelMultiImpulse(SysPara,impulseShape,pointSeq,totalL);

%% channel shift
F = dftmtx(subcarriersK);
Hfreqshift=cell(P,subcarriersK,P);
for ll=1:P
    for uu = 1:P
        extractImpulseuu = [];
        for nn = 1:length(pointSeq)
            extractImpulseuu = [extractImpulseuu;impulseShape{ll}((pointSeq(nn)-1)*Rx*P + 1 + (uu-1)*Rx : (pointSeq(nn)-1)*Rx*P + uu*Rx,:)]; % Extract Desired Channels
        end
        extractImpulseuutail = [];
        for mm = pointSeq(end)+1:weightLen + tapsN -1
            extractImpulseuutail = [extractImpulseuutail;impulseShape{ll}((mm-1)*Rx*P + 1 + (uu-1)*Rx : (mm-1)*Rx*P + uu*Rx,:)];
        end
        extractImpulseuuhead = [];
        for bb = 1:pointSeq(1) -1
            extractImpulseuuhead = [extractImpulseuuhead;impulseShape{ll}((bb-1)*Rx*P + 1 + (uu-1)*Rx : (bb-1)*Rx*P + uu*Rx,:)];
        end
        shiftedEffcChan = [extractImpulseuu;extractImpulseuutail;extractImpulseuuhead];
        for kk = 1:subcarriersK
            Fbar = kron(F(kk,1:weightLen + tapsN -1),eye(Rx));
            Hfreqshift{uu,kk,ll} = Fbar * shiftedEffcChan;
        end
    end
end

%% 频域预编码
fre_precoder=zeros(Tx,P*Nds,subcarriersK);
tptemp=zeros(Tx,Nds,weightLen);
eqchannel_energy=zeros(P,subcarriersK);
for uu=1:P
    TPtemp=timePrecoder(:,(uu-1)*Nds+[1:Nds]);
    for ii = 1:weightLen
        tptemp(:,:,ii)=TPtemp((ii-1)*Tx+[1:Tx],:);
    end
    %fft
    for ii = 1:Tx
        for jj = 1:Nds
            fre_precoder(ii,(uu-1)*Nds+jj,:) = fft(tptemp(ii,jj,:),subcarriersK);
        end
    end
end

for kk=1:subcarriersK
        energyprecoder(kk)=norm(fre_precoder(:,:,kk),'fro');
end

for kk=1:subcarriersK
    for uu=1:P
        channeluukk=squeeze(Hfreq((uu-1)*Nds+(1:Nds),:,kk));
        precoderuukk=squeeze(fre_precoder(:,(uu-1)*Nds+(1:Nds),kk));
        eqchanneluukk=channeluukk*precoderuukk;
        eqchannel_energy(uu,kk)=trace(eqchanneluukk*eqchanneluukk');
    end
end
eqtimechannel=HtimeToep* timePrecoder;
for uu=1:P
    for ll=1:weightLen+tapsN-1
    Tchanneluukk(uu,ll)=trace(eqtimechannel((ll-1)*Rx*P+(uu-1)*Rx+[1:Rx],(uu-1)*Nds+[1:Nds])*eqtimechannel((ll-1)*Rx*P+(uu-1)*Rx+[1:Rx],(uu-1)*Nds+[1:Nds])');
    end
end


%% real channel
capacityMulti = 0;

for kk=1:subcarriersK
    for uu=1:P
        Ruukk=zeros(Nds,Nds);
        % channeluukk=squeeze(HfreqImperfect((uu-1)*Nds+(1:Nds),:,kk));
        % precoderuukk=squeeze(fre_precoder(:,(uu-1)*Nds+(1:Nds),kk));
        % eqchanneluukk=channeluukk*precoderuukk;

        eqchanneluukk = multiRealChan{uu,kk};
        % eqchanneluukk = channeluukk*precoderuukk;

        combineruukk=inv(eqchanneluukk'*eqchanneluukk+SNR*eye(Nds))*eqchanneluukk';
        eqsignaluukk=combineruukk*eqchanneluukk;
        %         eqsignaluukk=channeluukk*precoderuukk;
        combinertemp=combineruukk*combineruukk';
        for ll = 1:P
            % precoderllkk = squeeze(fre_precoder(:,(ll-1)*Nds + [1:Nds],kk));
            % Ruukk = Ruukk + combineruukk*channeluukk*precoderllkk*precoderllkk'*channeluukk'*combineruukk';

            eqchannelllkk=Hfreqshift{uu,kk,ll};
            Ruukk = Ruukk + combineruukk* eqchannelllkk* eqchannelllkk'*combineruukk';
        end
        Ruukk = Ruukk+SNR*combinertemp-eqsignaluukk*eqsignaluukk';

        capacityMulti=capacityMulti+real(log2(det( eye(Nds) + eqsignaluukk'*inv(Ruukk)*eqsignaluukk )));

    end
end
%% est Channel
capacityMultiImperfect = 0;

for kk=1:subcarriersK
    for uu=1:P
        Ruukk=zeros(Nds,Nds);
        channeluukk=squeeze(HfreqImperfect((uu-1)*Nds+(1:Nds),:,kk));
        precoderuukk=squeeze(fre_precoder(:,(uu-1)*Nds+(1:Nds),kk));

        eqchanneluukk_real = multiRealChan{uu,kk};
        eqchanneluukk_est=squeeze(multiEstChan(uu,kk,:,:));

        % eqchanneluukk_real = channeluukk*precoderuukk;
        % eqchanneluukk_est=eqchanneluukk_real;
        combineruukk=inv(eqchanneluukk_est'*eqchanneluukk_est+SNR*eye(Nds))*eqchanneluukk_est';
        eqsignaluukk=combineruukk*eqchanneluukk_real;
        combinertemp=combineruukk*combineruukk';
        for ll = 1:P
            % precoderllkk = squeeze(fre_precoder(:,(ll-1)*Nds + [1:Nds],kk));
            % Ruukk = Ruukk + combineruukk*channeluukk*precoderllkk*precoderllkk'*channeluukk'*combineruukk';

            eqchannelllkk=Hfreqshift{uu,kk,ll};
            Ruukk = Ruukk + combineruukk* eqchannelllkk* eqchannelllkk'*combineruukk';
        end
        Ruukk = Ruukk+SNR*combinertemp-eqsignaluukk*eqsignaluukk';

        capacityMultiImperfect=capacityMultiImperfect+real(log2(det( eye(Nds) + eqsignaluukk'*inv(Ruukk)*eqsignaluukk )));

    end
end

% capacityMulitiImperfect01 = 0;
% F = dftmtx(subcarriersK);
% for uu = 1:P
%     Hdesireduu = [];
%     for nn = 1:length(pointSeq)
%         Hdesireduu = [Hdesireduu;HtimeToepImperfect((pointSeq(nn)-1)*Rx*P + 1 + (uu-1)*Rx : (pointSeq(nn)-1)*Rx*P + uu*Rx,:)]; % Extract Desired Channels
%     end
%     Hdesired{uu} = Hdesireduu;
% end
% for kk = 1:subcarriersK
%     Fbar = kron(F(kk,pointSeq),eye(Rx));
%     for uu = 1:P
%         Tuu = T((uu-1)*length(pointSeq)*Rx+[1:length(pointSeq)*Rx],:);
%         
%         Hdesireduu = Hdesired{uu};
%         Qzfuu = Qzf{uu};
%         Heffectkk = Fbar * Hdesireduu * Qzfuu;
%         eqchanneluu =Heffectkk*((Qzfuu'*Qzfuu)^(-1/2))*Tuu;
%         combinerkk = inv(eqchanneluu'*eqchanneluu+SNR*eye(Nds))*eqchanneluu';
%         InterUserdet = 0;
%         for uubar = 1:P
%             if uubar ~= uu
%                 Tuubar = T((uubar-1)*length(pointSeq)*Rx+[1:length(pointSeq)*Rx],:);
%                 Qzfuubar = Qzf{uubar};
%                 InterUserdet = InterUserdet + combinerkk * Fbar * Hdesireduu * Qzfuubar*((Qzfuubar'*Qzfuubar)^(-1/2))*Tuubar * (combinerkk * Fbar * Hdesireduu * Qzfuubar*((Qzfuubar'*Qzfuubar)^(-1/2))*Tuubar)';
%             end    
%         end
% 
%         capacityMulitiImperfect01 = capacityMulitiImperfect01 + real(log2(det(  eye(Nds)*combinerkk*combinerkk' + 1/SNR*(combinerkk* eqchanneluu * (combinerkk* eqchanneluu )'+InterUserdet ) )/det(  eye(Nds)*combinerkk*combinerkk' + 1/SNR*InterUserdet ) ));
%     end
% end

end

