function [H] = complexHouse(Z,P,n)

x = Z(:,n);
u = sqrt(x'*x);

eTheta = x(1)/norm(x(1));
v = (x+eTheta*u*[1;zeros(P-1,1)])/norm(x+eTheta*u*[1;zeros(P-1,1)]);
H = -conj(eTheta)*(eye(P)-2*v*v');
end

