function [NMSESingleImpulse,NMSESingleImpulseTimeDenoise,HfreqSingleImpulseEstInpoDenoise,HfreqSingleImpulse] = lsChannelSingleImpulse(SysPara,impulseShapeSingle,startPoint)
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
weightLen = SysPara.weightLen; % ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 minimum FIR Length
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio
ExtendedPilotIdx = SysPara.ExtendedPilotIdx;

F = dftmtx(subcarriersK);
HfreqSingleImpulse = cell(P,subcarriersK);


for uu = 1:P
    extractImpulseuu = impulseShapeSingle{uu}((startPoint-1)*Rx*P  + (uu-1)*Rx + [1:Rx],:); % Extract Desired Channels
    extractImpulseuutail = [];
    for mm = startPoint+1:weightLen + tapsN -1
        extractImpulseuutail = [extractImpulseuutail;impulseShapeSingle{uu}((mm-1)*Rx*P + 1 + (uu-1)*Rx : (mm-1)*Rx*P + uu*Rx,:)];
    end
    extractImpulseuuhead = [];
    for bb = 1:startPoint -1
        extractImpulseuuhead = [extractImpulseuuhead;impulseShapeSingle{uu}((bb-1)*Rx*P + 1 + (uu-1)*Rx : (bb-1)*Rx*P + uu*Rx,:)];
    end
    shiftedEffcChan = [extractImpulseuu;extractImpulseuutail;extractImpulseuuhead];
    for kk = 1:subcarriersK
        Fbar = kron(F(kk,1:weightLen + tapsN -1),eye(Rx));
        HfreqSingleImpulse{uu,kk} = Fbar * shiftedEffcChan;
    end
end


%% LS Est
if ExtendedPilotIdx == 1    
    baseNum = 2;
    [pilotOutput] = PilotGeneCECP2(subcarriersK/12,ExtendedPilotIdx);
    [HfreqSingleImpulseEst] = LSChannelEst2(SysPara,pilotOutput,HfreqSingleImpulse);
    % HfreqSingleImpulseEst = zeros(P,subcarriersK/12/baseNum,Rx,Nds);
    % [pilotOutput] = PilotGeneCECP(subcarriersK/12); %[subcarriersK,2,24] extend double
    % for uu = 1:P
    %     for kkidx = 1:subcarriersK/12/baseNum
    %         currentbaseNumber = floor((uu-1)/24); %% UserGroup Idx 0,1,...
    %         currentRealUUNumber = uu - currentbaseNumber*24;
    %         [locseq,wf,wt] = LSChannelEst(currentRealUUNumber);
    %         for ii = 1:length(locseq)
    %             pilot1 = squeeze(pilotOutput(locseq(ii) + (kkidx-1)*12,1,currentRealUUNumber));
    %             pilot2 = squeeze(pilotOutput(locseq(ii) + (kkidx-1)*12,2,currentRealUUNumber));
    %             noiseGene = 1/sqrt(2)*sqrt(SNR)*( (randn(Rx,Nds) + 1j*randn(Rx,Nds)) .* wt(1)./pilot1 + (randn(Rx,Nds) + 1j*randn(Rx,Nds)) * wt(2)./pilot2 )/2;
    %             currentChan = HfreqSingleImpulse{uu,locseq(ii) + currentbaseNumber*12 + (kkidx-1)*12*baseNum};
    %             HfreqSingleImpulseEst(uu,kkidx,:,:) = squeeze(HfreqSingleImpulseEst(uu,kkidx,:,:)) + currentChan + noiseGene .* wf(ii);
    %         end
    %         HfreqSingleImpulseEst(uu,kkidx,:,:) = squeeze(HfreqSingleImpulseEst(uu,kkidx,:,:))./length(locseq);
    %     end
    % end    
elseif ExtendedPilotIdx == 2
    baseNum = 4;
    [pilotOutput] = PilotGeneCECP2(subcarriersK/12,ExtendedPilotIdx);
    [HfreqSingleImpulseEst] = LSChannelEst2(SysPara,pilotOutput,HfreqSingleImpulse);
    % HfreqSingleImpulseEst = zeros(P,subcarriersK/12/baseNum,Rx,Nds);
    % [pilotOutput] = PilotGeneCECP(subcarriersK/12); %[subcarriersK,2,24] extend double
    % for uu = 1:P
    %     for kkidx = 1:subcarriersK/12/baseNum
    %         currentbaseNumber = floor((uu-1)/24); %% UserGroup Idx 0,1,...
    %         currentRealUUNumber = uu - currentbaseNumber*24;
    %         [locseq,wf,wt] = LSChannelEst(currentRealUUNumber);
    %         for ii = 1:length(locseq)
    %             pilot1 = squeeze(pilotOutput(locseq(ii) + (kkidx-1)*12,1,currentRealUUNumber));
    %             pilot2 = squeeze(pilotOutput(locseq(ii) + (kkidx-1)*12,2,currentRealUUNumber));
    %             noiseGene = 1/sqrt(2)*sqrt(SNR)*( (randn(Rx,Nds) + 1j*randn(Rx,Nds)) .* wt(1)./pilot1 + (randn(Rx,Nds) + 1j*randn(Rx,Nds)) * wt(2)./pilot2 )/2;
    %             currentChan = HfreqSingleImpulse{uu,locseq(ii) + currentbaseNumber*12 + (kkidx-1)*12*baseNum};
    %             HfreqSingleImpulseEst(uu,kkidx,:,:) = squeeze(HfreqSingleImpulseEst(uu,kkidx,:,:)) + currentChan + noiseGene * wf(ii);
    %         end
    %         HfreqSingleImpulseEst(uu,kkidx,:,:) = squeeze(HfreqSingleImpulseEst(uu,kkidx,:,:))./length(locseq);
    %     end
    % end
end

%% NMSE
% HfreqSingleImpulseEstInpo = mean(HfreqSingleImpulseEst,2); % Time domain denoise

HfreqSingleImpulseEstTime = ifft(HfreqSingleImpulseEst,floor(floor(subcarriersK/12)/baseNum),2);
HfreqSingleImpulseEstInpoDenoise = fft(HfreqSingleImpulseEstTime(:,1:1,:,:),subcarriersK,2);
NMSESingleImpulseTimeDenoise = 0;
for uu = 1:P
    for kk = 1:subcarriersK 
       NMSESingleImpulseTimeDenoise =  NMSESingleImpulseTimeDenoise + norm(squeeze(HfreqSingleImpulseEstInpoDenoise(uu,startPoint,:,:))-HfreqSingleImpulse{uu,kk},'fro').^2/norm(HfreqSingleImpulse{uu,kk},'fro').^2;
    end
end


HfreqSingleImpulseEstTime = ifft(HfreqSingleImpulseEst,floor(floor(subcarriersK/12)/baseNum),2);
HfreqSingleImpulseEstInpo = fft(HfreqSingleImpulseEstTime,subcarriersK,2);
NMSESingleImpulse = 0;
for uu = 1:P
    for kk = 1:subcarriersK
       NMSESingleImpulse =  NMSESingleImpulse + norm(squeeze(HfreqSingleImpulseEstInpo(uu,1,:,:))-HfreqSingleImpulse{uu,kk},'fro').^2/norm(HfreqSingleImpulse{uu,kk},'fro').^2;
    end
end

end