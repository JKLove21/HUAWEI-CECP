function [capacityMulti, impulseShape,timePrecoder,capacityMultiImperfect,chanEstNMSEMulti_imperfect,NMSEMultiImpulseTimeDenoise_imperfect] = QRMultiImpulse_robnew(HtimeToep,HtimeToepImperfect,Hfreq,HfreqImperfect,totalL,SysPara,sch_tag)
%UNTITLED5 此处显示有关此函数的摘要
%   此处显示详细说明
global  Rx subcarriersK SNR P pointSeq Hdesired Qzf
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
weightLen = SysPara.weightLen; % ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 minimum FIR Length
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio
channEstError=SysPara.channEstError;


Hdesired = cell(P,1);
Qzf = cell(P,1);
timePrecoder = zeros(weightLen * Tx, P*Nds);
centerPoint = ceil((weightLen + tapsN-1)/2); % Find the central Impulse Point
if totalL == 1
    leftPoint = 0;
    rightPoint = 0;
else
    leftPoint = floor((totalL-1)/2);
    rightPoint = ceil((totalL-1)/2);
end
pointSeq = [centerPoint - leftPoint:centerPoint + rightPoint]; % Multiple Responses Reservation Set

Tn=HtimeToep'*HtimeToep+Rx*sum(channEstError)*eye(weightLen*Tx);
tmp=inv(Tn'*Tn)*Tn'*HtimeToep';

% inv(R1'*R1);
for uu = 1:P
    Rnew = R1;
    Hdesireduu = [];
    counter = [];
    for nn = 1:length(pointSeq)
        Hdesireduu = [Hdesireduu;HtimeToep((pointSeq(nn)-1)*Rx*P + 1 + (uu-1)*Rx : (pointSeq(nn)-1)*Rx*P + uu*Rx,:)]; % Extract Desired Channels
        counter = [counter,(pointSeq(nn)-1)*Rx*P + 1 + (uu-1)*Rx : (pointSeq(nn)-1)*Rx*P + uu*Rx]; % Record The Index
    end
    Qzfuu = tmp(:, counter);
    % ExtractionTemp = Rnew(:, counter); % Extract Operation
    % Rnew(:, counter) = []; % Extract Operation
    % Rnew = [Rnew,ExtractionTemp]; % Shift Operation
    % [Q2,~] = qr(Rnew);
    % Qzfuu = Q1*Q2(:,end-length(pointSeq)*Rx+1:end);

    Hdesired{uu} = Hdesireduu;
    Qzf{uu} = Qzfuu;
end


%% Manifold Optimization for maximizing channel capacity
Tinitial = randn(length(pointSeq)*Rx*P,Nds) + 1j*randn(length(pointSeq)*Rx*P,Nds);
Tinitial = Tinitial/norm(Tinitial,'fro');
[capacityManifoldCGMethod,T] = MFGradDesMulti(Tinitial,SysPara);
capacityMulti = capacityManifoldCGMethod(end);
%% Return Time Precoder
impulseShape=cell(2,1);
for uu = 1:P
    timePrecoder(:,(uu-1)*Nds + [1:Nds]) = Qzf{uu} * ((Qzf{uu}'*Qzf{uu})^(-1/2))*T((uu-1)*length(pointSeq)*Rx + [1:length(pointSeq)*Rx],:);
    impulseShape_perfect{uu} = HtimeToep* Qzf{uu} * ((Qzf{uu}'*Qzf{uu})^(-1/2)) * T((uu-1)*length(pointSeq)*Rx + [1:length(pointSeq)*Rx],:);
    impulseShape_imperfect{uu} = HtimeToepImperfect* Qzf{uu} * ((Qzf{uu}'*Qzf{uu})^(-1/2)) * T((uu-1)*length(pointSeq)*Rx + [1:length(pointSeq)*Rx],:);
end
impulseShape{uu} = HtimeToepImperfect * Qzf{uu} * T((uu-1)*length(pointSeq)*Rx + [1:length(pointSeq)*Rx],:);


%% DMRS
[chanEstNMSEMulti,NMSEMultiImpulseTimeDenoise,multiEstChan,multiRealChan] = lsChannelMultiImpulse(SysPara,impulseShape_perfect,pointSeq,totalL);
[chanEstNMSEMulti_imperfect,NMSEMultiImpulseTimeDenoise_imperfect,multiEstChan_imperfect,multiRealChan_imperfect] = lsChannelMultiImpulse(SysPara,impulseShape_imperfect,pointSeq,totalL);

%% 频域预编码
% fre_precoder=zeros(Tx,P*Nds,subcarriersK);
% tptemp=zeros(Tx,Nds,weightLen);
% eqchannel_energy=zeros(P,subcarriersK);
% for uu=1:P
%     TPtemp=timePrecoder(:,(uu-1)*Nds+[1:Nds]);
%     for ii = 1:weightLen
%         tptemp(:,:,ii)=TPtemp((ii-1)*Tx+[1:Tx],:);
%     end
%     %fft
%     for ii = 1:Tx
%         for jj = 1:Nds
%             fre_precoder(ii,(uu-1)*Nds+jj,:) = fft(tptemp(ii,jj,:),subcarriersK);
%         end
%     end
% end

%% shift
F = dftmtx(subcarriersK);
Hfreqshift_perfect=cell(P,subcarriersK,P);
for ll=1:P
    for uu = 1:P
        extractImpulseuu = [];
        for nn = 1:length(pointSeq)
            extractImpulseuu = [extractImpulseuu;impulseShape_perfect{ll}((pointSeq(nn)-1)*Rx*P + 1 + (uu-1)*Rx : (pointSeq(nn)-1)*Rx*P + uu*Rx,:)]; % Extract Desired Channels
        end
        extractImpulseuutail = [];
        for mm = pointSeq(end)+1:weightLen + tapsN -1
            extractImpulseuutail = [extractImpulseuutail;impulseShape_perfect{ll}((mm-1)*Rx*P + 1 + (uu-1)*Rx : (mm-1)*Rx*P + uu*Rx,:)];
        end
        extractImpulseuuhead = [];
        for bb = 1:pointSeq(1) -1
            extractImpulseuuhead = [extractImpulseuuhead;impulseShape_perfect{ll}((bb-1)*Rx*P + 1 + (uu-1)*Rx : (bb-1)*Rx*P + uu*Rx,:)];
        end
        shiftedEffcChan = [extractImpulseuu;extractImpulseuutail;extractImpulseuuhead];
        for kk = 1:subcarriersK
            Fbar = kron(F(kk,1:weightLen + tapsN -1),eye(Rx));
            Hfreqshift_perfect{uu,kk,ll} = Fbar * shiftedEffcChan;
        end
    end
end

Hfreqshift_imperfect=cell(P,subcarriersK,P);
for ll=1:P
    for uu = 1:P
        extractImpulseuu = [];
        for nn = 1:length(pointSeq)
            extractImpulseuu = [extractImpulseuu;impulseShape_imperfect{ll}((pointSeq(nn)-1)*Rx*P + 1 + (uu-1)*Rx : (pointSeq(nn)-1)*Rx*P + uu*Rx,:)]; % Extract Desired Channels
        end
        extractImpulseuutail = [];
        for mm = pointSeq(end)+1:weightLen + tapsN -1
            extractImpulseuutail = [extractImpulseuutail;impulseShape_imperfect{ll}((mm-1)*Rx*P + 1 + (uu-1)*Rx : (mm-1)*Rx*P + uu*Rx,:)];
        end
        extractImpulseuuhead = [];
        for bb = 1:pointSeq(1) -1
            extractImpulseuuhead = [extractImpulseuuhead;impulseShape_imperfect{ll}((bb-1)*Rx*P + 1 + (uu-1)*Rx : (bb-1)*Rx*P + uu*Rx,:)];
        end
        shiftedEffcChan = [extractImpulseuu;extractImpulseuutail;extractImpulseuuhead];
        for kk = 1:subcarriersK
            Fbar = kron(F(kk,1:weightLen + tapsN -1),eye(Rx));
            Hfreqshift_imperfect{uu,kk,ll} = Fbar * shiftedEffcChan;
        end
    end
end


%% perfect channel
capacityMulti = 0;

for kk=1:subcarriersK
    for uu=1:P
        Ruukk=zeros(Nds,Nds);
        % channeluukk=squeeze(Hfreq((uu-1)*Nds+(1:Nds),:,kk));
        % precoderuukk=squeeze(fre_precoder(:,(uu-1)*Nds+(1:Nds),kk));

        eqchanneluukk_real = Hfreqshift_perfect{uu,kk,uu};
        eqchanneluukk_est=squeeze(multiEstChan(uu,kk,:,:));

        combineruukk=inv(eqchanneluukk_est'*eqchanneluukk_est+SNR*eye(Nds))*eqchanneluukk_est';
        eqsignaluukk=combineruukk*eqchanneluukk_real;
        combinertemp=combineruukk*combineruukk';
        for ll = 1:P
            % precoderllkk = squeeze(fre_precoder(:,(ll-1)*Nds + [1:Nds],kk));
            % Ruukk = Ruukk + combineruukk*channeluukk*precoderllkk*precoderllkk'*channeluukk'*combineruukk';

            eqchannelllkk=Hfreqshift_perfect {uu,kk,ll};
            Ruukk = Ruukk + combineruukk* eqchannelllkk* eqchannelllkk'*combineruukk';
        end
        Ruukk = Ruukk+SNR*combinertemp-eqsignaluukk*eqsignaluukk';

        capacityMulti=capacityMulti+real(log2(det( eye(Nds) + eqsignaluukk'*inv(Ruukk)*eqsignaluukk )));

    end
end
%% Imperfect Channel
capacityMultiImperfect = 0;

for kk=1:subcarriersK
    for uu=1:P
        Ruukk=zeros(Nds,Nds);
        eqchanneluukk_real = Hfreqshift_imperfect {uu,kk,uu};
        eqchanneluukk_est=squeeze(multiEstChan_imperfect (uu,kk,:,:));

        combineruukk=inv(eqchanneluukk_est'*eqchanneluukk_est+SNR*eye(Nds))*eqchanneluukk_est';
        eqsignaluukk=combineruukk*eqchanneluukk_real;
        combinertemp=combineruukk*combineruukk';
        %         eqsignaluukk=channeluukk*precoderuukk;
        combinertemp=combineruukk*combineruukk';
        for ll = 1:P
            % precoderllkk = squeeze(fre_precoder(:,(ll-1)*Nds + [1:Nds],kk));
            % Ruukk = Ruukk + combineruukk*channeluukk*precoderllkk*precoderllkk'*channeluukk'*combineruukk';
       
            eqchannelllkk=Hfreqshift_imperfect {uu,kk,ll};
            Ruukk = Ruukk + combineruukk* eqchannelllkk* eqchannelllkk'*combineruukk';

        end
        Ruukk = Ruukk+SNR*combinertemp-eqsignaluukk*eqsignaluukk';

        capacityMultiImperfect=capacityMultiImperfect+real(log2(det( eye(Nds) + eqsignaluukk'*inv(Ruukk)*eqsignaluukk )));

    end
end


end

