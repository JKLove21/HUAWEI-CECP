function [pilotOutput] = PilotGeneCECP(numRB)
% Return Extended Pilot
% TS38.211-i20 V18.2.0(2024-03)

pilotOutput = zeros(numRB*12,2,24); %[RBlength, double symbol, 24UE]

[r0,r1,r2] = PDSCH_dmrs(numRB);

for nn = 0:numRB-1
    for uu = 0:24-1
        switch uu
            case 0
                userIdx = 1;
                wf = [1,1,1,1];
                wt = [1,1];
                for ll = 1:2
                    for kk = 1:4
                        if kk<=2
                            pilotOutput(12*nn + kk + 0,ll,userIdx) = wf(kk)*wt(ll)*r0(4*nn + kk);
                        else
                            pilotOutput(12*nn + kk + 0 + 4,ll,userIdx)= wf(kk)*wt(ll)*r0(4*nn + kk);
                        end
                    end
                end
            case 1
                userIdx = 2;
                wf = [1,-1,1,-1];
                wt = [1,1];
                for ll = 1:2
                    for kk = 1:4
                        if kk<=2
                            pilotOutput(12*nn + kk + 0,ll,userIdx) = wf(kk)*wt(ll)*r0(4*nn + kk);
                        else
                            pilotOutput(12*nn + kk + 0 + 4,ll,userIdx)= wf(kk)*wt(ll)*r0(4*nn + kk);
                        end
                    end
                end
            case 6
            userIdx = 7;
            wf = [1,1,1,1];
            wt = [1,-1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 0,ll,userIdx) = wf(kk)*wt(ll)*r0(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 0 + 4,ll,userIdx)= wf(kk)*wt(ll)*r0(4*nn + kk);
                    end
                end
            end

            case 7
            userIdx = 8;
            wf = [1,-1,1,-1];
            wt = [1,-1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 0,ll,userIdx) = wf(kk)*wt(ll)*r0(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 0 + 4,ll,userIdx)= wf(kk)*wt(ll)*r0(4*nn + kk);
                    end
                end
            end
            case 12
            userIdx = 13;
            wf = [1,1,-1,-1];
            wt = [1,1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 0,ll,userIdx) = wf(kk)*wt(ll)*r0(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 0 + 4,ll,userIdx)= wf(kk)*wt(ll)*r0(4*nn + kk);
                    end
                end
            end
            case 13
            userIdx = 14;
            wf = [1,-1,-1,1];
            wt = [1,1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 0,ll,userIdx) = wf(kk)*wt(ll)*r0(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 0 + 4,ll,userIdx)= wf(kk)*wt(ll)*r0(4*nn + kk);
                    end
                end
            end
            case 18
            userIdx = 19;
            wf = [1,1,-1,-1];
            wt = [1,-1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 0,ll,userIdx) = wf(kk)*wt(ll)*r0(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 0 + 4,ll,userIdx)= wf(kk)*wt(ll)*r0(4*nn + kk);
                    end
                end
            end
            case 19
            userIdx = 20;
            wf = [1,-1,-1,1];
            wt = [1,-1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 0,ll,userIdx) = wf(kk)*wt(ll)*r0(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 0 + 4,ll,userIdx)= wf(kk)*wt(ll)*r0(4*nn + kk);
                    end
                end
            end







            case 2
            userIdx = 3;
            wf = [1,1,1,1];
            wt = [1,1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 2,ll,userIdx) = wf(kk)*wt(ll)*r1(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 2 + 4,ll,userIdx)= wf(kk)*wt(ll)*r1(4*nn + kk);
                    end
                end
            end
            case 3
            userIdx = 4;
            wf = [1,-1,1,-1];
            wt = [1,1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 2,ll,userIdx) = wf(kk)*wt(ll)*r1(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 2 + 4,ll,userIdx)= wf(kk)*wt(ll)*r1(4*nn + kk);
                    end
                end
            end
            case 8
            userIdx = 9;
            wf = [1,1,1,1];
            wt = [1,-1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 2,ll,userIdx) = wf(kk)*wt(ll)*r1(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 2 + 4,ll,userIdx)= wf(kk)*wt(ll)*r1(4*nn + kk);
                    end
                end
            end
            case 9
            userIdx = 10;
            wf = [1,-1,1,-1];
            wt = [1,-1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 2,ll,userIdx) = wf(kk)*wt(ll)*r1(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 2 + 4,ll,userIdx)= wf(kk)*wt(ll)*r1(4*nn + kk);
                    end
                end
            end
            case 14
            userIdx = 15;
            wf = [1,1,-1,-1];
            wt = [1,1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 2,ll,userIdx) = wf(kk)*wt(ll)*r1(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 2 + 4,ll,userIdx)= wf(kk)*wt(ll)*r1(4*nn + kk);
                    end
                end
            end
            case 15
            userIdx = 16;
            wf = [1,-1,-1,1];
            wt = [1,1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 2,ll,userIdx) = wf(kk)*wt(ll)*r1(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 2 + 4,ll,userIdx)= wf(kk)*wt(ll)*r1(4*nn + kk);
                    end
                end
            end
            case 20
            userIdx = 21;
            wf = [1,1,-1,-1];
            wt = [1,-1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 2,ll,userIdx) = wf(kk)*wt(ll)*r1(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 2 + 4,ll,userIdx)= wf(kk)*wt(ll)*r1(4*nn + kk);
                    end
                end
            end
            case 21
            userIdx = 22;
            wf = [1,-1,-1,1];
            wt = [1,-1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 2,ll,userIdx) = wf(kk)*wt(ll)*r1(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 2 + 4,ll,userIdx)= wf(kk)*wt(ll)*r1(4*nn + kk);
                    end
                end
            end







            case 4
            userIdx = 5;
            wf = [1,1,1,1];
            wt = [1,1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 4,ll,userIdx) = wf(kk)*wt(ll)*r2(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 4 + 4,ll,userIdx)= wf(kk)*wt(ll)*r2(4*nn + kk);
                    end
                end
            end
            case 5
            userIdx = 6;
            wf = [1,-1,1,-1];
            wt = [1,1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 4,ll,userIdx) = wf(kk)*wt(ll)*r2(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 4 + 4,ll,userIdx)= wf(kk)*wt(ll)*r2(4*nn + kk);
                    end
                end
            end
            case 10
            userIdx = 11;
            wf = [1,1,1,1];
            wt = [1,-1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 4,ll,userIdx) = wf(kk)*wt(ll)*r2(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 4 + 4,ll,userIdx)= wf(kk)*wt(ll)*r2(4*nn + kk);
                    end
                end
            end
            case 11
            userIdx = 12;
            wf = [1,-1,1,-1];
            wt = [1,-1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 4,ll,userIdx) = wf(kk)*wt(ll)*r2(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 4 + 4,ll,userIdx)= wf(kk)*wt(ll)*r2(4*nn + kk);
                    end
                end
            end
            case 16
            userIdx = 17;
            wf = [1,1,-1,-1];
            wt = [1,1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 4,ll,userIdx) = wf(kk)*wt(ll)*r2(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 4 + 4,ll,userIdx)= wf(kk)*wt(ll)*r2(4*nn + kk);
                    end
                end
            end
            case 17
            userIdx = 18;
            wf = [1,-1,-1,1];
            wt = [1,1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 4,ll,userIdx) = wf(kk)*wt(ll)*r2(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 4 + 4,ll,userIdx)= wf(kk)*wt(ll)*r2(4*nn + kk);
                    end
                end
            end
            case 22
            userIdx = 23;
            wf = [1,1,-1,-1];
            wt = [1,-1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 4,ll,userIdx) = wf(kk)*wt(ll)*r2(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 4 + 4,ll,userIdx)= wf(kk)*wt(ll)*r2(4*nn + kk);
                    end
                end
            end
            case 23
            userIdx = 24;
            wf = [1,-1,-1,1];
            wt = [1,-1];
            for ll = 1:2
                for kk = 1:4
                    if kk<=2
                        pilotOutput(12*nn + kk + 4,ll,userIdx) = wf(kk)*wt(ll)*r2(4*nn + kk);
                    else
                        pilotOutput(12*nn + kk + 4 + 4,ll,userIdx)= wf(kk)*wt(ll)*r2(4*nn + kk);
                    end
                end
            end


        end
    end
end




end