clear all
close all
clear global
%% Construct Parameters
global  SysPara
[SysPara] = ConstructParameters;
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio
dim = SysPara.SingleUserDim;
channEstError = SysPara.channEstError;
%% Test Part
MaximumEquivalentChannelLen = 8; % Compare the effect of equivalent channel length
MonteCarloNum =1;
totalL = 3;
SNRrange = 10:2:20;
% LRange  = (ceil((tapsN-1)/(Tx/(P*dim)-1))+1+50 ):5:(ceil((tapsN-1)/(Tx/(P*dim)-1))+1 +50 );
LRange = 50 ;   
len  = length(LRange);

% EST
FourRBEZFEst = zeros(length(SNRrange),len,MonteCarloNum);
EZFEst = zeros(length(SNRrange),len,MonteCarloNum);

SingleImpulseEst = zeros(length(SNRrange),len,MonteCarloNum);
% MultiImpulseEst = zeros(length(SNRrange),MaximumEquivalentChannelLen,MonteCarloNum);
MultiImpulseEst = zeros(length(SNRrange),len,MonteCarloNum);

SingleImpulseEstTimeDenoise  = zeros(length(SNRrange),len,MonteCarloNum);
% MultiImpulseEstTimeDenoise = zeros(length(SNRrange),MaximumEquivalentChannelLen,MonteCarloNum);
MultiImpulseEstTimeDenoise   = zeros(length(SNRrange),len,MonteCarloNum);

SingleImpulseEst_rob   = zeros(length(SNRrange),len,MonteCarloNum);
% MultiImpulseEst_rob  = zeros(length(SNRrange),MaximumEquivalentChannelLen,MonteCarloNum);
MultiImpulseEst_rob    = zeros(length(SNRrange),len,MonteCarloNum);
SingleImpulseEstTimeDenoise_rob  = zeros(length(SNRrange),len,MonteCarloNum);
% MultiImpulseEstTimeDenoise_rob = zeros(length(SNRrange),MaximumEquivalentChannelLen,MonteCarloNum);
MultiImpulseEstTimeDenoise_rob   = zeros(length(SNRrange),len,MonteCarloNum);

% Capacity
EZFCapacityTtl_RB       = zeros(length(SNRrange),len,MonteCarloNum);
EZFCapacityTtl_RE       = zeros(length(SNRrange),len,MonteCarloNum);
EZFCapacityTtl_sch      = zeros(length(SNRrange),len,MonteCarloNum);


EZFCapacityTtl_RE_Imperfect= zeros(length(SNRrange),len,MonteCarloNum);
EZFCapacityTtl_RB_Imperfect      = zeros(length(SNRrange),len,MonteCarloNum);

capacitySinglePTtl               = zeros(length(SNRrange),len,MonteCarloNum);
capacitySinglePTtl_rob           = zeros(length(SNRrange),len,MonteCarloNum);
capacitySinglePTtl_Imperfect     = zeros(length(SNRrange),len,MonteCarloNum);
capacitySinglePTtl_Imperfect_rob = zeros(length(SNRrange),len,MonteCarloNum);
capacitySinglePTtl_Imperfect_robnew =zeros(length(SNRrange),len,MonteCarloNum);

capacityMultiPTtl                = zeros(length(SNRrange),len,MonteCarloNum);
capacityMultiPTtl_rob            = zeros(length(SNRrange),len,MonteCarloNum);
capacityMultiPTtl_Imperfect      = zeros(length(SNRrange),len,MonteCarloNum);
capacityMultiPTtl_Imperfect_rob  = zeros(length(SNRrange),len,MonteCarloNum);
capacityMultiPTtl_Imperfect_robnew  = zeros(length(SNRrange),len,MonteCarloNum);

%% Loop
for testNum = 1:MonteCarloNum
    %% Global Seed
    % rng(testNum);
    counter_len =0;
    Seed = SysPara.Seed*testNum+randi(100);

    [SysPara] = ConstructParameters;
    SysPara.Seed = Seed ;
    [muMimoChanCell,genieChanFreq,singularValueCell] = muMimoChan_gen(SysPara); % Generate NRCDL Channel

    for weightLen = LRange
        counter = 0;
        counter_len =  counter_len+1;
        SysPara.weightLen = weightLen;
        [HtimeToep,HtimeToepImperfect,Hfreq, HfreqImperfect] = channelGen(SysPara,muMimoChanCell);
        [HtimeToepR,HtimeToepRImperfect,HfreqR,HfreqRImperfect] = LowDimTGen_new(Hfreq, HfreqImperfect,SysPara);

        for SNRbar = SNRrange
            SysPara.SNR = 1/db2pow(SNRbar);
            global SNR
            SNR = 1/db2pow(SNRbar);
            counter = counter + 1;
            SysPara.Rx = Rx;
            %% Aggregated Block Toeplitz Channel Matrix T Generation
            %% EZF
            % [EZFCapacity,EZFCapacityImperfect,chanEstNMSEEZF,EZFRealChan,EZFEstChan,ezfPrecoder] = EZF(SysPara,Hfreq,HfreqImperfect);
            % [chanEstNMSEEZF,EZFEstChan,EZFRealChan] = lsChannelEZF(SysPara,EZFEquiChanImperfect);
            % EZFEst(counter,counter_len,testNum)   = chanEstNMSEEZF/subcarriersK/P;
            % EZFCapacityTtl_RE(counter,counter_len,testNum)           = EZFCapacity;
            % EZFCapacityTtl_RE_Imperfect(counter,counter_len,testNum) = EZFCapacityImperfect;

            % 4RB EZF
            [FourRBEZFCapacity,FourRBEZFCapacityImperfect,chanEstNMSEFourRBEZF,fourRBRealChan,fourRBEstChan,fourRBezfPrecoder] = FourRBEZF(SysPara,Hfreq,HfreqImperfect);
            % [chanEstNMSEFourRBEZF,fourRBEstChan,fourRBRealChan] = lsChannelFourRBEZF(SysPara,FourRBEZFEquiChanImperfect);
            FourRBEZFEst(counter,counter_len,testNum)  =  chanEstNMSEFourRBEZF/subcarriersK/P;
            EZFCapacityTtl_RB(counter,counter_len,testNum)           = FourRBEZFCapacity;
            EZFCapacityTtl_RB_Imperfect(counter,counter_len,testNum) = FourRBEZFCapacityImperfect;

            
            %% Proposed Method for Single Impulse based on QR decomposition
            % single
            SysPara.Rx = dim;
            [capacitySingle,timePrecoder,capacitySingleImperfect,chanEstNMSESingle,NMSESingleImpulseTimeDenoise,singleEstChan,singleRealChan] = QRSingleImpulse(HtimeToepR,HtimeToepRImperfect,HfreqR,HfreqRImperfect,SysPara);
            % [chanEstNMSESingle,NMSESingleImpulseTimeDenoise,singleEstChan,singleRealChan] = lsChannelSingleImpulse(SysPara,impulseShapeSingle,startPoint);
            SingleImpulseEst(counter,counter_len,testNum)               = chanEstNMSESingle/subcarriersK/P;
            SingleImpulseEstTimeDenoise(counter,counter_len,testNum)    = NMSESingleImpulseTimeDenoise/subcarriersK/P;
            capacitySinglePTtl(counter, counter_len,testNum)            = capacitySingle;
            capacitySinglePTtl_Imperfect (counter, counter_len,testNum) = capacitySingleImperfect;

            % [capacitySingle_rob,impulseShapeSingle_rob,capacitySingleImperfect_rob,~,~,singleEstChan_rob,singleRealChan_rob] = QRSingleImpulse_rob(HtimeToepR,HtimeToepRImperfect,HfreqR,HfreqRImperfect,SysPara);
            [capacitySingle_robnew, impulseShape,timePrecoder,capacitySingleImperfect_robnew,chanEstNMSESingle_rob,NMSESingleImpulseTimeDenoise_rob] = QRSingleImpulse_robnew(HtimeToepR,HtimeToepRImperfect,HfreqR,HfreqRImperfect,SysPara);
            % [chanEstNMSESingle_rob,NMSESingleImpulseTimeDenoise_rob,singleEstChan_rob,singleRealChan_rob] = lsChannelSingleImpulse(SysPara,impulseShapeSingle_rob,startPoint);
            SingleImpulseEst_rob(counter,counter_len,testNum)            = chanEstNMSESingle_rob/subcarriersK/P;
            SingleImpulseEstTimeDenoise_rob(counter,counter_len,testNum) = NMSESingleImpulseTimeDenoise_rob/subcarriersK/P;
            capacitySinglePTtl_Imperfect_robnew(counter, counter_len,testNum) = capacitySingleImperfect_robnew;


            clear Hdesired Qzf
            %% Proposed Method for Multi Impulse based on QR decomposition
            % multi

            % for totalL = 2:2:MaximumEquivalentChannelLen % 2 means channel length is shortend to 2;
            %     [capacityMulti,timePrecoderMulti,impulseShapeMulti,capacityMultiImperfect,pointSeq] = QRMultiImpulse(HtimeToep,HtimeToepImperfect,Hfreq,HfreqImperfect,totalL,SysPara);
            %     [chanEstNMSEMulti,NMSEMultiImpulseTimeDenoise,multiEstChan,multiRealChan] = lsChannelMultiImpulse(SysPara,impulseShapeMulti,pointSeq,totalL);
            %     MultiImpulseEst(counter,totalL,testNum) = chanEstNMSEMulti/subcarriersK/P;
            %     MultiImpulseEstTimeDenoise(counter,totalL,testNum) = NMSEMultiImpulseTimeDenoise/subcarriersK/P;
            %
            %     [capacityMulti_rob,impulseShapeMulti_rob,timePrecoderMulti_rob,capacityMultiImperfect_rob,pointSeq] = QRMultiImpulse_rob(HtimeToep,HtimeToepImperfect,Hfreq,HfreqImperfect,totalL,SysPara);
            %     [chanEstNMSEMulti_rob,NMSEMultiImpulseTimeDenoise_rob,multiEstChan_rob,multiRealChan_rob] = lsChannelMultiImpulse(SysPara,impulseShapeMulti_rob,pointSeq,totalL);
            %     MultiImpulseEst_rob(counter,totalL,testNum) = chanEstNMSEMulti_rob/subcarriersK/P;
            %     MultiImpulseEstTimeDenoise_rob(counter,totalL,testNum) = NMSEMultiImpulseTimeDenoise_rob/subcarriersK/P;
            %
            %     disp(totalL);
            % end

            % [capacityMulti,timePrecoderMulti,capacityMultiImperfect,chanEstNMSEMulti,NMSEMultiImpulseTimeDenoise,multiEstChan,multiRealChan] = QRMultiImpulse(HtimeToepR,HtimeToepRImperfect,HfreqR,HfreqRImperfect,totalL,SysPara);
            % [chanEstNMSEMulti,NMSEMultiImpulseTimeDenoise,multiEstChan,multiRealChan] = lsChannelMultiImpulse(SysPara,impulseShapeMulti,pointSeq,totalL);
            % MultiImpulseEst(counter,counter_len,testNum)             = chanEstNMSEMulti/subcarriersK/P;
            % MultiImpulseEstTimeDenoise(counter,counter_len,testNum)  = NMSEMultiImpulseTimeDenoise/subcarriersK/P;
            % capacityMultiPTtl(counter,counter_len,testNum)           = capacityMulti;
            % capacityMultiPTtl_Imperfect(counter,counter_len,testNum) = capacityMultiImperfect;

            % [capacityMulti_rob,timePrecoderMulti_rob,capacityMultiImperfect_rob,chanEstNMSEMulti_rob,NMSEMultiImpulseTimeDenoise_rob,multiEstChan_rob,multiRealChan_rob] = QRMultiImpulse_rob(HtimeToepR,HtimeToepRImperfect,HfreqR,HfreqRImperfect,totalL,SysPara);
            % [capacityMulti_robnew, impulseShape,timePrecoder,capacityMultiImperfect_robnew,chanEstNMSEMulti_rob,NMSEMultiImpulseTimeDenoise_rob] = QRMultiImpulse_robnew(HtimeToepR,HtimeToepRImperfect,HfreqR,HfreqRImperfect,totalL,SysPara);

            % [chanEstNMSEMulti_rob,NMSEMultiImpulseTimeDenoise_rob,multiEstChan_rob,multiRealChan_rob] = lsChannelMultiImpulse(SysPara,impulseShapeMulti_rob,pointSeq,totalL);
            % MultiImpulseEst_rob(counter,counter_len,testNum)             = chanEstNMSEMulti_rob/subcarriersK/P;
            % MultiImpulseEstTimeDenoise_rob(counter,counter_len,testNum)  = NMSEMultiImpulseTimeDenoise_rob/subcarriersK/P;
            % capacityMultiPTtl_rob(counter,counter_len,testNum)           = capacityMulti_rob;
            % capacityMultiPTtl_Imperfect_rob(counter,counter_len,testNum) = capacityMultiImperfect_rob;
            % capacityMultiPTtl_Imperfect_robnew(counter,counter_len,testNum) = capacityMultiImperfect_robnew;

           

            disp(channEstError);
            disp(testNum);
            disp(SNRbar);
            disp(weightLen);

        end
        [SysPara] = ConstructParameters;
    end
end


%%  plot
% esterror_SNR plot
% Esterror_EZF = pow2db(mean(EZFEst,3));
Esterror_FourRBEZF = pow2db(mean(FourRBEZFEst,3));
Esterror_SingleImpulse = pow2db(mean(SingleImpulseEst,3));
Esterror_SingleImpulse_rob = pow2db(mean(SingleImpulseEst_rob,3));
% Esterror_MultiImpulse = pow2db(mean(MultiImpulseEstTimeDenoise,3));
% Esterror_MultiImpulse_rob = pow2db(mean(MultiImpulseEstTimeDenoise_rob,3));

% Esterror_MultiImpulse_L = pow2db(mean(MultiImpulseEstTimeDenoise,3));
% Esterror_MultiImpulse = Esterror_MultiImpulse_L(:,end);
% Esterror_MultiImpulse_rob_L = pow2db(mean(MultiImpulseEstTimeDenoise_rob,3));
% Esterror_MultiImpulse_rob = Esterror_MultiImpulse_rob_L(:,end);

%%

f=figure;
% plot(Esterror_EZF(:,end),'k-s','LineWidth',2)
% hold on
plot(Esterror_FourRBEZF(:,end),'B-x','LineWidth',2)
hold on
plot(Esterror_SingleImpulse(:,end),'r-o','LineWidth',2)
hold on
plot(Esterror_SingleImpulse_rob(:,end),'r--o','LineWidth',2)
hold on
% plot(Esterror_MultiImpulse(:,end),'g-P','LineWidth',2)
% hold on
% plot(Esterror_MultiImpulse_rob(:,end),'g--P','LineWidth',2)
% hold on
% title(['Channel estimation error comparison (with combiner) ' , 'SNR = ' num2str(pow2db(1/SNR)) ,'channEstError = ' num2str(pow2db(1./SysPara.channEstError).')])
title('Channel estimation error comparison (with combiner) ' )
subtTxt = genSubtitle(MonteCarloNum,SysPara);
subtitle(subtTxt)

% legend('EZF4RB','Single','Single rob','Multi','Multi rob')
legend('EZF4RB','Single','Single rob')
ylabel('channel estimation error (dB)')
xlabel('SNR')
xticks([1:length(SNRrange)])
xticklabels(SNRrange)

%%
% capacity_SNR plot
capaEZF_RB = mean(EZFCapacityTtl_RB,3)/subcarriersK;
capaEZF_RB_Imperfect= mean(EZFCapacityTtl_RB_Imperfect,3)/subcarriersK;
% capaEZF_fullband = mean(EZFCapacityTtl_RE,3)/subcarriersK;
% capaEZF_fullband_Imperfect = mean(EZFCapacityTtl_RE_Imperfect,3)/subcarriersK;
% capaEZF_sch = mean(EZFCapacityTtl_sch,2)/subcarriersK;

capaSRC = mean(capacitySinglePTtl,3)/subcarriersK;
% capaSRC_rob = mean(capacitySinglePTtl_rob,3)/subcarriersK;
capaSRC_Imperfect = mean(capacitySinglePTtl_Imperfect,3)/subcarriersK;
% capaSRC_Imperfect_rob = mean(capacitySinglePTtl_Imperfect_rob,3)/subcarriersK;
capaSRC_Imperfect_robnew = mean(capacitySinglePTtl_Imperfect_robnew,3)/subcarriersK;

% capaMRC = mean(capacityMultiPTtl,3)/subcarriersK;
% capaMRC_rob = mean(capacityMultiPTtl_rob,2)/subcarriersK;
% capaMRC_Imperfect = mean(capacityMultiPTtl_Imperfect,3)/subcarriersK;
% capaMRC_Imperfect_rob = mean(capacityMultiPTtl_Imperfect_rob,3)/subcarriersK;
% capaMRC_Imperfect_robnew = mean(capacityMultiPTtl_Imperfect_robnew,3)/subcarriersK;
%%

figure;
% plot(SNRrange,capaEZF_fullband(:,end),'k-s','LineWidth',2);
% hold on;
% plot(SNRrange,capaEZF_fullband_Imperfect(:,end),'k--s','LineWidth',2);
% hold on;
plot(SNRrange,capaEZF_RB(:,end),'B-x','LineWidth',2);
hold on;
plot(SNRrange,capaEZF_RB_Imperfect(:,end),'B--x','LineWidth',2);
hold on;

plot(SNRrange,capaSRC(:,end),'r-o','LineWidth',2);
hold on;
% plot(SNRrange,capaSRC_rob(:,end),'r:o','LineWidth',2);
% hold on;
plot(SNRrange,capaSRC_Imperfect(:,end),'r--o','LineWidth',2);
hold on;
% plot(SNRrange,capaSRC_Imperfect_rob(:,end),'r-.o','LineWidth',2);
% hold on;
plot(SNRrange,capaSRC_Imperfect_robnew(:,end),'m-o','LineWidth',2);
hold on;

% plot(SNRrange,capaMRC(:,end),'g-P','LineWidth',2);
% hold on;
% plot(SNRrange,capaMRC_rob(:,end),'g:P','LineWidth',2);
% hold on;
% plot(SNRrange,capaMRC_Imperfect(:,end),'g--P','LineWidth',2);
% hold on;
% plot(SNRrange,capaMRC_Imperfect_rob(:,end),'g-.P','LineWidth',2);
% hold on;
% plot(SNRrange,capaMRC_Imperfect_robnew(:,end),'m-P','LineWidth',2);
% hold on;

grid on
legend('EZF 4RB ', 'EZF 4RB imperfect','Single ideal nonrob','Single imperfect nonrob','Single imperfect robnew')

xlabel('SNR')
ylabel('Channel Capacity (bps/Hz)')
title('Capacity v.s. SNR')
subtTxt = genSubtitle(MonteCarloNum,SysPara);
subtitle([subtTxt ' FIRlength = ' num2str(LRange(end))]);
