clear all
close all
clear global
%% Construct Parameters
global fre_seq SysPara sub_user_seq
[SysPara] = ConstructParameters;
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
dim = SysPara.SingleUserDim; % Dimension Reduced per User
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio
RBsize = SysPara.RBsize; % 12
RBnum = SysPara.RBnum; % floor()s
UE_schedulnum = SysPara.UE_schedulnum; % 4

%% Test Part
chanNonZeroEle = 5; % chanNonZeroEle
LRange = (ceil((tapsN-1)/(Tx/(P*dim)-1))+20 ):5:(ceil((tapsN-1)/(Tx/(P*dim)-1))+1 + 70);
% LRange = 10:4:30;
% LRange = 50;
len = length(LRange);
monteCarloNum = 1;
time_select = 2 ;
% EZFCapacityTtl = zeros(len ,monteCarloNum);
EZFCapacityTtl_fullband = zeros(len,monteCarloNum,time_select+1);
EZFCapacityTtl_sch = zeros(len,monteCarloNum,time_select+1);

capacitySinglePTtl = zeros(len,monteCarloNum,time_select+1);
capacityMultiPTtl = zeros(len,monteCarloNum,time_select+1);
capacityMultiPTtl_newsch = zeros(len,monteCarloNum,time_select+1);

ezf_precoder=cell(len,1);
ezf_sch_precoder=cell(len,1);
single_precoder=cell(len,1);
multi_precoder=cell(len,1);
multi_precoder_sch=cell(len,1);

for ii = 1:monteCarloNum
    % SysPara.Seed = SysPara.Seed*ii;
    Seed = SysPara.Seed*ii+round(rand(1)*100);

    [SysPara] = ConstructParameters;
    SysPara.Seed = Seed ;
    [muMimoChanCell,muMimoChanCell_predict] = muMimoChan_gen_new(SysPara);
    % time_select=size(muMimoChanCell,2);
    for jj=1:time_select
        counter = 0;
        muMimoChanCell_temp=cell(P,1);
        for uu=1:P
            muMimoChanCell_temp{uu}=muMimoChanCell{uu,jj};
        end
        for weightLen = LRange
            SysPara.weightLen = weightLen;
            counter = counter + 1;
            if jj == 1
                %% Generate Channel
                [HtimeToep,Hfreq] = AggreTGen(muMimoChanCell_temp,SysPara); % Generate T based on NRCDL Channel
                [HtimeToepR,HfreqR] = LowDimTGen(muMimoChanCell_temp,SysPara);

                [Htime_subband_sch,HtimeToepR_sch, HfreqR_sch]=Htime_sch_new(SysPara,Hfreq,HtimeToep);
                [fre_seq,sub_user_seq] = fre_sch_new(Hfreq,SysPara);
                %% EZF
                [EZFCapacity_band,ezf_precoder{counter}] = EZF(SysPara,Hfreq);
                % [EZFCapacity] = EZF(SysPara,Hfreq);
                % [EZFCapacity_RB] = EZF_RB(SysPara,Hfreq);
                [EZFCapacity_schRE,ezf_sch_precoder{counter}] = EZF_sch_RE(SysPara,Hfreq);

                % EZFCapacityTtl(counter,ii) = EZFCapacity_RB;
                EZFCapacityTtl_fullband(counter,ii,jj) = EZFCapacity_band;
                EZFCapacityTtl_sch(counter,ii,jj) = EZFCapacity_schRE;
                %% Proposed method w/ Resduction
                SysPara.Rx = dim;
                % single

                % [capacitySingleR,~,single_precoder{counter}] = QRSingleImpulse(HtimeToepR,HfreqR,SysPara);
                % capacitySinglePTtl(counter,ii,jj) = capacitySingleR;
                % multi

                [capacityMultiR,timePrecoder,multi_precoder{counter}] = QRMultiImpulse(HtimeToepR,HfreqR,chanNonZeroEle,SysPara);
                % [~,capacityMultiR,timePrecoder] = QRMultiImpulse(HtimeToepR,chanNonZeroEle,SysPara);
                capacityMultiPTtl(counter,ii,jj) = capacityMultiR;

                [capa_newsch,multi_precoder_sch{counter}]=sub_multi(HtimeToepR,HfreqR,SysPara,chanNonZeroEle,sub_user_seq);
                capacityMultiPTtl_newsch(counter,ii,jj) = capa_newsch;
                %
                [SysPara] = ConstructParameters;
            else
                [~,Hfreq] = AggreTGen(muMimoChanCell_temp,SysPara); % Generate T based on NRCDL Channel
                [~,HfreqR] = LowDimTGen(muMimoChanCell_temp,SysPara);
                EZFCapacityTtl_fullband(counter,ii,jj) =  calcCapa_fullband(Hfreq,ezf_precoder{counter},SysPara);
                EZFCapacityTtl_sch(counter,ii,jj) =       calcCapa_sch(Hfreq,ezf_sch_precoder{counter},SysPara);

                % capacitySinglePTtl(counter,ii,jj) =       calcCapa_fullband(HfreqR,single_precoder{counter},SysPara);
                capacityMultiPTtl(counter,ii,jj)  =       calcCapa_fullband(HfreqR,multi_precoder{counter},SysPara);
                capacityMultiPTtl_newsch(counter,ii,jj) = calcCapa_sch(HfreqR,multi_precoder_sch{counter},SysPara);

            end
        end
    end
    %% for predict
    [SysPara] = ConstructParameters;
    counter = 0;
    muMimoChanCell_temp=cell(P,1);
    for uu=1:P
        muMimoChanCell_temp{uu}=muMimoChanCell_predict{uu};
    end
    for weightLen = LRange
        SysPara.weightLen = weightLen;
        counter = counter + 1;

        %% Generate Channel
        [HtimeToep,Hfreq] = AggreTGen(muMimoChanCell_temp,SysPara); % Generate T based on NRCDL Channel
        [HtimeToepR,HfreqR] = LowDimTGen(muMimoChanCell_temp,SysPara);

        [Htime_subband_sch,HtimeToepR_sch, HfreqR_sch]=Htime_sch_new(SysPara,Hfreq,HtimeToep);
        [fre_seq,sub_user_seq] = fre_sch_new(Hfreq,SysPara);
        %% EZF
        [~,ezf_precoder{counter}] = EZF_fullband(SysPara,Hfreq);
        [~,ezf_sch_precoder{counter}] = EZF_sch_RE(SysPara,Hfreq);

        %% Proposed method w/ Resduction
        SysPara.Rx = dim;
        % single
        % [~,~,single_precoder{counter}] = QRSingleImpulse(HtimeToepR,HfreqR,SysPara);
        % multi
        [~,timePrecoder,multi_precoder{counter}] = QRMultiImpulse(HtimeToepR,HfreqR,chanNonZeroEle,SysPara);
        [~,multi_precoder_sch{counter}]=sub_multi(HtimeToepR,HfreqR,SysPara,chanNonZeroEle,sub_user_seq);
        %
        [SysPara] = ConstructParameters;
    end
   
    jj=jj+1;
    muMimoChanCell_temp=cell(P,1);
    for uu=1:P
        muMimoChanCell_temp{uu}=muMimoChanCell{uu,end};
    end
    counter=0;
    for weightLen = LRange
        SysPara.weightLen = weightLen;
        [HtimeToep,Hfreq] = AggreTGen(muMimoChanCell_temp,SysPara); % Generate T based on NRCDL Channel
        [HtimeToepR,HfreqR] = LowDimTGen(muMimoChanCell_temp,SysPara);
        

        counter=counter+1;
        EZFCapacityTtl_fullband(counter,ii,jj) =  calcCapa_fullband(Hfreq,ezf_precoder{counter},SysPara);
        EZFCapacityTtl_sch(counter,ii,jj) =       calcCapa_sch(Hfreq,ezf_sch_precoder{counter},SysPara);

        % capacitySinglePTtl(counter,ii,jj) =       calcCapa_fullband(HfreqR,single_precoder{counter},SysPara);
        capacityMultiPTtl(counter,ii,jj)  =       calcCapa_fullband(HfreqR,multi_precoder{counter},SysPara);
        capacityMultiPTtl_newsch(counter,ii,jj) = calcCapa_sch(HfreqR,multi_precoder_sch{counter},SysPara);
    end
end



% end
%%

% capaORG = mean(capacityOrgChan,2)/subcarriersK;
% capaRC = mean(capacityReducedChan,2)/subcarriersK;

% capaEZF_RB= mean(EZFCapacityTtl,2)/subcarriersK;
capaEZF_fullband = mean(EZFCapacityTtl_fullband,2)/subcarriersK;
capaEZF_sch = mean(EZFCapacityTtl_sch,2)/subcarriersK;

% capaSRC = mean(capacitySinglePTtl,2)/subcarriersK;
capaMRC = mean(capacityMultiPTtl,2)/subcarriersK;
capaMRC_schedul_v2 = mean(capacityMultiPTtl_newsch,2)/subcarriersK;

%% position
% plot(capapos);
% grid on
figure

plot(LRange,capaEZF_fullband(:,1),'k-o','LineWidth',2);
hold on;
plot(LRange,capaEZF_sch(:,1),'b-o','LineWidth',2);
% hold on;
% plot(LRange,capaSRC(:,1),'r-o','LineWidth',2);
hold on;
plot(LRange,capaMRC(:,1),'g-o','LineWidth',2);
hold on;
plot(LRange,capaMRC_schedul_v2(:,1),'m-o','LineWidth',2);


plot(LRange,capaEZF_fullband(:,2),'k--x','LineWidth',2);
hold on;
plot(LRange,capaEZF_sch(:,2),'b--x','LineWidth',2);
% hold on;
% plot(LRange,capaSRC(:,2),'r--x','LineWidth',2);
hold on;
plot(LRange,capaMRC(:,2),'g--x','LineWidth',2);
hold on;
plot(LRange,capaMRC_schedul_v2(:,2),'m--x','LineWidth',2);


plot(LRange,capaEZF_fullband(:,3),'k-.^','LineWidth',2);
hold on;
plot(LRange,capaEZF_sch(:,3),'b-.^','LineWidth',2);
% hold on;
% plot(LRange,capaSRC(:,2),'r--x','LineWidth',2);
hold on;
plot(LRange,capaMRC(:,3),'g-.^','LineWidth',2);
hold on;
plot(LRange,capaMRC_schedul_v2(:,3),'m-.^','LineWidth',2);


grid

% legend('EZF fullband RE','EZF sch RE','Single','Multi fullband','Multi scheduling A2', ...
%     'EZF fullband RE t2','EZF sch RE t2','Single t2','Multi fullband t2','Multi scheduling A2 t2')
legend('EZF fullband RE','EZF sch RE','Multi fullband','Multi scheduling A2', 'EZF fullband RE t2','EZF sch RE t2', ...
    'Multi fullband t2','Multi scheduling A2 t2','EZF fullband RE predict','EZF sch RE predict','Multi fullband predict','Multi scheduling A2 predict');
xlabel('FIR Length')
% ylim([4.5*10^4 6.5*10^4])
ylabel('Channel Capacity (bps/Hz)')
title('Capacity v.s. FIR Length')
subtTxt = genSubtitle(monteCarloNum,SysPara);
subtitle(subtTxt)
%% Visualize
% % plot(LRange,capaORG,'k-','LineWidth',2);
% % hold on;
% % plot(LRange,capaRC,'r--','LineWidth',2);
% % hold on;
% plot(LRange,capaEZF,'g-','LineWidth',2);
% hold on;
% % plot(LRange,capaSO,'b--o','LineWidth',2);
% % hold on;
% % plot(LRange,capaMO,'bs-','LineWidth',2);
% % hold on;
% plot(LRange,capaSRC,'r--o','LineWidth',2);
% hold on;
% plot(LRange,capaMRC,'rs-','LineWidth',2);
% hold on;
% grid
% legend('EZF',...
%     'Single w/ Reduction','Multi w/ Reduction','Location','southeast')
% xlabel('FIR Length')
% % ylim([4.5*10^4 6.5*10^4])
% ylabel('Channel Capacity (bps/Hz)')
% title('Capacity v.s. FIR Length')
% subtTxt = genSubtitle(monteCarloNum,SysPara);
% subtitle(subtTxt)