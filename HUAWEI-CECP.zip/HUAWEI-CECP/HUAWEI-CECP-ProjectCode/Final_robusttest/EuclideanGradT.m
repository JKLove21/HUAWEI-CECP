function [gradT] = EuclideanGradT(T)
%UNTITLED 此处显示有关此函数的摘要
% Heffectkk = Hbarpk Vp = Tuu
global Rx subcarriersK SNR P Hdesired Qzf startPoint
F = dftmtx(subcarriersK);
gradT = zeros(size(T));
% for uu = 1:P
%     value = 0;
%     Tuu = T((uu-1)*Rx+[1:Rx],:);
%     Hdesireduu = Hdesired{uu};
%     Qzfuu = Qzf{uu};
%     for kk = 1:subcarriersK
%         Fbar = kron(F(kk,startPoint),eye(Rx));
%         Heffectkk = Fbar * Hdesireduu * Qzfuu;
%         Mpk = SNR*eye(size(Tuu,2))+( Heffectkk * Tuu )'* Heffectkk * Tuu ;
%         value = value - Heffectkk' * Heffectkk * Tuu / Mpk;
%     end
%     gradT((uu-1)*Rx+[1:Rx],:) = value;
% end
for uu = 1:P
    value = 0;
    Tuu = T((uu-1)*Rx+[1:Rx],:);
    Hdesireduu = Hdesired{uu};
    Qzfuu = Qzf{uu};
    for kk = 1:subcarriersK
        Fbar = kron(F(kk,startPoint),eye(Rx));
        % Heffectkk = Fbar * Hdesireduu * Qzfuu;
        Heffectkk = Fbar *Hdesireduu * Qzfuu* (Qzfuu'*Qzfuu)^(-1/2);


        Mpk = SNR*eye(size(Tuu,2))+( Heffectkk * Tuu )'* Heffectkk * Tuu ;
        value = value - Heffectkk' * Heffectkk * Tuu / Mpk;


    end
    gradT((uu-1)*Rx+[1:Rx],:) = value;
end


% for uu = 1:P
%     value = 0;
%     Tuu = T((uu-1)*Rx+[1:Rx],:);
%     Hdesireduu = Hdesired{uu};
%     Qzfuu = Qzf{uu};
%     for kk = 1:subcarriersK
%         Ruukk=0;
%         Fbar = kron(F(kk,startPoint),eye(Rx));
%         % Heffectkk = Fbar * Hdesireduu * Qzfuu;
%         Heffectkk = Fbar *Hdesireduu*Qzfuu* (Qzfuu'*Qzfuu)^(-1/2);
% 
%         eqchanneluukk = Heffectkk * Tuu;
%         combinertemp = inv(eqchanneluukk'*eqchanneluukk+SNR*eye(Rx))*eqchanneluukk';
%         eqsignaluukk = combinertemp * Heffectkk;
%         for ll = 1:P
%             Qzfll = Qzf{ll};
%             Tll = T((ll-1)*Rx+(1:Rx),:);
%             precoderllkk = Qzfll*(Qzfll'*Qzfll)^(-1/2)*Tll;
%             eqchannelllkk = Fbar *Hdesireduu* precoderllkk;
%             Ruukk = Ruukk + combinertemp *eqchannelllkk*eqchannelllkk'*combinertemp';
%         end
%         Ruukk = Ruukk+SNR*combinertemp*combinertemp'-eqsignaluukk*eqsignaluukk';  
% 
%         Mpk = SNR*eye(size(Tuu,2))+eqsignaluukk'*inv(Ruukk)* eqsignaluukk ;
%         value = value - Heffectkk' *inv(Ruukk)* Heffectkk * Tuu / Mpk;
% 
% 
%     end
%     gradT((uu-1)*Rx+[1:Rx],:) = value;
% end



end