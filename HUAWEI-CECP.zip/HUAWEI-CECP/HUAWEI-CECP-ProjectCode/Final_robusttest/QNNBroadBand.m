function [SumRate] = QNNBroadBand(SysPara,genieChanFreq)


Tx = SysPara.Tx;  % Transmit Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
weightLen = SysPara.weightLen;
Rx = SysPara.Rx;  % Receive Antennas
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
%% Tx-Rx Initialization
timePrecoderW = randn(weightLen*Tx,P*Nds) + 1j*randn(weightLen*Tx,P*Nds);
timePrecoderW = timePrecoderW/norm(timePrecoderW,'fro');
% RecFreq = randn(Rx,subcarriersK,P,Nds) + 1j*randn(Rx,subcarriersK,P,Nds);
%% Freqquency Doamin Processing
[sumRateFreq] = freqMMSE(SysPara,genieChanFreq);
%% QNN Training for Broadband
% [SumRate] = QNNMMSEBroadBand(SysPara,genieChanFreq,timePrecoderW);
[SumRate] = QNNPerfectMMSETrain(SysPara,genieChanFreq,timePrecoderW);
end




