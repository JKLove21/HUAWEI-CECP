function [capacitySingle,timePrecoder] = QRSingleImpulseUEPrecod(HtimeToep,SysPara)
%UNTITLED3 此处显示有关此函数的摘要
%   此处显示详细说明

Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
weightLen = SysPara.weightLen; % ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 minimum FIR Length
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio

global Hdesired Qzf startPoint Nds subcarriersK SNR P % Prepare for Manifold Optimization
Hdesired = cell(P,1);
Qzf = cell(P,1);
impulseShape = cell(P,1);
%% Impuse Center
startPoint = ceil((weightLen + tapsN-1)/2);
timePrecoder = zeros(weightLen * Tx, P*Nds);

[Q,R] = qr(HtimeToep'); % T^H = QR
Q1 = Q(:,1:Nds*P*(weightLen + tapsN-1)); % Squeeze Operation
R1 = R(1:Nds*P*(weightLen + tapsN-1),:); % Squeeze Operation

for uu = 1:P
    Rnew = R1;
    Rnew(:,(startPoint-1)*Nds*P + 1 + (uu-1)*Nds : (startPoint-1)*Nds*P + uu*Nds) = []; % Extract Operation
    Rnew = [Rnew,R1(:,(startPoint-1)*Nds*P + 1 + (uu-1)*Nds : (startPoint-1)*Nds*P + uu*Nds)]; % Shift Operation
    [Q2,~] = qr(Rnew); % Performe QR Again for the pth UT
    Qzfuu = Q1*Q2(:,end-Nds+1:end); % Optimal ISI and IUI Canceller
    Hdesireduu = HtimeToep((startPoint-1)*Nds*P + 1 + (uu-1)*Nds : (startPoint-1)*Nds*P + uu*Nds,:); % Desired Channel Components
    Hdesired{uu} = Hdesireduu;
    Qzf{uu} = Qzfuu;
end
%% Manifold Optimization for maximizing channel capacity
Tinitial = randn(Nds*P,Nds) + 1j*randn(Nds*P,Nds);
Tinitial = Tinitial/norm(Tinitial,'fro');
manifold = spherecomplexfactory(Nds*P,Nds);
problem.M = manifold;
problem.cost  = @objectFunSingleUEPrecod;
problem.egrad = @EuclideanGradTUEPrecod;
% checkgradient(problem);
Operation.maxiter = 20;
[T,cost,info,options] = conjugategradient(problem,Tinitial,Operation);

capacityManifoldCGMethod = [];
for ii = 1:length(info)
    capacityManifoldCGMethod = [capacityManifoldCGMethod,abs(info(ii).cost)];
end
capacitySingle = capacityManifoldCGMethod(end);
%% Return Time Precoder
for uu = 1:P
    timePrecoder(:,(uu-1)*Nds + [1:Nds]) = Qzf{uu} * T((uu-1)*Nds + [1:Nds],:);
    impulseShape{uu} = HtimeToep * Qzf{uu} * T((uu-1)*Nds + [1:Nds],:);
end

end

