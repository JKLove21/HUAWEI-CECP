function [value] = objectFunSingleUEPrecod(T)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
global  Nds subcarriersK SNR P Hdesired Qzf startPoint

F = dftmtx(subcarriersK);
value = 0;
for uu = 1:P
    Tuu = T((uu-1)*Nds+[1:Nds],:);
    Hdesireduu = Hdesired{uu};
    Qzfuu = Qzf{uu};
    for kk = 1:subcarriersK
        Fbar = kron(F(kk,startPoint),eye(Nds));
        Heffectkk = Fbar * Hdesireduu * Qzfuu;
        value = value - real(log2(det(  eye(Nds) + 1/SNR*Heffectkk * Tuu * (Heffectkk * Tuu)' )));
    end
end

end