function [EZFCapacity,EZFCapacityImperfect,chanEstNMSEEZF,EZFRealChan,EZFEstChan,ezfPrecoder] = EZF(SysPara,Hfreq,HfreqImperfect)
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Rati

% Hfreq = 1/sqrt(2)*(randn(Rx*P,Tx,subcarriersK) + 1j*randn(Rx*P,Tx,subcarriersK));
% SNR = 1/db2pow(10*log10(20.5));

EZFEquiChan = cell(P,subcarriersK);
EZFEquiChanImperfect = cell(P,subcarriersK);
EZFCapacity = 0;
EZFCapacityImperfect = 0;

ezfPrecoder=zeros(Tx,Nds*P,subcarriersK);

for kk = 1:subcarriersK
    Hv = [];
    for uu = 1:P
        channeluukk = squeeze(Hfreq((uu-1)*Rx + [1:Rx],:,kk));
        [~,~,V]=svd(channeluukk);
        Hv = [Hv;V(:,1:Nds)'];
    end
    temp = Hv'*inv(Hv*Hv');
    ezfPrecodertmp = temp/norm(temp,'fro');
    ezfPrecoder(:,:,kk)=ezfPrecodertmp;
end

%% DMRS
for kk=1:subcarriersK
    for uu=1:P
        channeluukk = squeeze(Hfreq((uu-1)*Rx + [1:Rx],:,kk)); % Imperfect Perfect Channel
        ezfPrecoderuu = ezfPrecoder(:,(uu-1)*Nds + [1:Nds],kk);
        tmpChanEquiperfect = channeluukk*ezfPrecoderuu;
        EZFEquiChan{uu,kk} = tmpChanEquiperfect;
    end
end

[chanEstNMSEEZF,EZFEstChan,EZFRealChan] = lsChannelEZF(SysPara,EZFEquiChan);


for kk=1:subcarriersK
    for uu=1:P
        channeluukk = squeeze(HfreqImperfect((uu-1)*Rx + [1:Rx],:,kk)); % Imperfect Perfect Channel
        ezfPrecoderuu = ezfPrecoder(:,(uu-1)*Nds + [1:Nds],kk);
        tmpChanEquiImperfect = channeluukk*ezfPrecoderuu;
        EZFEquiChanImperfect{uu,kk} = tmpChanEquiImperfect;
    end
end

[chanEstNMSEEZF_imperfect,EZFEstChan_imperfect,EZFRealChan_imperfect] = lsChannelEZF(SysPara,EZFEquiChanImperfect);


%% perfect channel 
for kk=1:subcarriersK
    for uu = 1:P

        channeluukk = squeeze(Hfreq((uu-1)*Rx + [1:Rx],:,kk)); 
        ezfPrecoderuu = ezfPrecoder(:,(uu-1)*Nds + [1:Nds],kk);

        tmpChanEqui = EZFRealChan{uu,kk};
        tmpChanEquiest=squeeze(EZFEstChan(uu,kk,:,:));
       
        combineruukk = inv(tmpChanEquiest'*tmpChanEquiest+SNR*eye(Nds))*tmpChanEquiest';
        eqsignaluukk = combineruukk*tmpChanEqui;

        InterUserdet = 0;
        for uubar = 1:P
            if uubar ~= uu
                ezfPrecoderuubar = ezfPrecoder(:,(uubar-1)*Nds + [1:Nds],kk);
                InterUserdet = InterUserdet + combineruukk * channeluukk * ezfPrecoderuubar * (combineruukk * channeluukk * ezfPrecoderuubar)';
            end
        end

        EZFCapacity = EZFCapacity + log2(det( eye(Nds)*combineruukk*combineruukk' + 1/SNR*(eqsignaluukk*eqsignaluukk'+InterUserdet) )/det(eye(Nds)*combineruukk*combineruukk' + 1/SNR*InterUserdet ));
        % EZFOriginal = EZFOriginal + log2(det( eye(Nds)*combineruukk*combineruukk' + 1/SNR*combineruukk*channeluukk*ezfPrecoderuu*ezfPrecoderuu'*channeluukk'*combineruukk' ));

    end
end
%% imperfect channel 
for kk=1:subcarriersK
    for uu = 1:P
        channeluukk = squeeze(HfreqImperfect((uu-1)*Rx + [1:Rx],:,kk));
        ezfPrecoderuu = ezfPrecoder(:,(uu-1)*Nds + [1:Nds],kk);

        tmpChanEqui = EZFRealChan_imperfect{uu,kk};
        tmpChanEquiest=squeeze(EZFEstChan_imperfect(uu,kk,:,:));
        
        combineruukk = inv( tmpChanEquiest'* tmpChanEquiest+SNR*eye(Nds))* tmpChanEquiest';
        eqsignaluukkImperfect = combineruukk* tmpChanEqui;

        InterUserdet = 0;
        for uubar = 1:P
            if uubar ~= uu
                ezfPrecoderuubar = ezfPrecoder(:,(uubar-1)*Nds + [1:Nds],kk);
                InterUserdet = InterUserdet + combineruukk*channeluukk * ezfPrecoderuubar * (combineruukk*channeluukk * ezfPrecoderuubar)';
            end
        end
        EZFCapacityImperfect = EZFCapacityImperfect + log2(det( eye(Nds)*combineruukk * combineruukk' + 1/SNR*(eqsignaluukkImperfect*eqsignaluukkImperfect'+InterUserdet) )/det( eye(Nds)*combineruukk*combineruukk'+  1/SNR*InterUserdet));

    end

end
end