function [equiChan] = euqiChanCheck(SysPara,timePrecoderW,genieChanFreq)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
Tx = SysPara.Tx;  % Transmit Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
Rx = SysPara.Rx;  % Receive Antennas
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
numRB = SysPara.numRB;
weightLen = SysPara.weightLen;
numSubCar = 12*numRB;

%% EquiChan Compute

DFTTrun = dftmtx(numSubCar);
equiChan = zeros(Rx,numSubCar,P,Nds);

for uu = 1:P
    for dd = 1:Nds
        counter = 0;
        for kk = 1:subcarriersK
            if kk <= numSubCar/2 || kk >= subcarriersK-numSubCar/2+1
                counter = counter + 1;
                equiChan(:,counter,uu,dd) = squeeze(genieChanFreq{uu}(kk,:,:))*kron(DFTTrun(counter,1:weightLen),eye(Tx))*timePrecoderW(:,(uu-1)*Nds + dd);
            end
        end
    end
end

end

