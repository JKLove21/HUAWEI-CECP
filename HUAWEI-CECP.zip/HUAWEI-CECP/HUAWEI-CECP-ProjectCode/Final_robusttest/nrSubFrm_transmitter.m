function [pilotout] = nrSubFrm_transmitter(SysPara,blockIndx)


%% Parameter
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
pilotType = 0;
cellId = blockIndx;

pilotout = cell(Nds,P);
%% Pilot Generation Orthogonal
disp('Orthogonal Pilot');
prbMapOutTmp = squeeze(pilotGene(SysPara,pilotType,cellId)); %���赥����type��6�û���cellId=1
counter = 0;
for uu = 1:P
    for dd = 1:Nds
        counter = counter + 1;
        pilotout{dd,uu} = prbMapOutTmp(:,counter);
    end
end
%% Pilot Generation Non-orthogonal
% disp('Non-Orthogonal Pilot');
% 
% counter = 0;
% for uu = 1:P
%     for dd = 1:Nds
%         counter = counter + 1;
%         cellId = (blockIndx - 1)*P*Nds + counter;
%         prbMapOutTmp = squeeze(pilotGene(SysPara,pilotType,cellId)); %���赥����type��6�û���cellId=1
%         pilotout{dd,uu} = prbMapOutTmp(:,counter);
%     end
% end

end