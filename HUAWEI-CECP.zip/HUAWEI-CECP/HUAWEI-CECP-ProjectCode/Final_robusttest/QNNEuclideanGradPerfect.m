function [GradienttimePrecoderW] = QNNEuclideanGradPerfect(timePrecoderW)
%UNTITLED4 此处显示有关此函数的摘要
%   此处显示详细说明
global subcarriersK Tx Nds P weightLen numSubCar genieChanFreq RecFreq

GradienttimePrecoderW = zeros(weightLen*Tx,P*Nds);
DFTmtxInput = dftmtx(numSubCar);
%% Euclidean Gradient
crossVecUser = zeros(weightLen*Tx,Nds,P);
RautoMtx = 0;
for uu = 1:P
    counter = 0;
    for kk = 1:subcarriersK
        if kk <= numSubCar/2 || kk >= subcarriersK-numSubCar/2+1
            counter = counter + 1;
            ChanneluukkBar = squeeze(genieChanFreq{uu}(kk,:,:)) * kron(DFTmtxInput(counter,1:weightLen),eye(Tx));
            recCoeffuudd = squeeze(RecFreq(:,kk,uu,:));
            tmp1 = ChanneluukkBar' * recCoeffuudd;
            crossVecUser(:,:,uu) = crossVecUser(:,:,uu) + tmp1;
            RautoMtx = RautoMtx + tmp1 * tmp1';
        end
    end
end


for uulocal = 1:P
    timePrecoderuulocalddlocal = timePrecoderW(:, (uulocal-1)*Nds+ [1:Nds]);
    GradienttimePrecoderW(:,(uulocal-1)*Nds+ [1:Nds]) = RautoMtx*timePrecoderuulocalddlocal - squeeze(crossVecUser(:,:,uulocal));
end

% for uulocal = 1:P
%     for ddlocal = 1:Nds
%         timePrecoderuulocalddlocal = timePrecoderW(:,(uulocal-1)*Nds + ddlocal);
%         tmp1 = 0;
%         tmp2 = 0;
%         counter = 0;
%         for kk = 1:subcarriersK
%             if kk <= numSubCar/2 || kk >= subcarriersK-numSubCar/2+1
%                 counter = counter + 1;
%                 ChanneluulocalkkBar = squeeze(genieChanFreq{uulocal}(kk,:,:)) * kron(DFTmtxInput(counter,1:weightLen),eye(Tx)); %Rx X Tx
%                 recCoeffuulocalddlocal = squeeze(RecFreq(:,kk,uulocal,ddlocal));  
%                 for uu = 1:P
%                     ChanneluukkBar = squeeze(genieChanFreq{uu}(kk,:,:)) * kron(DFTmtxInput(counter,1:weightLen),eye(Tx)); %Rx X Tx           
%                     for dd = 1:Nds
%                         recCoeffuudd = squeeze(RecFreq(:,kk,uu,dd));
%                         tmp1 = tmp1 + ChanneluukkBar' * recCoeffuudd * recCoeffuudd' * ChanneluukkBar;
%                     end
%                 end
%                 tmp2 = tmp2 +  ChanneluulocalkkBar' * recCoeffuulocalddlocal;
%             end
%         end
%         GradienttimePrecoderW(:,(uulocal-1)*Nds + ddlocal) = tmp1*timePrecoderuulocalddlocal - tmp2;
%     end
% end

end

