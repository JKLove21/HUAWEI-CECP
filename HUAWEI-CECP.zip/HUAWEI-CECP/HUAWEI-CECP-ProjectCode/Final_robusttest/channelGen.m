function [HtimeToep,HtimeToepImperfect,Hfreq, HfreqImperfect] = channelGen(SysPara,muMimoChanCell)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
channEstError = SysPara.channEstError;

% Htmp = zeros(Rx*P,Tx,tapsN);
% HtmpImperfect = zeros(Rx*P,Tx,tapsN);
% for uu=1:P
% for ii = 1:Rx
%     for jj = 1:Tx
%         Htmp((uu-1)*Rx + ii,jj,:) = sqrt(0.5/tapsN).*(randn(tapsN,1) + 1i*randn(tapsN,1));
%         HtmpImperfect(ii,jj,:) = squeeze(Htmp(ii,jj,:)) + sqrt(channEstError(uu)*0.5/tapsN).*(randn(tapsN,1) + 1i*randn(tapsN,1));
% %         bar(squeeze(abs([Htmp(ii,jj,:);HtmpImperfect(ii,jj,:)])).');
%     end
% end
% end

Htmp = zeros(Rx*P,Tx,tapsN);
HtmpImperfect = zeros(Rx*P,Tx,tapsN);
for uu = 1:P
    TimeChanRes = muMimoChanCell{uu};
    for tt = 1:Tx
        for rr = 1:Rx
            taps_tmp=squeeze(TimeChanRes(:,rr,tt));
            Htmp((uu-1)*Rx + rr,tt,:) = taps_tmp;
            HtmpImperfect((uu-1)*Rx + rr,tt,:) = squeeze(Htmp((uu-1)*Rx + rr,tt,:)) + sqrt(channEstError(uu)*0.5/tapsN).*(randn(tapsN,1) + 1i*randn(tapsN,1));
        end
    end
end

[HtimeToep, HtimeToepImperfect, Hfreq, HfreqImperfect] = gen_channel_noise(Htmp,HtmpImperfect,SysPara);

end

