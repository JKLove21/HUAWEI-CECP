function [Equichan] = PowTest(timePrecoderSingle,Hfreq,SysPara,weightLen)
%UNTITLED2 此处显示有关此函数的摘要
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Rati

DFTmtxInput = dftmtx(subcarriersK);
for uu = 1:P
    for kk = 1:subcarriersK
        channeluukk = squeeze(Hfreq((uu-1)*Rx + [1:Rx],:,kk));
        Equichan = channeluukk * kron(DFTmtxInput(kk,1:weightLen),eye(Tx)) * timePrecoderSingle(:,(uu-1)*Nds + [1:Nds]);
    end
end

end

