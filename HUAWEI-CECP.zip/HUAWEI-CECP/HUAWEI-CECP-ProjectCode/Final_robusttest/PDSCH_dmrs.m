function [r0,r1,r2] = PDSCH_dmrs(RBnum)
%  reference: subclause 7.4.1.1.1 (Sequence generation) of TS38.211

subCarNum = RBnum*12;

[Cinit0,Cinit1,Cinit2] = PDSDH_dmrs_Cinit;
c0 = NR_GoldSeq(subCarNum*2,Cinit0);
c1 = NR_GoldSeq(subCarNum*2,Cinit1);
c2 = NR_GoldSeq(subCarNum*2,Cinit2);
r0 = zeros(1,subCarNum);
r1 = zeros(1,subCarNum);
r2 = zeros(1,subCarNum);
for nn = 1:subCarNum
    r0(nn) = sqrt(1/2)*(1-2*c0(2*nn-1)+1j*(1-2*c0(2*nn)));
    r1(nn) = sqrt(1/2)*(1-2*c1(2*nn-1)+1j*(1-2*c1(2*nn)));
    r2(nn) = sqrt(1/2)*(1-2*c2(2*nn-1)+1j*(1-2*c2(2*nn)));
end

end

