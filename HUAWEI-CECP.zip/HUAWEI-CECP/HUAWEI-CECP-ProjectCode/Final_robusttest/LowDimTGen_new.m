function [HtimeToep,HtimeToepImperfect,Hfreq,HfreqImperfect] = LowDimTGen_new(Hfreq,HfreqImperfect,SysPara)

Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
dim = SysPara.SingleUserDim;
P = SysPara.P;    % User Terminals
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
channEstError = SysPara.channEstError;
subcarriersK = SysPara.subcarriersK;
Htmp = zeros(dim*P,Tx,tapsN);
HtmpImperfect = zeros(dim*P,Tx,tapsN);
for uu=1:P
    HtimeLowDimtmp = zeros(subcarriersK,dim,Tx);
    HfreqLowDim = zeros(dim,Tx,subcarriersK);
    Hfrequu=Hfreq((uu-1)*Rx+[1:Rx],:,:);
    CorrMat = zeros(Rx,Rx);
    % Calculate Hfreq
    for kk = 1:subcarriersK
        HfreqTmp = squeeze(Hfrequu(:,:,kk));
        CorrMat = CorrMat+HfreqTmp*HfreqTmp';
    end
    [~, ~, v] = svd(CorrMat);
    PrecodMat = v(:,1:dim)';
    for kk = 1:subcarriersK
        HfreqLowDim(:,:,kk) = PrecodMat*squeeze(Hfrequu(:,:,kk));
    end
    % Calculate HtimeLowDim
    for ii = 1:dim
        for jj = 1:Tx
            HtimeLowDimtmp(:,ii,jj) = ifft(HfreqLowDim(ii,jj,:),subcarriersK);
        end
    end
    HtimeLowDim = HtimeLowDimtmp(1:tapsN,:,:);

    for tt = 1:Tx
        for rr = 1:dim
            taps_tmp=squeeze(HtimeLowDim(:,rr,tt));
            Htmp((uu-1)*dim + rr,tt,:) = taps_tmp;
        end
    end
end

for uu=1:P
    HtimeLowDimtmp = zeros(subcarriersK,dim,Tx);
    HfreqLowDim = zeros(dim,Tx,subcarriersK);
    Hfrequu=HfreqImperfect((uu-1)*Rx+[1:Rx],:,:);
    CorrMat = zeros(Rx,Rx);
    % Calculate Hfreq
    for kk = 1:subcarriersK
        HfreqTmp = squeeze(Hfrequu(:,:,kk));
        CorrMat = CorrMat+HfreqTmp*HfreqTmp';
    end
    [~, ~, v] = svd(CorrMat);
    PrecodMat = v(:,1:dim)';
    for kk = 1:subcarriersK
        HfreqLowDim(:,:,kk) = PrecodMat*squeeze(Hfrequu(:,:,kk));
    end
    % Calculate HtimeLowDim
    for ii = 1:dim
        for jj = 1:Tx
            HtimeLowDimtmp(:,ii,jj) = ifft(HfreqLowDim(ii,jj,:),subcarriersK);
        end
    end
    HtimeLowDim = HtimeLowDimtmp(1:tapsN,:,:);

    for tt = 1:Tx
        for rr = 1:dim
            taps_tmp=squeeze(HtimeLowDim(:,rr,tt));
            HtmpImperfect((uu-1)*dim + rr,tt,:) = taps_tmp;
        end
    end
end





SysPara.Rx = dim;
[HtimeToep,HtimeToepImperfect,Hfreq,HfreqImperfect] = gen_channel_noise(Htmp,HtmpImperfect,SysPara);


% Verification Part
%-------------------------------------------------------------
% Rx = dim;
% Hfreq2 = zeros(Rx * P,Tx,SysPara.subcarriersK);
% for ii = 1:Rx * P
%     for jj = 1:Tx
%         Hfreq2(ii,jj,:) = fft(Htmp(ii,jj,:),SysPara.subcarriersK);
%     end
% end
% loss = 0;
% for i = 1:1024
%     loss = loss+sum(abs(squeeze(HfreqO(:,:,i))).^2,'all')-sum(abs(squeeze(Hfreq2(:,:,i))).^2,'all');
% end
% disp('信道能量差：')
% loss
%----------------------------------------------
end