function [value] = objectFunMulti(T)
%UNTITLED
global  Rx subcarriersK SNR P Hdesired Qzf pointSeq SysPara

dim = SysPara.SingleUserDim;
% global dim
Rx = dim;

F = dftmtx(subcarriersK);
value = 0;
for uu = 1:P
    Tuu = T((uu-1)*length(pointSeq)*Rx+(1:length(pointSeq)*Rx),:);
    % Hdesireduu = Hdesired{uu};
    Qzfuu = Qzf{uu};
    for kk = 1:subcarriersK
        Fbar = kron(F(kk,pointSeq),eye(Rx));
        % Heffectkk = Fbar * Hdesireduu * Qzfuu;
        Heffectkk = Fbar * (Qzfuu'*Qzfuu)^(-1/2);

        value = value - real(log2(det(  eye(Rx) + 1/SNR*Heffectkk * Tuu *(Heffectkk * Tuu)'  )));
    end
end

end
