clear all
close all
clear global
%% Construct Parameters

[SysPara] = ConstructParameters;
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio
channEstError = SysPara.channEstError;
%% Test Part
% [ceil((tapsN-1)/(Tx/(P*Rx)-1))+1:2:ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 + 40]
SICapa = [];
SICapaImperfect = [];
FIRLenRange = length(40:2:60); % Time domain FIR filter length range
MaximumEquivalentChannelLen = 8; % Compare the effect of equivalent channel length
MICapa = zeros(MaximumEquivalentChannelLen,FIRLenRange); % You can view the variation of channel capacity about MaximumEquivalentChannelLen and FIRLenRange
MICapaImperfect = zeros(MaximumEquivalentChannelLen,FIRLenRange);

MonteCarloNum = 1;
for testNum = 1:MonteCarloNum
    %% Global Seed
    rng(testNum);
    
%     [muMimoChanCell,~] = muMimoChan_interface(SysPara,chanTime); % Accept time domain channel (size == [subcarriersK Rx Tx P])
    % [muMimoChanCell,~] = muMimoChan_gen(SysPara); % Generate NRCDL Channel
%     load('muMimoChanCell.mat');
    counter = 0;
    for weightLen = 40:2:60
        counter = counter + 1;
        SysPara.weightLen = weightLen;
        %% Aggregated Block Toeplitz Channel Matrix T Generation
        [HtimeToep,Hfreq,HtimeToepImperfect, HfreqImperfect] = channelGen(SysPara);
        % [HtimeToep,Hfreq,HtimeToepImperfect, HfreqImperfect] = AggreTGen(muMimoChanCell,SysPara); % Generate T based on NRCDL Channel
        %% WMMSE
        % [WMMSECapacity,WMMSEEquiChan,WMMSECapacityImperfect,WMMSEEquiChanImperfect] = WMMSE(SysPara,Hfreq,HfreqImperfect);
        %% EZF
        [EZFCapacity,EZFEquiChan,EZFCapacityImperfect,EZFEquiChanImperfect] = EZF(SysPara,Hfreq,HfreqImperfect);
        %% 4RB EZF
        % [FourRBEZFCapacity,FourRBEZFEquiChan,FourRBEZFCapacityImperfect,FourRBEZFEquiChanImperfect] = FourRBEZF(SysPara,Hfreq,HfreqImperfect);
        %% Proposed Method for Single Impulse based on QR decomposition
        [capacitySingle,timePrecoderSingle,impulseShapeSingle,capacitySingleImperfect,startPoint] = QRSingleImpulse(HtimeToep,HtimeToepImperfect,SysPara);
        SICapa = [SICapa,capacitySingle];
        SICapaImperfect = [SICapaImperfect,capacitySingleImperfect];
        clear Hdesired Qzf
%         Equichan = PowTest(timePrecoderSingle,Hfreq,SysPara,weightLen);
        %% Proposed Method for Single Impulse based on QR decomposition
        for totalL = 2:2:MaximumEquivalentChannelLen % 2 means channel length is shortend to 2; 
            [capacityManifoldCGMethod,capacityMulti,timePrecoderMulti,impulseShapeMulti,capacityMultiImperfect,pointSeq] = QRMultiImpulse(HtimeToep,HtimeToepImperfect,totalL,SysPara);
            MICapa(totalL,counter) = capacityMulti;
            MICapaImperfect(totalL,counter) = capacityMultiImperfect;
        end
        disp(weightLen);
        disp(channEstError);
    end
end

StopTrigger = 1;