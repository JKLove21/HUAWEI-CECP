function [wFreq] = nrEqualizerSpaceTime(sigFreq,SysPara,pilot)
%UNTITLED2 此处显示有关此函数的摘要
%   此处显示详细说明
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
Rx = SysPara.Rx;  % Receive Antennas
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
numRB = SysPara.numRB;
numSubCar = 12*numRB;
% locFreq = [subcarriersK-numSubCar/2+1:subcarriersK,1:numSubCar/2];
locFreq = [1:numSubCar/2,subcarriersK-numSubCar/2+1:subcarriersK];
RecTapsQ = 4;

%% Equalization in time domain
disp('Spatial-time')
DFTmatrixInput = dftmtx(numSubCar);
wFreq = zeros(Rx,subcarriersK,P,Nds);

for uu = 1:P
    AutocorreMtx = zeros(RecTapsQ*Rx,RecTapsQ*Rx);
    wt = zeros(RecTapsQ*Rx,1);
    inputRecSig = transpose(squeeze(sigFreq(locFreq,uu,:)));
    [computeResult] = computeFHYdiagBlock(SysPara,DFTmatrixInput,inputRecSig,RecTapsQ);
    AutocorreMtx(:,:) = computeResult * computeResult';
    for dd = 1:Nds
        pilotSymbol = pilot{dd,uu}(locFreq);
        wt(:) = AutocorreMtx\(computeResult*conj(pilotSymbol));

        wtTmp = zeros(RecTapsQ,1);
        for mm = 1:Rx
            for taps = 1:RecTapsQ
                wtTmp(taps,1) = wt(mm + (taps-1)*Rx,1);
            end
            wFreq(mm,locFreq,uu,dd) = fft(wtTmp,numSubCar);
        end
    end

end

end

