function [timeWBiSec] = QNNBiSectionMethod(SysPara,genieChanFreq,RecFreq,timePrecoderW,pilotout)
%UNTITLED4 此处显示有关此函数的摘要
%   此处显示详细说明
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio
weightLen = SysPara.weightLen;
numRB = SysPara.numRB;
numSubCar = 12*numRB;
DFTmtxInput = dftmtx(subcarriersK)./sqrt(subcarriersK);



RtimeW = zeros(Tx*weightLen,Tx*weightLen,P,Nds);
crosstiemW = zeros(Tx*weightLen,P,Nds);
for uulocal = 1:P
    for ddlocal = 1:Nds
        Datakkddlocaluulocal = pilotout{ddlocal,uulocal};
        for kk = 1:subcarriersK
            %% PublicTerm
            publicTerm = 0;
            for uu = 1:P
                for dd = 1:Nds
                    Datakkdduu = pilotout{dd,uu}(kk);
                    publicTerm = publicTerm + timePrecoderW(:,(uu-1)*Nds + dd) * Datakkdduu;
                end
            end
            if kk <= numSubCar/2 || kk >= subcarriersK-numSubCar/2+1
                for uu = 1:P
                    ChanneluukkBar = squeeze(genieChanFreq{uu}(kk,:,:)) * kron(DFTmtxInput(kk,1:weightLen),eye(Tx)); %Rx X Tx
                    for dd = 1:Nds
                        Recppddkk = squeeze(RecFreq(:,kk,uu,dd))';
                        Datakkdduu = pilotout{dd,uu}(kk);
                        RtimeW(:,:,uulocal,ddlocal) = squeeze(RtimeW(:,:,uulocal,ddlocal)) + Datakkddlocaluulocal(kk)' * ChanneluukkBar' * Recppddkk' * Recppddkk * ChanneluukkBar * Datakkddlocaluulocal(kk);
                        crosstiemW(:,uulocal,ddlocal) = squeeze(crosstiemW(:,uulocal,ddlocal)) + Datakkddlocaluulocal(kk)'*ChanneluukkBar' * Recppddkk'* Datakkdduu - ...
                            Datakkddlocaluulocal(kk)' * ChanneluukkBar' * Recppddkk' * Recppddkk * ChanneluukkBar * (publicTerm - timePrecoderW(:,(uulocal-1)*Nds + ddlocal) * Datakkddlocaluulocal(kk));
                    end
                end
            end
        end
    end
end
    
lower = 0;
upper = 200;
errVal = 10;
while ((abs(errVal)>1e-2) && (upper >= 1e-10))
    lambdaVal = (lower + upper )/2;
    timeWBiSec = [];
    for uulocal = 1:P
        for ddlocal = 1:Nds
            timeWBiSec = [timeWBiSec,(squeeze(RtimeW(:,:,uulocal,ddlocal)) + lambdaVal * eye(Tx*weightLen))\squeeze(crosstiemW(:,uulocal,ddlocal))];
        end
    end    
    errVal = norm(timeWBiSec,'fro') - 1;
    if errVal > 0
        lower = lambdaVal;
    else
        upper = lambdaVal;
    end
end

end

