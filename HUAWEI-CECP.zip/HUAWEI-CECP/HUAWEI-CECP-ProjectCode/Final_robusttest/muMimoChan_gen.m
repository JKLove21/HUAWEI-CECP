function [mimoChanCell2,genieChanFreq,singularValueCell] = muMimoChan_gen(SysPara)
%
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
mimoChanCell = cell(P,Tx);
mimoChanCell2 = cell(P,1);
genieChanFreq = cell(P,1);
singularValueCell = cell(P,1);
T=subcarriersK;
% chanMtx = zeros(subcarriersK,Rx,Tx,P);
for uu = 1:P
    userSeed = 7*SysPara.Seed+42*uu+66;
    pulseInput = zeros(T,Tx);
    [mimoChan] = channel_gen(SysPara,userSeed);
    mimoChanCell(uu,:) = repmat({mimoChan},1,Tx);
    % nrCDL = mimoChan;
    for tt = 1:Tx
        pulseInput(1,:) = 0;
        pulseInput(1,tt) = 1;
        nrCDL = mimoChanCell{uu,tt};

        [pulseOutput(:,:,tt),PathGains,sampleTimes] = nrCDL(pulseInput);

    end


    mimoChanCell2{uu} = pulseOutput(1:tapsN,:,:);
    chanSingularValue = zeros(subcarriersK,min(Rx,Tx));
    [chanFreq] = getgenieChanFreq(SysPara,pulseOutput);
    for ll = 1:subcarriersK
        [~,S,~]=svd(reshape(chanFreq(ll,:,:),Rx,Tx));
        chanSingularValue(ll,:) = diag(S);
    end
    genieChanFreq{uu} = chanFreq;
    singularValueCell{uu} = chanSingularValue;
end


