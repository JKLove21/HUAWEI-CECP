function [computeResult] = computeFHYdiagBlock(SysPara,DFTmatrix,sigSymbol,RecTapsQ)
%sigSymbol: Nf X RxAnt
%   此处显示详细说明

Rx = SysPara.Rx;  % Receive Antennas
numRB = SysPara.numRB;
numSubCar = 12*numRB;

computeResult = zeros(RecTapsQ*Rx,numSubCar);
DFTtrun = DFTmatrix(:,1:RecTapsQ);
for nn = 1:Rx
    tmp = DFTtrun'*diag(sigSymbol(nn,:));
    for taps = 1:RecTapsQ
        computeResult((taps-1)*Rx + nn,:) = tmp(taps,:);
    end 
end

end

