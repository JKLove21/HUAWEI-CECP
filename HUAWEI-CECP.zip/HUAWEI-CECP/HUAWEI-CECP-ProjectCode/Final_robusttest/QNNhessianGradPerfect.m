function [hessianGradtimeW] = QNNhessianGradPerfect(timePrecoderW,eta)
%UNTITLED4 此处显示有关此函数的摘要
%   此处显示详细说明
global subcarriersK Tx Nds P weightLen numSubCar genieChanFreq RecFreq

hessianGradtimeW = [];
DFTmtxInput = dftmtx(numSubCar);

%% Euclidean Gradient
for uulocal = 1:P
    for ddlocal = 1:Nds
        tmp1 = 0;
        counter = 0;
        for kk = 1:subcarriersK
            if kk <= numSubCar/2 || kk >= subcarriersK-numSubCar/2+1
                counter = counter + 1;
                for uu = 1:P
                    ChanneluukkBar = squeeze(genieChanFreq{uu}(kk,:,:)) * kron(DFTmtxInput(counter,1:weightLen),eye(Tx)); %Rx X Tx           
                    for dd = 1:Nds
                        recCoeffuudd = squeeze(RecFreq(:,kk,uu,dd));
                        tmp1 = tmp1 + ChanneluukkBar' * recCoeffuudd * recCoeffuudd' * ChanneluukkBar;
                    end
                end
            end
        end
        hessianGradtimeW = blkdiag(hessianGradtimeW,tmp1);
    end
end

end

