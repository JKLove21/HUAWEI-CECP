function [HtimeToep,HtimeToepImperfect,Hfreq,HfreqImperfect] = gen_channel_noise(Htmp,HtmpImperfect,SysPara)

Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)

subcarriersK = SysPara.subcarriersK; % Subcarriers Number
weightLen = SysPara.weightLen;
channEstError=SysPara.channEstError;
%% The corresponding channel in frequency domain
Hfreq = zeros(Rx * P,Tx,subcarriersK);
for ii = 1:Rx * P
    for jj = 1:Tx
        Hfreq(ii,jj,:) = fft(Htmp(ii,jj,:),subcarriersK);
    end
end

% imperfect
HfreqImperfect = zeros(Rx * P,Tx,subcarriersK);
for ii = 1:Rx * P
    for jj = 1:Tx
        HfreqImperfect(ii,jj,:) = fft(HtmpImperfect(ii,jj,:),subcarriersK);
    end
end

% for uu=1:P
%     for ii = 1:Rx 
%         for jj = 1:Tx
%             HfreqImperfect((uu-1)*Rx+ii,jj,:) = Hfreq((uu-1)*Rx+ii,jj,:)+reshape(sqrt(channEstError(uu)*0.5).*(randn(subcarriersK,1) + 1i*randn(subcarriersK,1)),[1,1,subcarriersK]);
%         end
%     end
% end


%% ------Generate Toeplitz channel in time domain------
HblkTmp = zeros(Rx * P * tapsN,Tx);
for ii =1:tapsN
    HblkTmp([1:Rx * P] + (ii-1) * Rx * P, :) = Htmp(:,:,ii);  % H1,...,HL L = taps
end

HtimeToep = zeros(Rx * P * (weightLen + tapsN-1),Tx * weightLen);
% Hp = zeros(Rx * P * subcarriersK,Tx * subcarriersK);

for ii = 1:weightLen
    HtimeToep((ii-1) * Rx * P + [1:(Rx * P * tapsN)],(ii-1) * Tx + [1:Tx]) = HblkTmp(:,:); % circle H block tmp which is truncated by weightLen
end
% HtimeToep = HtimeToep(1:Rx * P*(weightLen + tapsN-1),:);

%imperfect
HblkTmpImperfect = zeros(Rx * P * tapsN,Tx);
for ii =1:tapsN
    HblkTmpImperfect([1:Rx * P] + (ii-1) * Rx * P, :) = HtmpImperfect(:,:,ii);  % H1,...,HL L = taps
end

HtimeToepImperfect = zeros(Rx * P * (weightLen + tapsN-1),Tx * weightLen);
% Hp = zeros(Rx * P * subcarriersK,Tx * subcarriersK);

for ii = 1:weightLen
    HtimeToepImperfect((ii-1) * Rx * P + [1:(Rx * P * tapsN)],(ii-1) * Tx + [1:Tx]) = HblkTmpImperfect(:,:); % circle H block tmp which is truncated by weightLen
end
%
% for ii = 1:(subcarriersK-tapsN)
%     Hp((ii-1)*Rx * P * tapsN +1:ii*Rx * P * tapsN,(ii-1)*Tx+1:ii*Tx)=HblkTmp;
% end
% for ii=subcarriersK-tapsN+1:subcarriersK
%     Hp((ii-1)*Rx * P +1:end , (ii-1)*Tx+1:ii*Tx)=HblkTmp(1:(subcarriersK-ii+1)*Rx * P,:);
%     Hp(1:(tapsN-(subcarriersK-ii+1))*Rx * P,(ii-1)*Tx+1:ii*Tx)=HblkTmp((tapsN-(subcarriersK-ii+1))*Rx * P * tapsN:end,:);
% end

% for kk=1:subcarriersK
%         Hfreq1(ii,jj,:) =kron(F(kk),eye(Rx))*HtimeToep
% end

% HtimeToepImperfect = HtimeToepImperfect(1:Rx * P*(weightLen + tapsN-1),:);
end