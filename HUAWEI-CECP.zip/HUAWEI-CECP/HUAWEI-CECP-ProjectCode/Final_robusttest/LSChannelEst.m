function [locseq,wf,wt] = LSChannelEst(currentRealUUNumber)
% recChannNoise (numRBExtnded*12*baseNumber,2,totalExtendedUE,Nr,Ns)

% Rx = SysPara.Rx;  % Receive Antennas
% Nds = SysPara.Nds; % Data Streams per User
% 
% LSEstChannel = zeros(numRBExtnded,totalExtendedUE,Rx,Nds);
% baseNumber = totalExtendedUE/24;
% 
% for uu = 1:totalExtendedUE
% 
%     currentbaseNumber = floor((uu-1)/24);
%     currentRealUUNumber = uu - currentbaseNumber*24;    
% 
%     switch currentRealUUNumber
%         case 1
%             locseq = [1,2,7,8];
%             wf = [1,1,1,1];
%             wt = [1,1];
%         case 2
%             locseq = [1,2,7,8];
%             wf = [1,-1,1,-1];
%             wt = [1,1];
%         case 7
%             locseq = [1,2,7,8];
%             wf = [1,1,1,1];
%             wt = [1,-1];
%         case 8
%             locseq = [1,2,7,8];
%             wf = [1,-1,1,-1];
%             wt = [1,-1];
%         case 13
%             locseq = [1,2,7,8];
%             wf = [1,1,-1,-1];
%             wt = [1,1];
%         case 14
%             locseq = [1,2,7,8];
%             wf = [1,-1,-1,1];
%             wt = [1,1];
%         case 19
%             locseq = [1,2,7,8];
%             wf = [1,1,-1,-1];
%             wt = [1,-1];
%         case 20
%             locseq = [1,2,7,8];
%             wf = [1,-1,-1,1];
%             wt = [1,-1];
%        case 3
%             locseq = [3,4,9,10];
%             wf = [1,1,1,1];
%             wt = [1,1];
%         case 4
%             locseq = [3,4,9,10];
%             wf = [1,-1,1,-1];
%             wt = [1,1];
%         case 9
%             locseq = [3,4,9,10];
%             wf = [1,1,1,1];
%             wt = [1,-1];
%         case 10
%             locseq = [3,4,9,10];
%             wf = [1,-1,1,-1];
%             wt = [1,-1];
%         case 15
%             locseq = [3,4,9,10];
%             wf = [1,1,-1,-1];
%             wt = [1,1];
%         case 16
%             locseq = [3,4,9,10];
%             wf = [1,-1,-1,1];
%             wt = [1,1];
%         case 21
%             locseq = [3,4,9,10];
%             wf = [1,1,-1,-1];
%             wt = [1,-1];
%         case 22
%             locseq = [3,4,9,10];
%             wf = [1,-1,-1,1];
%             wt = [1,-1];
%         case 5
%             locseq = [3,4,9,10];
%             wf = [1,1,1,1];
%             wt = [1,1];
%         case 6
%             locseq = [5,6,11,12];
%             wf = [1,-1,1,-1];
%             wt = [1,1];
%         case 11
%             locseq = [5,6,11,12];
%             wf = [1,1,1,1];
%             wt = [1,-1];
%         case 12
%             locseq = [5,6,11,12];
%             wf = [1,-1,1,-1];
%             wt = [1,-1];
%         case 17
%             locseq = [5,6,11,12];
%             wf = [1,1,-1,-1];
%             wt = [1,1];
%         case 18
%             locseq = [5,6,11,12];
%             wf = [1,-1,-1,1];
%             wt = [1,1];
%         case 23
%             locseq = [5,6,11,12];
%             wf = [1,1,-1,-1];
%             wt = [1,-1];
%         case 24
%             locseq = [5,6,11,12];
%             wf = [1,-1,-1,1];
%             wt = [1,-1];
% 
%     end
%     % for nn = 1:numRBExtnded
%     %     extractUURecY = squeeze( recChannNoise(12*(currentbaseNumber-1) + locseq + 36*(nn-1),:,uu,:,:) );
%     %     extractUURecYTmp = (squeeze(extractUURecY(:,1,:,:))*wt(1)./extendedPilotOutput(12*(currentbaseNumber-1) + locseq + 36*(nn-1),1,uu) + squeeze(extractUURecY(:,2,:,:))*wt(2)./extendedPilotOutput(12*(currentbaseNumber-1) + locseq + 36*(nn-1),2,uu))/2;
%     %     LSEstChannel(nn,uu,:,:) = ( squeeze(extractUURecYTmp(1,:,:))*wf(1) + squeeze(extractUURecYTmp(2,:,:))*wf(2) + squeeze(extractUURecYTmp(3,:,:))*wf(3) + squeeze(extractUURecYTmp(4,:,:))*wf(4))/4;
%     % end
% 
% end

switch currentRealUUNumber
    case 1
        locseq = [1,2,7,8];
        wf = [1,1,1,1];
        wt = [1,1];
    case 2
        locseq = [1,2,7,8];
        wf = [1,-1,1,-1];
        wt = [1,1];
    case 7
        locseq = [1,2,7,8];
        wf = [1,1,1,1];
        wt = [1,-1];
    case 8
        locseq = [1,2,7,8];
        wf = [1,-1,1,-1];
        wt = [1,-1];
    case 13
        locseq = [1,2,7,8];
        wf = [1,1,-1,-1];
        wt = [1,1];
    case 14
        locseq = [1,2,7,8];
        wf = [1,-1,-1,1];
        wt = [1,1];
    case 19
        locseq = [1,2,7,8];
        wf = [1,1,-1,-1];
        wt = [1,-1];
    case 20
        locseq = [1,2,7,8];
        wf = [1,-1,-1,1];
        wt = [1,-1];
   case 3
        locseq = [3,4,9,10];
        wf = [1,1,1,1];
        wt = [1,1];
    case 4
        locseq = [3,4,9,10];
        wf = [1,-1,1,-1];
        wt = [1,1];
    case 9
        locseq = [3,4,9,10];
        wf = [1,1,1,1];
        wt = [1,-1];
    case 10
        locseq = [3,4,9,10];
        wf = [1,-1,1,-1];
        wt = [1,-1];
    case 15
        locseq = [3,4,9,10];
        wf = [1,1,-1,-1];
        wt = [1,1];
    case 16
        locseq = [3,4,9,10];
        wf = [1,-1,-1,1];
        wt = [1,1];
    case 21
        locseq = [3,4,9,10];
        wf = [1,1,-1,-1];
        wt = [1,-1];
    case 22
        locseq = [3,4,9,10];
        wf = [1,-1,-1,1];
        wt = [1,-1];
    case 5
        locseq = [3,4,9,10];
        wf = [1,1,1,1];
        wt = [1,1];
    case 6
        locseq = [5,6,11,12];
        wf = [1,-1,1,-1];
        wt = [1,1];
    case 11
        locseq = [5,6,11,12];
        wf = [1,1,1,1];
        wt = [1,-1];
    case 12
        locseq = [5,6,11,12];
        wf = [1,-1,1,-1];
        wt = [1,-1];
    case 17
        locseq = [5,6,11,12];
        wf = [1,1,-1,-1];
        wt = [1,1];
    case 18
        locseq = [5,6,11,12];
        wf = [1,-1,-1,1];
        wt = [1,1];
    case 23
        locseq = [5,6,11,12];
        wf = [1,1,-1,-1];
        wt = [1,-1];
    case 24
        locseq = [5,6,11,12];
        wf = [1,-1,-1,1];
        wt = [1,-1];

end

end