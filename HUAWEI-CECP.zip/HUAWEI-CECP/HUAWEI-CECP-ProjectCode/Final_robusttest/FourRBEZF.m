function [EZFCapacity,EZFCapacityImperfect,chanEstNMSEFourRBEZF,fourRBRealChan,fourRBEstChan,ezfPrecoderkk] = FourRBEZF(SysPara,Hfreq,HfreqImperfect)
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Rati


EZFCapacity = 0;
EZFCapacityImperfect = 0;
EZFCapacity2 = 0;
EZFCapacityImperfect2 = 0;
EZFEquiChan = cell(P,subcarriersK);
EZFEquiChanImperfect = cell(P,subcarriersK);
RBSize = 48;
RBNum = floor(subcarriersK/RBSize);
%% Multi User Capacity(RB)
ezfPrecoderkk = zeros(Tx,Nds,P,subcarriersK);
for bb = 1:RBNum
    Hv = [];
    for uu = 1:P
        Ruubb = zeros(Tx,Tx);
        for ss = 1:RBSize
            channeluukk = squeeze(Hfreq((uu-1)*Rx + [1:Rx],:,(bb-1)*RBSize+ss));
            Ruubb = Ruubb + channeluukk'*channeluukk;
        end
        [~,~,V]=svd(Ruubb);
        Hv = [Hv;V(:,1:Nds)'];
    end
    temp = Hv'*inv(Hv*Hv');
    ezfPrecoder = temp/norm(temp,'fro');
    for uu = 1:P
        for ss = 1:RBSize
            ezfPrecoderkk(:,:,uu,(bb-1)*RBSize+ss) = ezfPrecoder(:,(uu-1)*Nds + [1:Nds]);
        end
    end
end

subcarrier_left=subcarriersK-RBNum*RBSize;
if subcarrier_left~=0
    Hv = [];
    for uu = 1:P
        Ruubb = zeros(Tx,Tx);
        for kk=1:subcarrier_left
            channeluukk = squeeze(Hfreq((uu-1)*Rx + [1:Rx],:,subcarriersK-subcarrier_left+kk));
            Ruubb = Ruubb + channeluukk'*channeluukk;
        end
        [~,~,V]=svd(Ruubb);
        Hv = [Hv;V(:,1:Nds)'];
    end
    temp = Hv'*inv(Hv*Hv');
    ezfPrecoder = temp/norm(temp,'fro');
    for uu = 1:P
        for kk=1:subcarrier_left
            ezfPrecoderkk(:,:,uu,subcarriersK-subcarrier_left+kk) = ezfPrecoder(:,(uu-1)*Nds + [1:Nds]);
        end
    end
end

%% DMRS
for kk=1:subcarriersK
    for uu=1:P
        channeluukk = squeeze(Hfreq((uu-1)*Rx + [1:Rx],:,kk)); % Imperfect Perfect Channel
        ezfPrecoderuu = squeeze(ezfPrecoderkk(:,:,uu,kk));
        tmpChanEquiperfect = channeluukk*ezfPrecoderuu;
        EZFEquiChan{uu,kk} = tmpChanEquiperfect;
    end
end

[chanEstNMSEFourRBEZF,fourRBEstChan,fourRBRealChan] = lsChannelFourRBEZF(SysPara,EZFEquiChan);


for kk = 1:subcarriersK
    for uu = 1:P
        channeluukk = squeeze(HfreqImperfect((uu-1)*Rx + [1:Rx],:,kk)); 
        ezfPrecoderuu = squeeze(ezfPrecoderkk(:,:,uu,kk));
        tmpChanEquiImperfect = channeluukk*ezfPrecoderuu;
        EZFEquiChanImperfect{uu,kk} = tmpChanEquiImperfect;
    end
end

[chanEstNMSEFourRBEZF_imperfect,fourRBEstChan_imperfect,fourRBRealChan_imperfect] = lsChannelFourRBEZF(SysPara,EZFEquiChanImperfect);



%% perfect channel 
for kk = 1:subcarriersK
    for uu = 1:P
        channeluukk = squeeze(Hfreq((uu-1)*Rx + [1:Rx],:,kk)); 
        ezfPrecoderuu = ezfPrecoderkk(:,:,uu,kk);
        
        tmpChanEqui = fourRBRealChan{uu,kk};
        tmpChanEquiest=squeeze(fourRBEstChan(uu,kk,:,:));

        combineruukk =  inv(tmpChanEquiest'* tmpChanEquiest+SNR*eye(Nds))* tmpChanEquiest';
        eqsignaluukk = combineruukk*tmpChanEqui;

        InterUserdet = 0;
        for uubar = 1:P
            if uubar ~= uu
                ezfPrecoderuubar = ezfPrecoderkk(:,:,uubar,kk);
                InterUserdet = InterUserdet + combineruukk * channeluukk * ezfPrecoderuubar * (combineruukk * channeluukk * ezfPrecoderuubar)';
            end
        end
        EZFCapacity = EZFCapacity + log2(det( eye(Nds)*combineruukk * combineruukk' + 1/SNR*(eqsignaluukk*eqsignaluukk'+InterUserdet) )/det(eye(Nds)*combineruukk*combineruukk' + 1/SNR*InterUserdet ));
        
    end
end

%% est channel 
for kk = 1:subcarriersK
    for uu = 1:P
        channeluukk = squeeze(HfreqImperfect((uu-1)*Rx + [1:Rx],:,kk)); 
        ezfPrecoderuu = ezfPrecoderkk(:,:,uu,kk);

        tmpChanEqui_real = fourRBRealChan_imperfect{uu,kk}; 
        tmpChanEquiest=squeeze(fourRBEstChan_imperfect(uu,kk,:,:));

        combineruukk = inv( tmpChanEquiest'* tmpChanEquiest+SNR*eye(Nds))* tmpChanEquiest';
        eqsignaluukk = combineruukk*tmpChanEqui_real;

        InterUserdet = 0;
        for uubar = 1:P
            if uubar ~= uu
                ezfPrecoderuubar = ezfPrecoderkk(:,:,uubar,kk);
                InterUserdet = InterUserdet + combineruukk*channeluukk * ezfPrecoderuubar * (combineruukk*channeluukk * ezfPrecoderuubar)';
            end
        end
        EZFCapacityImperfect = EZFCapacityImperfect + log2(det( eye(Nds)*combineruukk * combineruukk' + 1/SNR*(eqsignaluukk*eqsignaluukk'+InterUserdet) )/det(eye(Nds)*combineruukk*combineruukk' + 1/SNR*InterUserdet ));

    end
end

end