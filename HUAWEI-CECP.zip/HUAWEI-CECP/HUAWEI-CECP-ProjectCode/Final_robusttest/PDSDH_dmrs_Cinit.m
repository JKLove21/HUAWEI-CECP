function [Cinit0,Cinit1,Cinit2] = PDSDH_dmrs_Cinit
%  reference: subclause 7.4.1.1.1.1 (Pseudo-random sequence generation) of TS38.211

Ncsid = 0;  % n_csid = {0,1}
slotId = 0;
cellId = 1;
ofdmId = 2;

Cinit0 = mod((2^17*(14*slotId+ofdmId+1)*(2*cellId+1)+2^17*floor(0)+2*cellId+Ncsid),2^31);
Cinit1 = mod((2^17*(14*slotId+ofdmId+1)*(2*cellId+1)+2^17*floor(1/2)+2*cellId+1),2^31); %Ncsid = 1
Cinit2 = mod((2^17*(14*slotId+ofdmId+1)*(2*cellId+1)+2^17*floor(2/2)+2*cellId+Ncsid),2^31);
end

