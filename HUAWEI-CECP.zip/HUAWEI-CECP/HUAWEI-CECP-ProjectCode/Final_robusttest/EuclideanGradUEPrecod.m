function [value] = EuclideanGradUEPrecod(T)
%UNTITLED 此处显示有关此函数的摘要
% Heffectkk = Hbarpk Vp = Tuu

global Rx subcarriersK SNR QUE Hfrequu
F = dftmtx(subcarriersK);
value = 0;
for kk = 1:subcarriersK
    Huukk = squeeze(Hfrequu(:,:,kk));
    Fbar = kron(F(kk,1:QUE),eye(Rx));
    Tkk = Fbar * T;
    Mpk = SNR*eye(size(Tkk,2))+( Huukk' * Tkk )'* Huukk' * Tkk ;
    value = value - Fbar'* Huukk * Huukk' * Tkk / Mpk;
end


end

