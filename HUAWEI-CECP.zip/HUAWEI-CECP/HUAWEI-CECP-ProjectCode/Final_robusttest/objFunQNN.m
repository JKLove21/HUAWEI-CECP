function [MSEManOpt] = objFunQNN(timePrecoderW)

global subcarriersK Tx Rx Nds P weightLen numSubCar genieChanFreq pilotout RecFreq noise

DFTmtxInput = dftmtx(subcarriersK)./sqrt(subcarriersK);


yRecDL = zeros(subcarriersK,P,Rx);
MSEManOpt = 0;
for kk = 1:subcarriersK
    if kk <= numSubCar/2 || kk >= subcarriersK-numSubCar/2+1
        for uulocal = 1:P
            chanuukk = squeeze(genieChanFreq{uulocal}(kk,:,:))* kron(DFTmtxInput(kk,1:weightLen),eye(Tx)); %Rx X Tx
            for uu = 1:P
                for dd = 1:Nds
                    Datadduu = pilotout{dd,uu};
                    yRecDL(kk,uulocal,:) = squeeze(yRecDL(kk,uulocal,:)) + chanuukk * timePrecoderW(:,(uu-1)*Nds + dd) * Datadduu(kk);
                end
            end
            yRecDL(kk,uulocal,:) = squeeze(yRecDL(kk,uulocal,:)) + squeeze(noise(kk,uulocal,:));

            for ddlocal = 1:Nds
                recCoeffuudd = squeeze(RecFreq(:,kk,uulocal,ddlocal));
                pilotLocal = pilotout{ddlocal,uulocal};
                MSEManOpt = MSEManOpt + abs( recCoeffuudd'*squeeze(yRecDL(kk,uulocal,:)) - pilotLocal(kk) ).^2;
            end

        end
    end
end

end

