function [c] = NR_GoldSeq(Mpn,Cinit)
%  reference: subclause 5.2.1 (Pseudo-random sequence generation) of TS38.211

% initial x1 and x2 of length 31
Nc = 1600;
len = Mpn+Nc;
x1 = zeros(1,31+len);
x2 = zeros(1,31+len);
x1(1) = 1;
x2(1:31) = str2num(dec2bin(Cinit,31).').';
% generate x1 and x2 of length 31 + Nc
for nn = 1:len
    x1(nn+31) = mod(x1(nn+3)+x1(nn),2);
    x2(nn+31) = mod(x2(nn+3)+x2(nn+2)+x2(nn+1)+x2(nn),2);
end
% generate PN sequence c(n) of length Mpn
c = zeros(1,Mpn);
for nn = 1:Mpn
    c(nn) = mod(x1(nn+Nc)+x2(nn+Nc),2);
end
end

