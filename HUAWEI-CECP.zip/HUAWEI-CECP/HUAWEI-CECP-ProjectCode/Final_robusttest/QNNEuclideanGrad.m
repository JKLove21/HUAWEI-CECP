function [GradienttimePrecoderW] = QNNEuclideanGrad(timePrecoderW)
%UNTITLED2 此处显示有关此函数的摘要
%   此处显示详细说明
global subcarriersK Tx Nds P weightLen numSubCar genieChanFreq pilotout RecFreq noise

GradienttimePrecoderW = zeros(weightLen*Tx,P*Nds);
DFTmtxInput = dftmtx(subcarriersK)./sqrt(subcarriersK);

%% Euclidean Gradient
for uulocal = 1:P
    for ddlocal = 1:Nds
        Datakkddlocaluulocal = pilotout{ddlocal,uulocal};
        for kk = 1:subcarriersK
            %% PublicTerm
            publicTerm = 0;
            for uu = 1:P
                for dd = 1:Nds
                    Datakkdduu = pilotout{dd,uu}(kk);
                    publicTerm = publicTerm + timePrecoderW(:,(uu-1)*Nds + dd) * Datakkdduu;
                end
            end
            if kk <= numSubCar/2 || kk >= subcarriersK-numSubCar/2+1
                for uu = 1:P
                    ChanneluukkBar = squeeze(genieChanFreq{uu}(kk,:,:)) * kron(DFTmtxInput(kk,1:weightLen),eye(Tx)); %Rx X Tx
                    noiseTerm = squeeze(noise(kk,uu,:));
                    for dd = 1:Nds
                        Recppddkk = squeeze(RecFreq(:,kk,uu,dd));
                        Recppddkk = Recppddkk';
                        Datakkdduu = pilotout{dd,uu}(kk);
                        GradienttimePrecoderW(:,(uulocal-1)*Nds + ddlocal) = GradienttimePrecoderW(:,(uulocal-1)*Nds + ddlocal) + Datakkddlocaluulocal(kk)' * ChanneluukkBar' * Recppddkk' * Recppddkk * (ChanneluukkBar * publicTerm  ) - Datakkddlocaluulocal(kk)'*ChanneluukkBar' * Recppddkk'* Datakkdduu;
                    end
                end
            end
        end
    end
end

end

