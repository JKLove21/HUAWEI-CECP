function [outputArg1,outputArg2] = EZFTrain(SysPara,Hfreq)
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Rati

EZFCapacity = 0;
for kk = 1:subcarriersK
    ezfPrecoder = zeros(Tx,P*Nds);
    Hv = [];
    for uu = 1:P
        channeluukk = squeeze(genieChanFreq{uu}(kk,:,:));
        [~,~,V]=svd(channeluukk);
        Hv = [Hv;V(:,1:Nds)'];
    end
    temp = Hv'*inv(Hv*Hv');
    ezfPrecoder = temp/norm(temp,'fro');
    for uu = 1:P
        channeluukk = squeeze(Hfreq((uu-1)*Rx + [1:Rx],:,kk));
        ezfPrecoderuu = ezfPrecoder(:,(uu-1)*Nds + [1:Nds]);
        EZFCapacity = EZFCapacity + log2(det( eye(Rx) + 1/SNR*channeluukk*ezfPrecoderuu*ezfPrecoderuu'*channeluukk' ));
    end
end