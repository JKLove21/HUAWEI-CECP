function [capacitySingle,timePrecoder,capacitySingleImperfect,chanEstNMSESingle_imperfect,NMSESingleImpulseTimeDenoise_imperfect,singleEstChan_imperfect,singleRealChan_imperfect] = QRSingleImpulse(HtimeToep,HtimeToepImperfect,Hfreq,HfreqImperfect,SysPara)
%UNTITLED3 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
global Hdesired Qzf startPoint Rx subcarriersK SNR P % Prepare for Manifold Optimization SysPara
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
weightLen = SysPara.weightLen; % ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 minimum FIR Length
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio
channEstError=SysPara.channEstError;

Hdesired = cell(P,1);
Qzf = cell(P,1);
impulseShape = cell(P,1);
%% Impuse Center
startPoint = ceil((weightLen + tapsN-1)/2);
timePrecoder = zeros(weightLen * Tx, P*Nds);


% [R1] = generalized_blockQR(HtimeToep,weightLen,Rx*P);
% tmp = HtimeToep'/ R1 * inv(R1)'; % Eq.13
tmp = HtimeToep'*inv(HtimeToep*HtimeToep');

for uu = 1:P

    Qzfuu = tmp(:,(startPoint-1)*Rx*P + 1 + (uu-1)*Rx : (startPoint-1)*Rx*P + uu*Rx);
    Hdesireduu = HtimeToep((startPoint-1)*Rx*P + 1 + (uu-1)*Rx : (startPoint-1)*Rx*P + uu*Rx,:); % Desired Channel Components
    Hdesired{uu} = Hdesireduu;
    Qzf{uu} = Qzfuu;
end

%% Manifold Optimization for maximizing channel capacity
Tinitial = randn(Rx*P,Nds) + 1j*randn(Rx*P,Nds);
Tinitial = Tinitial/norm(Tinitial,'fro');
[capacityManifoldCGMethod,T] = MFGradDesSingle(Tinitial,SysPara);
capacitySingle_temp = capacityManifoldCGMethod(end);
%% Return Time Precoder
impulseShape_perfect=cell(P);impulseShape_imperfect=cell(P);
% load('timprecoder.mat');
for uu = 1:P
    timePrecoder(:,(uu-1)*Nds + [1:Nds]) =    Qzf{uu} * ((Qzf{uu}'*Qzf{uu})^(-1/2)) * T((uu-1)*Rx + [1:Rx],:);
    impulseShape_perfect{uu} = HtimeToep* Qzf{uu} * ((Qzf{uu}'*Qzf{uu})^(-1/2)) * T((uu-1)*Rx + [1:Rx],:);
    impulseShape_imperfect{uu} = HtimeToepImperfect * Qzf{uu} * ((Qzf{uu}'*Qzf{uu})^(-1/2)) * T((uu-1)*Rx + [1:Rx],:);
    %     impulseShape_perfect{uu} = HtimeToep* timePrecoder(:,(uu-1)*Nds + [1:Nds]);
    % impulseShape_imperfect{uu} = HtimeToepImperfect* timePrecoder(:,(uu-1)*Nds + [1:Nds]);
end


%% DMRS est
[chanEstNMSESingle,NMSESingleImpulseTimeDenoise,singleEstChan,singleRealChan] = lsChannelSingleImpulse(SysPara,impulseShape_perfect,startPoint);
[chanEstNMSESingle_imperfect,NMSESingleImpulseTimeDenoise_imperfect,singleEstChan_imperfect,singleRealChan_imperfect] = lsChannelSingleImpulse(SysPara,impulseShape_imperfect,startPoint);


%% Ƶ��Ԥ����
% fre_precoder=zeros(Tx,P*Nds,subcarriersK);
% tptemp=zeros(Tx,Nds,weightLen);
% eqchannel_energy=zeros(P,subcarriersK);
% for uu=1:P
%     TPtemp=timePrecoder(:,(uu-1)*Nds+[1:Nds]);
%     for ii = 1:weightLen
%         tptemp(:,:,ii)=TPtemp((ii-1)*Tx+[1:Tx],:);
%     end
%     %fft
%     for ii = 1:Tx
%         for jj = 1:Nds
%             fre_precoder(ii,(uu-1)*Nds+jj,:) = fft(tptemp(ii,jj,:),subcarriersK);
%         end
%     end
% end
% for kk=1:subcarriersK
%     for uu=1:P
%         energyprecoder(uu,kk)=norm(fre_precoder(:,(uu-1)*Nds+(1:Nds),kk),'fro');
%     end
% end
% 
% for kk=1:subcarriersK
%     for uu=1:P
%         channeluukk=squeeze(Hfreq((uu-1)*Nds+(1:Nds),:,kk));
%         precoderuukk=squeeze(fre_precoder(:,(uu-1)*Nds+(1:Nds),kk));
%         eqchanneluukk=channeluukk*precoderuukk;
%         eqchannel_energy(uu,kk)=trace(eqchanneluukk*eqchanneluukk');
%     end
% end
% eqtimechannel=HtimeToep* timePrecoder;
% for uu=1:P
%     for ll=1:weightLen+tapsN-1
%     Tchanneluukk(uu,ll)=trace(eqtimechannel((ll-1)*Rx*P+(uu-1)*Rx+[1:Rx],(uu-1)*Nds+[1:Nds])*eqtimechannel((ll-1)*Rx*P+(uu-1)*Rx+[1:Rx],(uu-1)*Nds+[1:Nds])');
%     end
% end
% for kk=1:subcarriersK
%     for uu=1:P
%         eqchanneluukk=squeeze(singleEstChan(uu,kk,:,:));
%         eqchannel_energy(uu,kk)=trace(eqchanneluukk*eqchanneluukk');
%     end
% end
% figure
% plot(eqchannel_energy(1,:));
% hold on
% plot(eqchannel_energy(2,:));
% 
% for kk=1:subcarriersK
%     for uu=1:P
%         eqchanneluukk=singleRealChan{uu,kk};
%         eqchannel_energy(uu,kk)=trace(eqchanneluukk*eqchanneluukk');
%     end
% end
% figure
% plot(eqchannel_energy(1,:));
% hold on
% plot(eqchannel_energy(2,:));
% for kk=1:subcarriersK
% 
%         eqchanneluukk1=Hfreq(1,2,kk);
%         eqchannel_energy1(kk)=trace(eqchanneluukk1*eqchanneluukk1');
% 
%         eqchanneluukk2=HfreqR(1,2,kk);
%         eqchannel_energy2(kk)=trace(eqchanneluukk2*eqchanneluukk2');
% end
% figure
% plot(eqchannel_energy1);
% hold on
% plot(eqchannel_energy2);
%% channel shift
Hfreqshift_perfect=cell(P,subcarriersK,P);
F = dftmtx(subcarriersK);
for ll=1:P
    for uu = 1:P
    extractImpulseuu = impulseShape_perfect{ll}((startPoint-1)*Rx*P  + (uu-1)*Rx + [1:Rx],:); % Extract Desired Channels
    extractImpulseuutail = [];
    for mm = startPoint+1:weightLen + tapsN -1
        extractImpulseuutail = [extractImpulseuutail;impulseShape_perfect{ll}((mm-1)*Rx*P + 1 + (uu-1)*Rx : (mm-1)*Rx*P + uu*Rx,:)];
    end
    extractImpulseuuhead = [];
    for bb = 1:startPoint -1
        extractImpulseuuhead = [extractImpulseuuhead;impulseShape_perfect{ll}((bb-1)*Rx*P + 1 + (uu-1)*Rx : (bb-1)*Rx*P + uu*Rx,:)];
    end
    shiftedEffcChan = [extractImpulseuu;extractImpulseuutail;extractImpulseuuhead];
    for kk = 1:subcarriersK
        Fbar = kron(F(kk,1:weightLen + tapsN -1),eye(Rx));
        Hfreqshift_perfect{uu,kk,ll} = Fbar * shiftedEffcChan;
    end
    end
end


Hfreqshift_imperfect=cell(P,subcarriersK,P);
F = dftmtx(subcarriersK);
for ll=1:P
    for uu = 1:P
    extractImpulseuu = impulseShape_imperfect{ll}((startPoint-1)*Rx*P  + (uu-1)*Rx + [1:Rx],:); % Extract Desired Channels
    extractImpulseuutail = [];
    for mm = startPoint+1:weightLen + tapsN -1
        extractImpulseuutail = [extractImpulseuutail;impulseShape_imperfect{ll}((mm-1)*Rx*P + 1 + (uu-1)*Rx : (mm-1)*Rx*P + uu*Rx,:)];
    end
    extractImpulseuuhead = [];
    for bb = 1:startPoint -1
        extractImpulseuuhead = [extractImpulseuuhead;impulseShape_imperfect{ll}((bb-1)*Rx*P + 1 + (uu-1)*Rx : (bb-1)*Rx*P + uu*Rx,:)];
    end
    shiftedEffcChan = [extractImpulseuu;extractImpulseuutail;extractImpulseuuhead];
    for kk = 1:subcarriersK
        Fbar = kron(F(kk,1:weightLen + tapsN -1),eye(Rx));
        Hfreqshift_imperfect{uu,kk,ll} = Fbar * shiftedEffcChan;
    end
    end
end

%% perfect Channel
capacitySingle = 0;
F=dftmtx(subcarriersK);
for kk=1:subcarriersK
    for uu=1:P
        Ruukk=zeros(Nds,Nds);
        % channeluukk=squeeze(Hfreq((uu-1)*Rx+(1:Rx),:,kk));
        % precoderuukk=squeeze(fre_precoder(:,(uu-1)*Nds+(1:Nds),kk));

        eqchanneluukk_real = Hfreqshift_perfect{uu,kk,uu};
        eqchanneluukk_est=squeeze(singleEstChan(uu,kk,:,:));

        combineruukk=inv(eqchanneluukk_est'*eqchanneluukk_est+SNR*eye(Nds))*eqchanneluukk_est';
        eqsignaluukk=combineruukk*eqchanneluukk_real;
        combinertemp=combineruukk*combineruukk';

        for ll = 1:P
            % precoderllkk = squeeze(fre_precoder(:,(ll-1)*Nds + [1:Nds],kk));
            % Ruukk = Ruukk + combineruukk*channeluukk*precoderllkk*precoderllkk'*channeluukk'*combineruukk';

            eqchannelllkk=Hfreqshift_perfect{uu,kk,ll};
            Ruukk = Ruukk + combineruukk* eqchannelllkk* eqchannelllkk'*combineruukk';
        end

        Ruukk = Ruukk+SNR*combinertemp-eqsignaluukk*eqsignaluukk';

       capacitySingle=capacitySingle+real(log2(det( eye(Nds) + eqsignaluukk'*inv(Ruukk)*eqsignaluukk )));

    end
end




%% imperfect Channel
capacitySingleImperfect = 0;

for kk=1:subcarriersK
    for uu=1:P
        Ruukk=zeros(Nds,Nds);
        % channeluukk=squeeze(HfreqImperfect((uu-1)*Rx+(1:Rx),:,kk))  ;
        % precoderuukk=squeeze(fre_precoder(:,(uu-1)*Nds+(1:Nds),kk)) ;

        eqchanneluukk_real = Hfreqshift_imperfect{uu,kk,uu};
        eqchanneluukk_est=squeeze(singleEstChan_imperfect(uu,kk,:,:));
        
        combineruukk=inv(eqchanneluukk_est'*eqchanneluukk_est+SNR*eye(Nds))*eqchanneluukk_est';
        eqsignaluukk = combineruukk*eqchanneluukk_real;
        combinertemp = combineruukk*combineruukk' ;

        for ll = 1:P

            % precoderllkk = squeeze(fre_precoder(:,(ll-1)*Nds + [1:Nds],kk));
            % Ruukk = Ruukk + combineruukk*channeluukk*precoderllkk*precoderllkk'*channeluukk'*combineruukk';

            eqchannelllkk=Hfreqshift_imperfect{uu,kk,ll};
            Ruukk = Ruukk + combineruukk* eqchannelllkk* eqchannelllkk'*combineruukk'; 

        end
        Ruukk = Ruukk+SNR*combinertemp-eqsignaluukk*eqsignaluukk';

        capacitySingleImperfect=capacitySingleImperfect+real(log2(det( eye(Nds) + eqsignaluukk'*inv(Ruukk)*eqsignaluukk )));

    end
end




%% Test Impuse Position
% capacityPos = [];
% for startPoint = 1:weightLen + tapsN-1
% % startPoint = ceil((weightLen + tapsN-1)/2);
%     timePrecoder = zeros(weightLen * Tx, P*Nds);
% 
%     [Q,R] = qr(HtimeToep'); % T^H = QR
%     Q1 = Q(:,1:Rx*P*(weightLen + tapsN-1)); % Squeeze Operation
%     R1 = R(1:Rx*P*(weightLen + tapsN-1),:); % Squeeze Operation
% 
%     for uu = 1:P
%         Rnew = R1;
%         Rnew(:,(startPoint-1)*Rx*P + 1 + (uu-1)*Rx : (startPoint-1)*Rx*P + uu*Rx) = []; % Extract Operation
%         Rnew = [Rnew,R1(:,(startPoint-1)*Rx*P + 1 + (uu-1)*Rx : (startPoint-1)*Rx*P + uu*Rx)]; % Shift Operation
%         [Q2,~] = qr(Rnew); % Performe QR Again for the pth UT
%         Qzfuu = Q1*Q2(:,end-Rx+1:end); % Optimal ISI and IUI Canceller
%         Hdesireduu = HtimeToep((startPoint-1)*Rx*P + 1 + (uu-1)*Rx : (startPoint-1)*Rx*P + uu*Rx,:); % Desired Channel Components
%         Hdesired{uu} = Hdesireduu;
%         Qzf{uu} = Qzfuu;
%     end
%     %% Manifold Optimization for maximizing channel capacity
%     Tinitial = randn(Rx*P,Nds) + 1j*randn(Rx*P,Nds);
%     Tinitial = Tinitial/norm(Tinitial,'fro');
%     [capacityManifoldCGMethod,T] = MFGradDesSingle(Tinitial,SysPara);
%     capacitySingle = capacityManifoldCGMethod(end);
%     capacityPos = [capacityPos,capacitySingle];
%     %% Return Time Precoder
%     for uu = 1:P
%         timePrecoder(:,(uu-1)*Nds + [1:Nds]) = Qzf{uu} * T((uu-1)*Rx + [1:Rx],:);
%     end
% end

end

