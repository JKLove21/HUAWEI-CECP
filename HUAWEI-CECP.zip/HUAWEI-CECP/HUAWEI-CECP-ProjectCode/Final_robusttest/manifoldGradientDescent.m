function [T,capacityManifoldCGMethod] = manifoldGradientDescent(Htime,F,pointSeq,Tinitial)

global  Rx P Nds

manifold = spherecomplexfactory(length(pointSeq)*Rx*P,Nds);
problem.M = manifold;
problem.cost  = @objectFun;
% problem.egrad = @EuclideanGradT;
% checkgradient(problem);
[T,cost,info,options] = conjugategradient(problem,Tinitial);

capacityManifoldCGMethod = [];
for ii = 1:length(info)
    capacityManifoldCGMethod = [capacityManifoldCGMethod,abs(info(ii).cost)];
end

% [T,cost,info,options] = rlbfgs(problem,Tinitial);
% 
% capacityManifoldBFGSMethod = [];
% for ii = 1:length(info)
%     capacityManifoldBFGSMethod = [capacityManifoldBFGSMethod,abs(info(ii).cost)];
% end
% 
% [T,cost,info,options] = steepestdescent(problem,Tinitial);
% 
% capacityManifoldSDMethod = [];
% for ii = 1:length(info)
%     capacityManifoldSDMethod = [capacityManifoldSDMethod,abs(info(ii).cost)];
% end

end

