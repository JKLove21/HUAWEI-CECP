function [equOutUser,wFreq] = nrEqualizerSpaceTimeVer2(sigFreq,frameCfg,simCfg,nodeCfg,bpParams,pilot)
% ***************************************
% copyright - CSRL@Fudan,2020/08/09
% ************************************
numSlot = frameCfg.numSlotPerSubfrm;
numSymPerSlot = frameCfg.numOFDMsymPerSlot;
numSymPerSubfrm = numSymPerSlot*numSlot;
DmrsPos0 = frameCfg.dmrsSymPos0;
numDmrsSymPerSlot = frameCfg.numDmrsSymPerSlot;
numRxAnt = simCfg.numRxAnt;
numUser = bpParams.K;
numRB = nodeCfg.numRB;     
numSubCarPerRB = frameCfg.numSubCarPerRB;
numSubCar = numSubCarPerRB*numRB;
Nf = frameCfg.Nf;
Nfft = 512;
tapsN = simCfg.tapsN;
locFreq = [1:numSubCar/2,Nf-numSubCar/2+1:Nf];
pilotNum = simCfg.pilotNum;

%% Equalization in time domain
disp('Spatial-time')
equOutUser = zeros(Nf,numUser,pilotNum);       

wt = zeros(tapsN*numRxAnt,numUser);
wFreq = zeros(numRxAnt,Nf,numUser);
Y = zeros(Nfft,numRxAnt,pilotNum);
Ydata = zeros(Nfft,numRxAnt);
Ry = zeros(numRxAnt,numRxAnt,Nfft);

Rcolone = zeros(tapsN*numRxAnt,numRxAnt,pilotNum);
RfftResult = zeros(numRxAnt,numRxAnt,Nfft);
pilotSymbol = zeros(Nfft,1);
r = zeros(tapsN*numRxAnt,pilotNum);
rmean = zeros(tapsN*numRxAnt,1);
rfftResult = zeros(numRxAnt,Nfft);
powNoiseLoad = 0.1;

for uu = 1:numUser
    for ll = 1:pilotNum
        %% Get Y
        % 导频处接收信号Y获取、中间补零
        Y([1:numSubCar/2,Nfft-numSubCar/2+1:Nfft],:,ll) = squeeze(sigFreq(:,uu,locFreq,ll)).';%sigFreq：Nr,UEnum,Nf,pilotNum

        %% Compute Ry        
        for kk = 1:Nfft
            if kk<=numSubCar/2 || kk>=Nfft-numSubCar/2+1
               Ry(:,:,kk) = squeeze(Y(kk,:,ll)).'*conj(squeeze(Y(kk,:,ll)));
            else
               Ry(:,:,kk) = powNoiseLoad * eye(numRxAnt); %对角加载
            end
        end

        %% Compute R
        % 计算块矩阵R的第一列Rcolone（第一行的共轭转置得出）
        for i = 1:numRxAnt
            for j = 1:numRxAnt
                if i<=j 
                   RfftResult(i,j,:) = fft(squeeze(Ry(i,j,:)),Nfft); 
                % Ry(k)共轭对称，利用复共轭的DFT性质
                else 
                   RfftResult(i,j,1)=conj(squeeze(RfftResult(j,i,1)));
                   RfftResult(i,j,2:Nfft)=conj(flipud(squeeze(RfftResult(j,i,2:end))));
                end    
                for nn = 1:tapsN
                    %R(i,(nn-1)*numRxAnt+j,ll)=RfftResult(i,j,nn);%第一行
                    Rcolone((nn-1)*numRxAnt+j,i,ll)=conj(RfftResult(i,j,nn)); %取前n点，共轭转置变为第一列块元素插入
                end
            end
        end


        %% Get pilotSymbol
        pilotSymbol([1:numSubCar/2,Nfft-numSubCar/2+1:Nfft]) = squeeze(pilot(locFreq,uu,ll)); 

        %% Compute r  
        for rr = 1:numRxAnt
            rfftResult(rr,:) = fft(squeeze(Y(:,rr,ll)).*conj(squeeze(pilotSymbol(:))),Nfft);
            rfftResult(rr,2:Nfft)= fliplr(rfftResult(rr,2:Nfft));
            for nn = 1:tapsN  
                r((nn-1)*numRxAnt+rr,ll)=rfftResult(rr,nn);  %取前n点插入
            end
        end
    end 

    %% Compute Wt
    tmp1 = 0;
    tmp2 = 0;
    for ll = 1:pilotNum
        tmp1 = tmp1 + Rcolone(:,:,ll);
        tmp2 = tmp2 + r(:,ll);
    end   
    Rcolonemean = tmp1/pilotNum;%+ powNoiseLoad * eye(numRxAnt);%对角加载
    rmean(:) = tmp2/pilotNum;
    wt(:,uu) = block_levinson(rmean(:), Rcolonemean);
    %% Compute Wf
    wtFFT = zeros(tapsN,1);
    for mm = 1:numRxAnt
        for taps = 1:tapsN
            wtFFT(taps,1) = wt(mm + (taps-1)*numRxAnt,uu);
        end
        wf(mm,:,uu) = fft(wtFFT,Nfft);
    end
    
  %% Compute equOutUser Nfft点
  for ll = 1:pilotNum
    Ydata([1:numSubCar/2,Nfft-numSubCar/2+1:Nfft],:) = squeeze(sigFreq(:,uu,locFreq,ll)).';
    [computeResultData] = computeFHYdiagBlock2(frameCfg,simCfg,dftmtx(Nfft),Ydata,tapsN);
    dataSym = conj(computeResultData'*wt(:,uu));
    equOutUser([1:Nfft/2,end-Nfft/2+1:end],uu,ll) = dataSym;
  end
end
wFreq(:,1:numSubCar/2,:) = wf(:,1:numSubCar/2,:);
wFreq(:,Nf-numSubCar/2 +1:Nf,:) = wf(:,Nfft-numSubCar/2+1:Nfft,:);
end

            
           
  
           
    