function [ChanEstOutput_new] = LSChannelEst2(SysPara,pilotOutput,EquiChan)

Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio
ExtendedPilotIdx = SysPara.ExtendedPilotIdx;

numRB = floor(subcarriersK/12);
[r0,r1,r2] = PDSCH_dmrs(numRB);

% if ExtendedPilotIdx == 1
%     ChanEstOutput = zeros(P,floor(numRB/2),Rx,Nds);
%     for nn = 1:numRB/2
%         for uu = 1:P
%             currentuuCDMGroup = floor((uu-1)/16); % 0,1,2 three groups
%             if currentuuCDMGroup == 0
%                 deltaoffset = 0;
%                 for ll = 1:2
%                     for kbar = 1:8
%                         if kbar <=4
%                             noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,Nds) + 1j*randn(Rx,Nds))./r0(8*(nn-1) + kbar);
%                             currentChan = EquiChan{uu,24*(nn-1) + deltaoffset + kbar};
%                             ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
%                         else
%                             noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,Nds) + 1j*randn(Rx,Nds))./r0(8*(nn-1) + kbar);
%                             currentChan = EquiChan{uu,24*(nn-1) + deltaoffset + kbar + 8};
%                             ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
%                         end
%                     end
%                 end
%                 ChanEstOutput(uu,nn,:,:) = ChanEstOutput(uu,nn,:,:)./16;
%             elseif currentuuCDMGroup == 1
%                 deltaoffset = 4;
%                 for ll = 1:2
%                     for kbar = 1:8
%                         if kbar <=4
%                             noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,Nds) + 1j*randn(Rx,Nds))./r1(8*(nn-1) + kbar);
%                             currentChan = EquiChan{uu,24*(nn-1) + deltaoffset + kbar};
%                             ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
%                         else
%                             noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,Nds) + 1j*randn(Rx,Nds))./r1(8*(nn-1) + kbar);
%                             currentChan = EquiChan{uu,24*(nn-1) + deltaoffset + kbar + 8};
%                             ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
%                         end
%                     end
%                 end
%                 ChanEstOutput(uu,nn,:,:) = ChanEstOutput(uu,nn,:,:)./16;
%             else
%                 deltaoffset = 8;
%                 for ll = 1:2
%                     for kbar = 1:8
%                         if kbar <=4
%                             noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,Nds) + 1j*randn(Rx,Nds))./r2(8*(nn-1) + kbar);
%                             currentChan = EquiChan{uu,24*(nn-1) + deltaoffset + kbar};
%                             ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
%                         else
%                             noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,Nds) + 1j*randn(Rx,Nds))./r2(8*(nn-1) + kbar);
%                             currentChan = EquiChan{uu,24*(nn-1) + deltaoffset + kbar + 8};
%                             ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
%                         end
%                     end
%                 end
%                 ChanEstOutput(uu,nn,:,:) = ChanEstOutput(uu,nn,:,:)./16;
%             end
%         end
%     end
% else
%     ChanEstOutput = zeros(P,floor(numRB/4),Rx,Nds);
%     for nn = 1:numRB/4
%         for uu = 1:P
%             currentuuCDMGroup = floor((uu-1)/32); % 0,1,2 three groups
%             if currentuuCDMGroup == 0
%                 deltaoffset = 0;
%                 for ll = 1:2
%                     for kbar = 1:16
%                         if kbar <=8
%                             noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,Nds) + 1j*randn(Rx,Nds))./r0(16*(nn-1) + kbar);
%                             currentChan = EquiChan{uu,48*(nn-1) + deltaoffset + kbar};
%                             ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
%                         else
%                             noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,Nds) + 1j*randn(Rx,Nds))./r0(16*(nn-1) + kbar);
%                             currentChan = EquiChan{uu,48*(nn-1) + deltaoffset + kbar + 16};
%                             ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
%                         end
%                     end
%                 end
%                 ChanEstOutput(uu,nn,:,:) = ChanEstOutput(uu,nn,:,:)./32;
% 
%             elseif currentuuCDMGroup == 1
%                 deltaoffset = 8;
%                 for ll = 1:2
%                     for kbar = 1:16
%                         if kbar <=8
%                             noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,Nds) + 1j*randn(Rx,Nds))./r1(16*(nn-1) + kbar);
%                             currentChan = EquiChan{uu,48*(nn-1) + deltaoffset + kbar};
%                             ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
%                         else
%                             noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,Nds) + 1j*randn(Rx,Nds))./r1(16*(nn-1) + kbar);
%                             currentChan = EquiChan{uu,48*(nn-1) + deltaoffset + kbar + 16};
%                             ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
%                         end
%                     end
%                 end
%                 ChanEstOutput(uu,nn,:,:) = ChanEstOutput(uu,nn,:,:)./32;
%             else
%                 deltaoffset = 16;
%                 for ll = 1:2
%                     for kbar = 1:16
%                         if kbar <=8
%                             noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,Nds) + 1j*randn(Rx,Nds))./r2(16*(nn-1) + kbar);
%                             currentChan = EquiChan{uu,48*(nn-1) + deltaoffset + kbar};
%                             ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
%                         else
%                             noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,Nds) + 1j*randn(Rx,Nds))./r2(16*(nn-1) + kbar);
%                             currentChan = EquiChan{uu,48*(nn-1) + deltaoffset + kbar + 16};
%                             ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
%                         end
%                     end
%                 end
%                 ChanEstOutput(uu,nn,:,:) = ChanEstOutput(uu,nn,:,:)./32;
%             end
%         end
%     end
% end

EquiChan_new=cell(P*Nds,subcarriersK);

for kk = 1:subcarriersK
    for uu=1:P
        for ss=1:Nds
            EquiChan_new{(uu-1)*Nds+ss,kk}=EquiChan{uu,kk}(:,ss);
        end
    end
end


if ExtendedPilotIdx == 1
    ChanEstOutput = zeros(P*Nds,floor(numRB/2),Rx,1);
    for nn = 1:numRB/2
        for uu = 1:P*Nds
            currentuuCDMGroup = floor((uu-1)/16); % 0,1,2 three groups
            if currentuuCDMGroup == 0
                deltaoffset = 0;
                for ll = 1:2
                    for kbar = 1:8
                        if kbar <=4
                            noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,1) + 1j*randn(Rx,1))./r0(8*(nn-1) + kbar);
                            % noiseGene =0;
                            currentChan = EquiChan_new{uu,24*(nn-1) + deltaoffset + kbar};
                            ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
                        else
                            noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,1) + 1j*randn(Rx,1))./r0(8*(nn-1) + kbar);
                            % noiseGene =0;
                            currentChan = EquiChan_new{uu,24*(nn-1) + deltaoffset + kbar + 8};
                            ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
                        end
                    end
                end
                ChanEstOutput(uu,nn,:,:) = ChanEstOutput(uu,nn,:,:)./16;
            elseif currentuuCDMGroup == 1
                deltaoffset = 4;
                for ll = 1:2
                    for kbar = 1:8
                        if kbar <=4
                            noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,1) + 1j*randn(Rx,1))./r1(8*(nn-1) + kbar);
                            % noiseGene =0;
                            currentChan = EquiChan_new{uu,24*(nn-1) + deltaoffset + kbar};
                            ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
                        else
                            noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,1) + 1j*randn(Rx,1))./r1(8*(nn-1) + kbar);
                            % noiseGene =0;
                            currentChan = EquiChan_new{uu,24*(nn-1) + deltaoffset + kbar + 8};
                            ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
                        end
                    end
                end
                ChanEstOutput(uu,nn,:,:) = ChanEstOutput(uu,nn,:,:)./16;
            else
                deltaoffset = 8;
                for ll = 1:2
                    for kbar = 1:8
                        if kbar <=4
                            noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,1) + 1j*randn(Rx,1))./r2(8*(nn-1) + kbar);
                            % noiseGene =0;
                            currentChan = EquiChan_new{uu,24*(nn-1) + deltaoffset + kbar};
                            ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
                        else
                            noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,1) + 1j*randn(Rx,1))./r2(8*(nn-1) + kbar);
                            % noiseGene =0;
                            currentChan = EquiChan_new{uu,24*(nn-1) + deltaoffset + kbar + 8};
                            ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
                        end
                    end
                end
                ChanEstOutput(uu,nn,:,:) = ChanEstOutput(uu,nn,:,:)./16;
            end
        end
    end
    ChanEstOutput_new=zeros(P,floor(numRB/2),Rx,Nds);

    for kk = 1:floor(numRB/2)
        for uu=1:P
            for ss=1:Nds
                ChanEstOutput_new(uu,kk,:,ss)=ChanEstOutput((uu-1)*Nds+ss,kk,:,:);
            end
        end
    end
else
    ChanEstOutput = zeros(P*Nds,floor(numRB/4),Rx,1);
    for nn = 1:numRB/4
        for uu = 1:P*Nds
            currentuuCDMGroup = floor((uu-1)/32); % 0,1,2 three groups
            if currentuuCDMGroup == 0
                deltaoffset = 0;
                for ll = 1:2
                    for kbar = 1:16
                        if kbar <=8
                            noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,1) + 1j*randn(Rx,1))./r0(16*(nn-1) + kbar);
                            % noiseGene =0;
                            currentChan = EquiChan_new{uu,48*(nn-1) + deltaoffset + kbar};
                            ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
                        else
                            noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,1) + 1j*randn(Rx,1))./r0(16*(nn-1) + kbar);
                            % noiseGene =0;
                            currentChan = EquiChan_new{uu,48*(nn-1) + deltaoffset + kbar + 16};
                            ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
                        end
                    end
                end
                ChanEstOutput(uu,nn,:,:) = ChanEstOutput(uu,nn,:,:)./32;

            elseif currentuuCDMGroup == 1
                deltaoffset = 8;
                for ll = 1:2
                    for kbar = 1:16
                        if kbar <=8
                            noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,1) + 1j*randn(Rx,1))./r1(16*(nn-1) + kbar);
                            % noiseGene =0;
                            currentChan = EquiChan_new{uu,48*(nn-1) + deltaoffset + kbar};
                            ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
                        else
                            noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,1) + 1j*randn(Rx,1))./r1(16*(nn-1) + kbar);
                            % noiseGene =0;
                            currentChan = EquiChan_new{uu,48*(nn-1) + deltaoffset + kbar + 16};
                            ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
                        end
                    end
                end
                ChanEstOutput(uu,nn,:,:) = ChanEstOutput(uu,nn,:,:)./32;
            else
                deltaoffset = 16;
                for ll = 1:2
                    for kbar = 1:16
                        if kbar <=8
                            noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,1) + 1j*randn(Rx,1))./r2(16*(nn-1) + kbar);
                            % noiseGene =0;
                            currentChan = EquiChan_new{uu,48*(nn-1) + deltaoffset + kbar};
                            ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
                        else
                            noiseGene = 1/sqrt(2)*sqrt(SNR)*(randn(Rx,1) + 1j*randn(Rx,1))./r2(16*(nn-1) + kbar);
                            % noiseGene =0;
                            currentChan = EquiChan_new{uu,48*(nn-1) + deltaoffset + kbar + 16};
                            ChanEstOutput(uu,nn,:,:) = squeeze(ChanEstOutput(uu,nn,:,:)) + currentChan + noiseGene;
                        end
                    end
                end
                ChanEstOutput(uu,nn,:,:) = ChanEstOutput(uu,nn,:,:)./32;
            end
        end
    end
    ChanEstOutput_new=zeros(P,floor(numRB/4),Rx,Nds);
    for kk = 1:floor(numRB/4)
        for uu=1:P
            for ss=1:Nds
                ChanEstOutput_new(uu,kk,:,ss)=ChanEstOutput((uu-1)*Nds+ss,kk,:,:);
            end
        end
    end
end

end