function [extendedPilotOutput] = ExtendedPilotGene(pilotOutput,numRBExtnded,totalExtendedUE)
%UNTITLED2 此处显示有关此函数的摘要
%   此处显示详细说明
baseNumber = totalExtendedUE/24;
extendedPilotOutput = zeros(numRBExtnded*12*baseNumber,2,totalExtendedUE);

for nn = 1:numRBExtnded
    for ii = 1:baseNumber
        extendedPilotOutput( 12*(ii-1) + [1:12] + 36*(nn-1),:,24*(ii-1) + [1:24] ) = pilotOutput(12*(nn-1) + [1:12],:,:);
    end
end



end