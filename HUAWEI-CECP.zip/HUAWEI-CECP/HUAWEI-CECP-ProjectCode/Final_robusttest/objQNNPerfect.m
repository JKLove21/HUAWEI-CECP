function [MSEManOpt] = objQNNPerfect(timePrecoderW)
%UNTITLED3 此处显示有关此函数的摘要
%   此处显示详细说明
global subcarriersK Tx Nds P weightLen numSubCar genieChanFreq RecFreq

DFTmtxInput = dftmtx(numSubCar);

MSEManOpt = 0;
counter =0;
for kk = 1:subcarriersK
    if kk <= numSubCar/2 || kk >= subcarriersK-numSubCar/2+1
        counter = counter + 1;
        for uu = 1:P
            chanuukk = squeeze(genieChanFreq{uu}(kk,:,:))* kron(DFTmtxInput(counter,1:weightLen),eye(Tx)); %Rx X Tx        
            for dd = 1:Nds
                recCoeffuudd = squeeze(RecFreq(:,kk,uu,dd));
                timePrecoderuudd = timePrecoderW(:,(uu-1)*Nds+dd);
                MSEManOpt = MSEManOpt + recCoeffuudd'*chanuukk*timePrecoderW*(chanuukk*timePrecoderW)'*recCoeffuudd + 1e-5*norm(recCoeffuudd).^2 + 1 - 2*real(recCoeffuudd'*chanuukk*timePrecoderuudd);
            end
        end
    end
end

end

