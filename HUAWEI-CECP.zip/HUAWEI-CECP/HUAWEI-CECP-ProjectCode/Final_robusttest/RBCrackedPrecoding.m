function [EZFCapacity,capacityRBCracked,RBCrackedPrecoderTime] = RBCrackedPrecoding(SysPara,Hfreq,RBCrackedPos)
%UNTITLED2 此处显示有关此函数的摘要
%   此处显示详细说明
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
SNR = SysPara.SNR; % Signal to Noise Ratio
SysPara.tapsN = 16; % channel taps (Randomly Generated)
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
SysPara.subcarriersK = length(RBCrackedPos);


HfreqRBSlected = Hfreq(:,:,RBCrackedPos);
Htmp = zeros(Rx*P,Tx,tapsN);
realTimeChan = zeros(Rx*P,Tx,length(RBCrackedPos));
realFreqChan = zeros(Rx*P,Tx,length(RBCrackedPos));
for ii = 1:Rx*P
    for tt = 1:Tx
        timeHseq = circshift(ifft(squeeze(HfreqRBSlected(ii,tt,:)),length(RBCrackedPos)),1/4*tapsN);
%         timeHseq(tapsN+1:end) = 0;
        realTimeChan(ii,tt,:) = timeHseq;
        realFreqChan(ii,tt,:) = fft(squeeze(realTimeChan(ii,tt,:)),length(RBCrackedPos));
        Htmp(ii,tt,:) = timeHseq(1:tapsN);
    end
end

[EZFCapacity] = EZF(SysPara,realFreqChan);

[HtimeToep, ~] = gen_channel_noise(Htmp,SysPara);
[capacityRBCracked,RBCrackedPrecoderTime] = QRSingleImpulse(HtimeToep,SysPara);
end

