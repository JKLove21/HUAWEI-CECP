function [chanFreq] = getgenieChanFreq(SysPara,pulseOutput)

% parameter setting
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
subcarriersK = SysPara.subcarriersK; % Subcarriers Number

chanFreq = zeros(subcarriersK,Rx,Tx);
for ii = 1:Rx
    for jj = 1:Tx
        chanFreq(:,ii,jj) = fft(squeeze(pulseOutput(:,ii,jj)),subcarriersK);
    end
end 

end

