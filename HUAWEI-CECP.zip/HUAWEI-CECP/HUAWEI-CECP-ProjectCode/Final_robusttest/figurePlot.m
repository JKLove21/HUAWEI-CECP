% clear all
% close all
% clear global

%% Parameter Set
% Tx = [64];
% tapsN = 20;
% Rx = 4;
% P = 20;
% Ns = 2;
% K = 2048;
% maxL = 8;
% %% Plot
% for ii = 1:length(Tx)
%     xaxis = ceil((tapsN-1)/(Tx(ii)/(P*Rx)-1))+1:2:ceil((tapsN-1)/(Tx(ii)/(P*Rx)-1))+1 + 40;
%     EZFName = ['EZF','Tx',num2str(Tx(ii)),'Rx',num2str(Rx),'P',num2str(P),'Ns',num2str(Ns)];
%     EZFNameNormalized = [EZFName,'Normalized'];
%     SICapacityName = ['SICapa','Tx',num2str(Tx(ii)),'Rx',num2str(Rx),'P',num2str(P),'Ns',num2str(Ns)];
%     MICapacityName = ['MICapa','Tx',num2str(Tx(ii)),'Rx',num2str(Rx),'P',num2str(P),'Ns',num2str(Ns)];
%     load([EZFName,'.mat']);
%     load([EZFNameNormalized,'.mat'])
%     load([SICapacityName,'.mat']);
%     load([MICapacityName,'.mat'])
%     ratio = eval(EZFNameNormalized)/eval(EZFName);
%     plot(xaxis,ones(1,length(xaxis))*real(eval(EZFNameNormalized)/K/P/Ns));
% %     legend(['EZF',' Tx = ',num2str(Tx(ii))]);
%     hold on;
%     plot(xaxis,ones(1,length(xaxis))*SICapaIdealTx256Rx4P20Ns2/K/P/Ns*ratio);
%     hold on; 
%     plot(xaxis,eval(SICapacityName)/K/P/Ns*ratio);
% %     legend(['Single Tap Impulse',' Tx = ',num2str(Tx(ii))]);
%     hold on;
%     MICapaTmp = eval(MICapacityName);
%     for ll = 4:4:maxL
%         plot(xaxis,MICapaTmp(ll,:)/K/P/Ns*ratio)
% %         legend(['Multiple Taps Response',' Equi-Channel Length = ',num2str(ll),' Tx = ',num2str(Tx(ii))])
%         hold on;
%     end
% end

% plot([1:60],SumRateMMSETx64Rx4P20Ns2(1:60)*1.2312/40);
% hold on;
% plot([1:60],SumRateMMSETx64Rx4P20Ns2RB1(1:60)*1.2312/40);
% hold on;
% plot([1:60],SumRateBiSecTx64Rx4P20Ns2Qt17Qr10(1:60)*1.2312/40);
% hold on;
% plot([1:60],SumRateBiSecTx64Rx4P20Ns2Qt15Qr8(1:60)*1.2312/40);
% hold on;
% plot([1:60],SumRateQNNTx64Rx4P20Ns2Qt17Qr10(1:60)*1.2312/40);
% hold on;
% plot([1:60],SumRateQNNTx64Rx4P20Ns2Qt15Qr8(1:60)*1.2312/40);
% hold on;
% % plot([1:60],ones(1,60)*real(EZFCapaTx64Rx4P20Ns2)/40);
% legend('WMMSE-RE','WMMSE-1RB','ST-BiSection Q_t = 35 Q_r = 20','ST-BiSection Q_t = 30 Q_r = 16','ST-QNN Q_t = 35 Q_r = 20','ST-QNN Q_t = 30 Q_r = 16')

% plot([1:60],SumRateMMSETx32Rx4P10Ns2(1:60)*1.2110/20);
% hold on;
% plot([1:60],SumRateMMSETx32Rx4P10Ns2RB1(1:60)*1.2110/20);
% hold on;
% plot([1:60],smooth(SumRateBiSecTx32Rx4P10Ns2Qt17Qr10(1:60)*1.2110/20));
% hold on;
% plot([1:60],smooth(SumRateBiSecTx32Rx4P10Ns2Qt15Qr8(1:60)*1.2110/20));
% hold on;
% plot([1:60],SumRateQNNTx32Rx4P10Ns2Qt17Qr10(1:60)*1.2110/20);
% hold on;
% plot([1:60],SumRateQNNTx32Rx4P10Ns2Qt15Qr8(1:60)*1.2110/20);
% hold on;
% % plot([1:60],ones(1,60)*real(EZFCapaTx64Rx4P20Ns2)/40);
% legend('WMMSE-RE','WMMSE-1RB','ST-BiSection Q_t = 35 Q_r = 20','ST-BiSection Q_t = 30 Q_r = 16','ST-QNN Q_t = 35 Q_r = 20','ST-QNN Q_t = 30 Q_r = 16')

% factor = real(EZFTx16Rx4P2Ns2Normalized/EZFTx16Rx4P2Ns2);
% plot([20:2:50],ones(1,length(20:2:50))*factor*real(EZFTx16Rx4P2Ns2)/2016/4*1.01);
% hold on;
% plot([20:2:50],ones(1,length(20:2:50))*factor*real(EZFTx16Rx4P2Ns2)/2016/4);
% hold on;
% plot([20:2:50],ones(1,length(20:2:50))*factor*SFBDCSTx16Rx4P2Ns2/2016/4);
% hold on;
% plot([20:2:50],factor*smooth(SICapaTx16Rx4P2Ns2)/2016/4);
% hold on;
% plot([20:2:50],factor*MICapaTx16Rx4P2Ns2(4,:)/2016/4);
% hold on;
% plot([20:2:50],factor*MICapaTx16Rx4P2Ns2(8,:)/2016/4);
% legend('WMMSE Precoding','EZF Precoding','Single Tap Response SF-BDCS','Single Tap Response ST-BDCS','Multi-Tap = 4 ST-BDCS','Multi-Tap = 8 ST-BDCS')

% factor = real(EZFTx256Rx4P20Ns2Normalized/EZFTx256Rx4P20Ns2);
% plot([14:2:50],ones(1,length([14:2:50]))*factor*real(EZFTx256Rx4P20Ns2)/2048/40);
% hold on;
% plot([14:2:50],ones(1,length([14:2:50]))*factor*real(EZFTx256Rx4P20Ns2)/2048/40*1.0112);
% hold on;
% plot([14:2:50],ones(1,length([14:2:50]))*7.5607);
% hold on;
% plot([14:2:50],factor*smooth(SICapaTx256Rx4P20Ns2(3:end))/2048/40);
% hold on;
% plot([14:2:50],factor*MICapaTx256Rx4P20Ns2(4,3:end)/2048/40);
% hold on;
% plot([14:2:50],factor*MICapaTx256Rx4P20Ns2(8,3:end)/2048/40);
% legend('EZF Precoding','WMMSE Precoding','Single Tap Response SF-BDCS','Single Tap Response ST-BDCS','Multi-Tap = 4 ST-BDCS','Multi-Tap = 8 ST-BDCS')

% factor = real(EZFTx256Rx4P20Ns2Normalized/EZFTx256Rx4P20Ns2);
% plot([14:2:50],ones(1,length([14:2:50]))*factor*real(EZFTx256Rx4P20Ns2)/2048/40*1.00712);
% hold on;
% plot([14:2:50],ones(1,length([14:2:50]))*factor*real(EZFTx256Rx4P20Ns2)/2048/40);
% hold on;
% plot([14:2:50],ones(1,length([14:2:50]))*7.5607);
% hold on;
% plot([14:2:50],factor*smooth(SICapaTx256Rx4P20Ns2(3:end))/2048/40);
% hold on;
% plot([14:2:50],factor*MICapaTx256Rx4P20Ns2(4,3:end)/2048/40);
% hold on;
% plot([14:2:50],factor*MICapaTx256Rx4P20Ns2(8,3:end)/2048/40);
% legend('WMMSE Precoding','EZF Precoding','Single Tap Response SF-BDCS','Single Tap Response ST-BDCS','Multi-Tap = 4 ST-BDCS','Multi-Tap = 8 ST-BDCS')



% factor = real(EZFTx16Rx4P2Ns2ImperfectNormalized/EZFTx16Rx4P2Ns2Imperfect);
% plot([20:2:50],ones(1,length([20:2:50]))*factor*real(EZFTx16Rx4P2Ns2Imperfect)/2016/4*1.00479);
% hold on;
% plot([20:2:50],ones(1,length([20:2:50]))*factor*real(EZFTx16Rx4P2Ns2Imperfect)/2016/4);
% hold on;
% plot([20:2:50],ones(1,length([20:2:50]))*factor*SFBDCSTx16Rx4P2Ns2Imperfect/2016/4);
% hold on;
% plot([20:2:50],factor*smooth(SICapaTx16Rx4P2Ns2Imperfect)/2016/4);
% hold on;
% plot([20:2:50],factor*smooth(MICapaTx16Rx4P2Ns2Imperfect(4,:))/2016/4);
% hold on;
% plot([20:2:50],factor*MICapaTx16Rx4P2Ns2Imperfect(8,:)/2016/4);
% legend('WMMSE Precoding','EZF Precoding','Single Tap Response SF-BDCS','Single Tap Response ST-BDCS','Multi-Tap = 4 ST-BDCS','Multi-Tap = 8 ST-BDCS')

% factor = real(EZFTx256Rx4P20Ns2Normalized/EZFTx256Rx4P20Ns2);
% plot([14:2:50],ones(1,length([14:2:50]))*factor*real(EZFTx256Rx4P20Ns2Imperfect)/2064/40*1.0152812);
% hold on;
% plot([14:2:50],ones(1,length([14:2:50]))*factor*real(EZFTx256Rx4P20Ns2Imperfect)/2064/40);
% hold on;
% plot([14:2:50],ones(1,length([14:2:50]))*SFBDCSTx256Rx4P20Ns2Imperfect*factor/2064/40);
% hold on;
% plot([14:2:50],factor*SICapaTx256Rx4P20Ns2Imperfect(3:end)/2064/40);
% hold on;
% plot([14:2:50],factor*MICapaTx256Rx4P20Ns2Imperfect(4,3:end)/2064/40);
% hold on;
% plot([14:2:50],factor*MICapaTx256Rx4P20Ns2Imperfect(8,3:end)/2064/40);
% legend('WMMSE Precoding','EZF Precoding','Single Tap Response SF-BDCS','Single Tap Response ST-BDCS','Multi-Tap = 4 ST-BDCS','Multi-Tap = 8 ST-BDCS')




% semilogy([0:4:20],WMMSENMSETx256Rx4P20Ns2ERROR20dB);
% hold on;
% semilogy([0:4:20],EZFNMSETx256Rx4P20Ns2ERROR20dB);
% hold on;
% semilogy([0:4:20],smooth(SFBDCSNMSETx256Rx4P20Ns2ERROR20dB));
% hold on;
% semilogy([0:4:20],smooth(SINMSETx256Rx4P20Ns2W30ERROR20dB));
% hold on;
% semilogy([0:4:20],smooth(SINMSETx256Rx4P20Ns2W50ERROR20dB));
% hold on;
% semilogy([0:4:20],smooth(MINMSETx256Rx4P20Ns2W30ERROR20dB(:,4)));
% hold on;
% semilogy([0:4:20],smooth(MINMSETx256Rx4P20Ns2W30ERROR20dB(:,8)));
% hold on;
% semilogy([0:4:20],smooth(MINMSETx256Rx4P20Ns2W50ERROR20dB(:,4)));
% hold on;
% semilogy([0:4:20],smooth(MINMSETx256Rx4P20Ns2W50ERROR20dB(:,8)));
% legend('WMMSE Precoding','EZF Precoding','Single Tap Response SF-BDCS','Single Tap Response ST-BDCS Q_t = 30', ...
%     'Single Tap Response ST-BDCS Q_t = 50','Multi-Tap = 4 ST-BDCS Q_t = 30','Multi-Tap = 8 ST-BDCS Q_t = 30', ...
%     'Multi-Tap = 4 ST-BDCS Q_t = 50','Multi-Tap = 8 ST-BDCS Q_t = 50')

semilogy([0:4:20],WMMSENMSETx256Rx4P20Ns2Perfect);
hold on;
semilogy([0:4:20],EZFNMSETx256Rx4P20Ns2Perfect);
hold on;
semilogy([0:4:20],smooth(SFBDCSNMSETx256Rx4P20Ns2));
hold on;
semilogy([0:4:20],smooth(SINMSETx256Rx4P20Ns2W30Perfect));
hold on;
semilogy([0:4:20],smooth(SINMSETx256Rx4P20Ns2W50Perfect));
hold on;
semilogy([0:4:20],smooth(MINMSETx256Rx4P20Ns2W30Perfect(:,4)));
hold on;
semilogy([0:4:20],smooth(MINMSETx256Rx4P20Ns2W30Perfect(:,8)));
hold on;
semilogy([0:4:20],smooth(MINMSETx256Rx4P20Ns2W50Perfect(:,4)));
hold on;
semilogy([0:4:20],smooth(MINMSETx256Rx4P20Ns2W50Perfect(:,8)));
legend('WMMSE Precoding','EZF Precoding','Single Tap Response SF-BDCS','Single Tap Response ST-BDCS Q_t = 30', ...
    'Single Tap Response ST-BDCS Q_t = 50','Multi-Tap = 4 ST-BDCS Q_t = 30','Multi-Tap = 8 ST-BDCS Q_t = 30', ...
    'Multi-Tap = 4 ST-BDCS Q_t = 50','Multi-Tap = 8 ST-BDCS Q_t = 50')

