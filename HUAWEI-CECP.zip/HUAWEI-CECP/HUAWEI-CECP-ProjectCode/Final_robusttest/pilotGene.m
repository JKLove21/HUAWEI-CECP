function [prbMapOut] = pilotGene(SysPara,pilotType,cellId)
%% 帧结构参数
OCCt = [+1,+1;
        +1,-1];
OCCt2 = [1,+1;
         +1,-1;
         -1,-1;
         -1,+1];
OCCf = [+1,+1,+1,+1;  %type1双符号频域Occ扩展
        +1,-1,+1,-1;
        +1,+1j,-1,-1j;
        +1,-1j,-1,+1j];

P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
numRB = SysPara.numRB;
numSubCar = 12*numRB;
locFreqPilotGene = [subcarriersK-numSubCar/2+1:subcarriersK,1:numSubCar/2];
%% 生成导频
switch pilotType
    case 0
        %% 单符号DMRS:configuration type2，6个用户
        prbMapOut = zeros(subcarriersK,Nds*P); %1个用户，6流，看看每一流的是不是正交的
        for uu = 1:Nds*P
            dmrs = PDSCH_dmrs(numSubCar,cellId);
            if mod(uu,6)==1  || mod(uu,6)==2
               IdxStart=1;
            elseif mod(uu,6)==3  || mod(uu,6)==4
                IdxStart=3;
            elseif mod(uu,6)==5  || mod(uu,6)==0
                IdxStart=5;
            end
            Loc1 = locFreqPilotGene(IdxStart:6:end); %频域第一部分位置，周期为6，比如1，7，13
            Loc2 = locFreqPilotGene(IdxStart+1:6:end); %频域第二部分位置
            pilotLocFreq=zeros(1,(length(Loc1)+length(Loc2)));
            pilotLocFreq(1:2:end)=Loc1; %整合成一个最终的频域位置
            pilotLocFreq(2:2:end)=Loc2;

            Seq1 = dmrs(IdxStart:6:end);%按照频点k选择铺满所有RB所有RE的root序列
            Seq2 = dmrs(IdxStart+1:6:end); 
            pilotSeq=zeros(1,(length(Seq1)+length(Seq2)));
            pilotSeq(1:2:end)=Seq1; %整合成一个最终选择后的导频序列
            pilotSeq(2:2:end)=Seq2;

            %同频的不同用户，在两个符号处进行码分 设预编码矩阵W=1，未乘功率因子beta
            if mod(uu,2)==1 %插入序列 (135、7911)
                prbMapOut(pilotLocFreq,uu) = pilotSeq.*repmat(OCCt(1,:),1,length(dmrs)/6);  
            elseif mod(uu,2)==0 % （246、81012）
                prbMapOut(pilotLocFreq,uu) = pilotSeq.*repmat(OCCt(2,:),1,length(dmrs)/6);
            end
        end

        
        
    case 1
       %% 双符号DMRS:configuration type2，12个用户
        prbMapOut = zeros(Nf,numSymPerSubfrm,numTxPort,numUser); %直接假设12流
        for uu = 1:numUser 
            for ss = 1:numSlot %2个slot
                dmrs = PDSCH_dmrs(numRB,ss-1,dmrsSymPos0,cellId);
                for tt = 1:numTxPort  %12用户选择频分的起始位置
                    if mod(uu,6)==1  | mod(uu,6)==2
                       IdxStart=1;
                    elseif mod(uu,6)==3  | mod(uu,6)==4
                        IdxStart=3;
                    elseif mod(uu,6)==5  | mod(uu,6)==0
                        IdxStart=5;
                    end

                    Loc1 = locFreqPilotGene(IdxStart:6:end); %频域第一部分位置，周期为6，比如1，7，13
                    Loc2 = locFreqPilotGene(IdxStart+1:6:end); %频域第二部分位置
                    pilotLocFreq=zeros(1,(length(Loc1)+length(Loc2)));
                    pilotLocFreq(1:2:end)=Loc1; %整合成一个最终的频域位置
                    pilotLocFreq(2:2:end)=Loc2;

                    Seq1 = dmrs(IdxStart:6:end);%按照频点k选择铺满所有RB所有RE的root序列
                    Seq2 = dmrs(IdxStart+1:6:end); 
                    pilotSeq=zeros(1,(length(Seq1)+length(Seq2)));
                    pilotSeq(1:2:end)=Seq1; %整合成一个最终选择后的导频序列
                    pilotSeq(2:2:end)=Seq2;

                    %同频的不同用户，在两个符号处进行码分 设预编码矩阵W=1，未乘功率因子beta
                    if mod(uu,2)==1 %DMSR第一个符号处插入序列 (1357911)
                        prbMapOut(pilotLocFreq,(dmrsSymPos0+1)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(OCCt(1,:),1,length(dmrs)/6);  
                        if uu<=6 %DMSR第二个符号处DMSR处插入序列 135
                            prbMapOut(pilotLocFreq,(dmrsSymPos0+2)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(OCCt2(1,:),1,length(dmrs)/6);
                        elseif uu>6
                            prbMapOut(pilotLocFreq,(dmrsSymPos0+2)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(OCCt2(3,:),1,length(dmrs)/6);
                        end
                    elseif mod(uu,2)==0 % 用户24681012
                        prbMapOut(pilotLocFreq,(dmrsSymPos0+1)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(OCCt(2,:),1,length(dmrs)/6);
                        if uu<=6 
                            prbMapOut(pilotLocFreq,(dmrsSymPos0+2)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(OCCt2(2,:),1,length(dmrs)/6);
                        elseif uu>6
                            prbMapOut(pilotLocFreq,(dmrsSymPos0+2)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(OCCt2(4,:),1,length(dmrs)/6);
                        end
                    end
                end
            end
        end 
    case 2
       % 单符号DMRS:configuration type1,4个用户
        prbMapOut = zeros(Nf,numSymPerSubfrm,numTxPort,numUser);
        for uu = 1:numUser
            for ss = 1:numSlot
                dmrs = PDSCH_dmrs(numRB,ss-1,dmrsSymPos0,cellId);
                for tt = 1:numTxPort
                    pilotLocFreq = locFreqPilotGene(ceil(uu/2):2:end);
                    if mod(uu,2)==1
                        prbMapOut(pilotLocFreq,(dmrsSymPos0+1)+(ss-1)*numSymPerSlot,tt,uu) = dmrs(ceil(uu/2):2:end).*repmat(OCCt(1,:),1,length(dmrs)/4);    % 未乘功率因子beta
                    elseif mod(uu,2)==0
                        prbMapOut(pilotLocFreq,(dmrsSymPos0+1)+(ss-1)*numSymPerSlot,tt,uu) = dmrs(ceil(uu/2):2:end).*repmat(OCCt(2,:),1,length(dmrs)/4);
                    end
                end
            end
        end
    case 3 
    % 双符号DMRS:configuration type1的扩展,16个用户
        prbMapOut = zeros(Nf,numSymPerSubfrm,numTxPort,numUser); 
        for uu = 1:numUser 
            if mod(uu,8)==1  | mod(uu,8)==2 | mod(uu,8)==5  | mod(uu,8)==6  %选择频域起始位置
               IdxStart = 1;
            else
               IdxStart = 2;
            end           
            for ss = 1:numSlot %2个slot
                dmrs = PDSCH_dmrs(numRB,ss-1,dmrsSymPos0,cellId);
                for tt = 1:numTxPort  
                    pilotLocFreq = locFreqPilotGene(IdxStart:2:end); 
                    pilotSeq = dmrs(IdxStart:2:end);       
                    %在两个符号处进行occ时域码分 设预编码矩阵W=1，未乘功率因子beta
                    if uu<=8  
                        if mod(uu,2) == 1 %0/2/4/6 第一个DMRS符号
                           prbMapOut(pilotLocFreq,(dmrsSymPos0+1)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(OCCf(1,:),1,length(dmrs)/8);  
                           if uu<=4 %0/2 第二个DMRS符号
                              prbMapOut(pilotLocFreq,(dmrsSymPos0+2)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(OCCf(1,:),1,length(dmrs)/8);
                           else %4/6 第二个DMRS符号
                              prbMapOut(pilotLocFreq,(dmrsSymPos0+2)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(-1*OCCf(1,:),1,length(dmrs)/8);
                           end
                        else %1/3/5/7 第一个DMRS符号
                           prbMapOut(pilotLocFreq,(dmrsSymPos0+1)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(OCCf(2,:),1,length(dmrs)/8);  
                           if uu<=4 %1/3 第二个DMRS符号
                              prbMapOut(pilotLocFreq,(dmrsSymPos0+2)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(OCCf(2,:),1,length(dmrs)/8);
                           else %5/7 第二个DMRS符号
                              prbMapOut(pilotLocFreq,(dmrsSymPos0+2)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(-1*OCCf(2,:),1,length(dmrs)/8);
                           end
                        end
                    else %扩展的Port8~15
                        if mod(uu,2) == 1 %8/10/12/14 第一个DMRS符号
                           prbMapOut(pilotLocFreq,(dmrsSymPos0+1)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(OCCf(3,:),1,length(dmrs)/8);  
                           if uu<=12 %8/10 第二个DMRS符号
                              prbMapOut(pilotLocFreq,(dmrsSymPos0+2)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(OCCf(3,:),1,length(dmrs)/8);
                           else %12/14 第二个DMRS符号
                              prbMapOut(pilotLocFreq,(dmrsSymPos0+2)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(-1*OCCf(3,:),1,length(dmrs)/8);
                           end
                        else %9/11/13/15 第一个DMRS符号
                           prbMapOut(pilotLocFreq,(dmrsSymPos0+1)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(OCCf(4,:),1,length(dmrs)/8);  
                           if uu<=12 %9/11 第二个DMRS符号
                              prbMapOut(pilotLocFreq,(dmrsSymPos0+2)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(OCCf(4,:),1,length(dmrs)/8);
                           else %13/15 第二个DMRS符号
                              prbMapOut(pilotLocFreq,(dmrsSymPos0+2)+(ss-1)*numSymPerSlot,tt,uu) = pilotSeq.*repmat(-1*OCCf(4,:),1,length(dmrs)/8);
                           end
                        end
                    end
                    
                end
            end    
        end
       
end
       
end

