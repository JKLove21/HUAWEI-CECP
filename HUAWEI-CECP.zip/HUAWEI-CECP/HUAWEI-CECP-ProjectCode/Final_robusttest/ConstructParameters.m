function [SysPara] = ConstructParameters
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
SysPara.Tx = 32;
SysPara.Rx = 2;
SysPara.P = 2;
SysPara.Nds = 2;
SysPara.tapsN = 25; % Maximum Channel Length Donot change
SysPara.weightLen = ceil((SysPara.tapsN-1)/(SysPara.Tx/(SysPara.P*SysPara.Rx)-1))+1; % Minimum FIR Filter Length
SysPara.subcarriersK = 2048;
SysPara.numRB = 24;
SysPara.SNR = 1/db2pow(10);

SysPara.chanType = 'CDL-B';
SysPara.delaySpreads = 300*1e-9;
SysPara.fcHz = 6.7*1e9;
% SysPara.fsHz = 1.2288*1e8;
% SysPara.fsHz = 400*1e6;
SysPara.fsHz = SysPara.subcarriersK*30*1e3;
SysPara.sampleDensity =128;

SysPara.ExtendedPilotIdx = 1;   %1 = 48; 2 = 96;
SysPara.channEstError = 1./db2pow(10*rand(SysPara.P,1)+5);

 SysPara.UserVelocity = 3;            %(km/h)
fd = SysPara.UserVelocity/3.6/3e8*SysPara.fcHz;
SysPara.MaximumDopplerShiftHz = fd;
% SysPara.sampleDensity =256;
SysPara.sampleDensity = round(SysPara.fsHz/SysPara.subcarriersK/2/fd);
SysPara.angleRxpolar = [-45 45];
SysPara.channelMode = 1;    % 0 for underrank channel, 1 for full rank channel
SysPara.Seed = 42;
SysPara.SingleUserDim = 2;  % Dimension Desired per User
SysPara.iterNum = 8;

SysPara.RBsize = 12;   %RB内RE数
SysPara.RBnum =floor(SysPara.subcarriersK/SysPara.RBsize);  % 总RB数
SysPara.schRBnum = 16; % 一个子带内RB数
SysPara.subband_num=floor(SysPara.subcarriersK/(SysPara.RBsize*SysPara.schRBnum)); %总子带数
SysPara.UE_schedulnum=SysPara.P; %user_num/subband
end

