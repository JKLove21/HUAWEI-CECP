clear all;

L = 20;
Q = 30;
K = 2048;
Qr = 48;
Tx = 256;
Rx = 4;
Ns = 2;
P = 20;
Lbar = (Q+L-1)/2;
ceilLen = 2^(ceil(log2(Q+L-1)));
I = 20;
IArmijo = 20;
IWMMSE = 15;
Sp = 8;

SingleResponse = Tx*(P*Rx)^2*(Q*L+L^2)+(P*Rx)^3*(Q*L+L^2/2) + (P*Rx)^3*(Q*L+L^2/2 - (Q+L-1)^2/4) +  ...
    Tx * P*Rx*P*Ns*ceilLen + Tx *(P*Ns + P*Rx)/2*ceilLen * log2(ceilLen) + (P*Rx)^2*P*Ns*Lbar*(Q+L-1) + Lbar * (P*Rx)^2*Ns;
BenchmarkSingle = (1/2*Tx*(P*Rx)^2+2/3*(P*Rx)^3)*K + (Tx * P*Rx*P*Ns + (P*Rx)^2*P*Ns)*K;

MultiResponse = Tx*(P*Rx)^2*(Q*L+L^2)+(P*Rx)^3*(Q*L+L^2/2) + (P*Rx)^3*(Q*L+L^2/2 - (Q+L-1)^2/4) +  ...
    Tx * P*Rx*P*Ns*ceilLen + Tx *(P*Ns + P*Rx)/2*ceilLen * log2(ceilLen) + (P*Rx)^2*P*Ns*Lbar*(Q+L-1) + Lbar * (P*Rx)^2*Ns + I*(K*P*Ns^3*IArmijo + P*(Sp*Rx)^2*Ns + Ns^3 + 1.5*Ns^2*Sp*Rx + ...
    5*Sp*Rx*Ns);

BenchmarkMulti = (1/2*Tx*(P*Rx)^2+2/3*(P*Rx)^3)*K + (Tx * P*Rx*P*Ns + (P*Rx)^2*P*Ns)*K + I*(K*P*Ns^3*IArmijo + P*(Sp*Rx)^2*Ns + Ns^3 + 1.5*Ns^2*Sp*Rx + ...
    5*Sp*Rx*Ns);
EZF = (1/2*Tx^2*(P*Rx) + 3*P*Tx^2*Ns + 1.5*Tx*(P*Ns)^2 + 2/3*(P*Ns)^3)*K;
WMMSENew = 1/2*K*Tx*(P*Rx)^2 + K*IWMMSE*( 2*P^3*Ns*Rx^2 + P^3*Rx^3 + 2/3*Rx^3*P + P*Rx^2*Ns + P*Ns^2*Rx + (P*Rx)^2*P*Ns + 2*(P*Ns)^2*P*Rx + 2/3*(P*Ns)^3 );

% WMMSERB = ( P*P*Ns*Rx^2/2 + Tx*P*P*Ns*Rx + P*Rx^3 + Rx^2*Ns*P + (Tx^3 + Tx^2*P*Ns)*10 + Tx*Rx*Ns*P + Tx^2*P*Ns/2 ) * (K/12 + 8) * 23;
% % QNNTime = ( (2*Q-1) * Tx*P*P*Ns*Rx + (4*Q-3)*P*Ns*Rx^2/2 + P*Rx*Rx^2/2 + Qr^2 * P*Rx^3 + Tx*Ns*P*Rx*K + 1.5*K*P*Rx^2*Ns + ((2*Q-1 + K )*Tx*Ns*P*Rx + 1.5*K*P*Rx^2*Ns)*4 )*28;
% WMMSE = ( P*P*Ns*Rx^2/2 + Tx*P*P*Ns*Rx + P*Rx^3 + Rx^2*Ns*P + (Tx^3 + Tx^2*P*Ns)*10 + Tx*Rx*Ns*P + Tx^2*P*Ns/2 ) * K * 25;

% QNNTime = ( (Q+L-1)*P*Rx*Tx*P*Ns + (2*Q+2*L-3)*P*Rx^2*P*Ns/2 + Qr^2 * P*Rx^3 + (Qr + Q+ L -2)*Rx^2*Ns*P + (Qr + L -1)*P*Tx*Rx*Ns + (2*Qr + 2*L -3)*Tx^2*P*Ns/2 + Tx^2*(2*Qr + 2*L -3)*log2(2*Qr + 2*L -3)+ 2*Tx^2*(2*Qr + 2*L -4+Q)*log2(2*Qr + 2*L -4+Q) + ( (2*Qr + 2*L + Q -4)*Tx^2*P*Ns )*4 )*30;

X = categorical({'Single Tap ST'});
bar(X,SingleResponse);
hold on;
X = categorical({'Single Tap SF'});
bar(X,BenchmarkSingle);
hold on;
X = categorical({'EZF'});
bar(X,EZF);
hold on;
hold on;
X = categorical({'WMMSE'});
bar(X,WMMSENew);
hold on;
X = categorical({'Multi-Tap SF'});
bar(X,BenchmarkMulti);
hold on;
X = categorical({'Multi-Tap ST'});
bar(X,MultiResponse);
legend('Single Tap Response ST-BDCS','Single Tap Response SF-BDCS','EZF Precoding','WMMSE Precoding','Multi-tap = 8 SF-BDCS','Multi-tap = 8 ST-BDCS')

% X = categorical({'ST-QNN Q_t = 30'});
% bar(X,QNNTime);
% hold on;
% X = categorical({'ST-QNN Q_t = 35'});
% bar(X,QNNTime35);
% hold on;
% X = categorical({'WMMSE-1RB'});
% bar(X,WMMSERB);
% hold on;
% X = categorical({'WMMSE-RE'});
% bar(X,WMMSE);
% legend('ST-QNN Q_t = 30  Q_r = 16','ST-QNN Q_t = 35  Q_r = 20','WMMSE-1RB','WMMSE-RE')

