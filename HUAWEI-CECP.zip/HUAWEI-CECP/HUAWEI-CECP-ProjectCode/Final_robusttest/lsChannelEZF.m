function [NMSEEZF,HfreqEZFEstInpo,EZFEquiChan] = lsChannelEZF(SysPara,EZFEquiChan)
%UNTITLED5 此处显示有关此函数的摘要
%   此处显示详细说明
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
weightLen = SysPara.weightLen; % ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 minimum FIR Length
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio
ExtendedPilotIdx = SysPara.ExtendedPilotIdx;


%% LS Est
if ExtendedPilotIdx == 1    
    baseNum = 2;
    [pilotOutput] = PilotGeneCECP2(subcarriersK/12,ExtendedPilotIdx);
    [HfreqEZFEst] = LSChannelEst2(SysPara,pilotOutput,EZFEquiChan);
    % HfreqEZFEst = zeros(P,subcarriersK/12/baseNum,Rx,Nds);
    % [pilotOutput] = PilotGeneCECP(subcarriersK/12); %[subcarriersK,2,24] extend double
    % for uu = 1:P
    %     for kkidx = 1:subcarriersK/12/baseNum
    %         currentbaseNumber = floor((uu-1)/24); %% UserGroup Idx 0,1,...
    %         currentRealUUNumber = uu - currentbaseNumber*24;
    %         [locseq,wf,wt] = LSChannelEst(currentRealUUNumber);
    %         for ii = 1:length(locseq)
    %             pilot1 = squeeze(pilotOutput(locseq(ii) + (kkidx-1)*12,1,currentRealUUNumber));
    %             pilot2 = squeeze(pilotOutput(locseq(ii) + (kkidx-1)*12,2,currentRealUUNumber));
    %             noiseGene = (1/sqrt(subcarriersK)*(randn(Rx,Nds) + 1j*randn(Rx,Nds)) .* wt(1)./pilot1 + 1/sqrt(subcarriersK)*(randn(Rx,Nds) + 1j*randn(Rx,Nds)) * wt(2)./pilot2 )/2;
    %             currentChan = EZFEquiChan{uu,locseq(ii) + currentbaseNumber*12 + (kkidx-1)*12*baseNum};
    %             HfreqEZFEst(uu,kkidx,:,:) = squeeze(HfreqEZFEst(uu,kkidx,:,:)) + currentChan + noiseGene .* wf(ii);
    %         end
    %         HfreqEZFEst(uu,kkidx,:,:) = squeeze(HfreqEZFEst(uu,kkidx,:,:))./length(locseq);
    %     end
    % end    
elseif ExtendedPilotIdx == 2
    baseNum = 4;
    [pilotOutput] = PilotGeneCECP2(subcarriersK/12,ExtendedPilotIdx);
    [HfreqEZFEst] = LSChannelEst2(SysPara,pilotOutput,EZFEquiChan);
    % HfreqEZFEst = zeros(P,subcarriersK/12/baseNum,Rx,Nds);
    % [pilotOutput] = PilotGeneCECP(subcarriersK/12); %[subcarriersK,2,24] extend double
    % for uu = 1:P
    %     for kkidx = 1:subcarriersK/12/baseNum
    %         % kkidx = floor((kk-1)/12/baseNum)+1; %% PiloSector Idx 1,..,..
    %         currentbaseNumber = floor((uu-1)/24); %% UserGroup Idx 0,1,...
    %         currentRealUUNumber = uu - currentbaseNumber*24;
    %         [locseq,wf,wt] = LSChannelEst(currentRealUUNumber);
    %         for ii = 1:length(locseq)
    %             pilot1 = squeeze(pilotOutput(locseq(ii) + (kkidx-1)*12,1,currentRealUUNumber));
    %             pilot2 = squeeze(pilotOutput(locseq(ii) + (kkidx-1)*12,2,currentRealUUNumber));
    %             noiseGene = (1/sqrt(subcarriersK)*(randn(Rx,Nds) + 1j*randn(Rx,Nds)) .* wt(1)./pilot1 + 1/sqrt(subcarriersK)*(randn(Rx,Nds) + 1j*randn(Rx,Nds)) * wt(2)./pilot2 )/2;
    %             currentChan = EZFEquiChan{uu,locseq(ii) + currentbaseNumber*12 + (kkidx-1)*12*baseNum};
    %             HfreqEZFEst(uu,kkidx,:,:) = squeeze(HfreqEZFEst(uu,kkidx,:,:)) + currentChan + noiseGene * wf(ii);
    %         end
    %         HfreqEZFEst(uu,kkidx,:,:) = squeeze(HfreqEZFEst(uu,kkidx,:,:))./length(locseq);
    %     end
    % end
end

%% NMSE

HfreqEZFEstTime = ifft(HfreqEZFEst,floor(subcarriersK/12)/baseNum,2);
HfreqEZFEstInpo = fft(HfreqEZFEstTime,subcarriersK,2);

NMSEEZF = 0;
for uu = 1:P
    for kk = 1:subcarriersK
       NMSEEZF =  NMSEEZF + norm(squeeze(HfreqEZFEstInpo(uu,kk,:,:))-EZFEquiChan{uu,kk},'fro').^2/norm(EZFEquiChan{uu,kk},'fro').^2;
    end
end

% OriginalChan = zeros(subcarriersK,1);
% for kk = 1:subcarriersK
%     OriginalChan(kk) = EZFEquiChan{1,kk}(1,1);
% end
% 
% plot(abs(OriginalChan));
% hold on;
% plot(abs(squeeze(HfreqEZFEstInpo(1,:,1,1))))
end