function [Con]=constant_coefficient(a,b,v,k)

temp=0;
for ii=1:length(v)
    temp=temp+squeeze(b(k,:,ii))*v;
end
C1=a(k,k)*(temp-squeeze(b(k,:,k))*v);

C2=a(k,:)*v*(sum(b(k,:,k))-b(k,k,k));
Con=C1-C2;

end