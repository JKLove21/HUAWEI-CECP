function [capacityManifoldCGMethod,T] = MFGradDesSingle(Tinitial,SysPara)
%UNTITLED4 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
iterNum = 2*SysPara.iterNum;

manifold = spherecomplexfactory(Rx*P,Nds);
problem.M = manifold;
problem.cost  = @objectFunSingle;
problem.egrad = @EuclideanGradT;
% checkgradient(problem);
Operation.maxiter = iterNum;
[T,cost,info,options] = conjugategradient(problem,Tinitial,Operation);

capacityManifoldCGMethod = [];
for ii = 1:length(info)
    capacityManifoldCGMethod = [capacityManifoldCGMethod,abs(info(ii).cost)];
end
end

