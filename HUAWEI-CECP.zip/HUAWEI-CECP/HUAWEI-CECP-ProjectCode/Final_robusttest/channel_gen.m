function [mimoChan] = channel_gen(SysPara,userSeed)

mimoChan = nrCDLChannel;
% mimoChan.UTDirectionOfTravel = rand(2,1)*90;
mimoChan.DelayProfile = SysPara.chanType;
mimoChan.DelaySpread = SysPara.delaySpreads;
mimoChan.CarrierFrequency = SysPara.fcHz;%carrier frequency
mimoChan.SampleRate = SysPara.fsHz;%sample rate
mimoChan.SampleDensity = SysPara.sampleDensity;
mimoChan.MaximumDopplerShift = SysPara.MaximumDopplerShiftHz;
mimoChan.TransmitAntennaArray.Size = [1 SysPara.Tx 1 1 1]; % [row col polar 1 1]
mimoChan.ReceiveAntennaArray.Size = [SysPara.Rx 1 1 1 1];  
mimoChan.ReceiveAntennaArray.PolarizationAngles = SysPara.angleRxpolar;
mimoChan.ChannelFiltering = true;
% mimoChan.NumTimeSamples = 122880;  
mimoChan.Seed = userSeed;
% mimoChan.UserVelocity = SysPara.UserVelocity/3.6; 
end