function [SumRate] = QNNPerfectMMSETrain(SysPara,genieChanFreq,timePrecoderW)
% MMSE based ST-MIMO-OFDM
% A space time distributed precoding design
global RecFreq
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
weightLen = SysPara.weightLen;
numRB = SysPara.numRB;
numSubCar = 12*numRB;
locFreq = [1:numSubCar/2,subcarriersK-numSubCar/2+1:subcarriersK];
% DFTmtxInput = dftmtx(subcarriersK);
DFTmtxInput = dftmtx(numSubCar);
SumRate = [];
MMSEIteration = [];
for blockIndx = 1:30
    disp(blockIndx);
    rng(blockIndx);
    %% Rx weight Space Time
    [RecFreq] = nrEqualizerSpaceTimePerfect(SysPara,genieChanFreq,timePrecoderW);
    %% Tx weight Space Time
    [timePrecoderW] = QNNBiSectionPerfect(SysPara,RecFreq,genieChanFreq);
%     [timePrecoderW,MMSEIterationblockIndx] = QNNManifoldPerfect(SysPara,RecFreq,genieChanFreq,timePrecoderW,blockIndx);
%     MMSEIteration = [MMSEIteration,MMSEIterationblockIndx];
    %% Check Tx Equivalent Channel
%     [equiChan] = euqiChanCheck(SysPara,timePrecoderW,genieChanFreq);
    %% SumRate Test
    sumrate = 0;
    publicTerm = zeros(subcarriersK,P,Nds);
    counter = 0;
    for kk = 1:subcarriersK
        if kk <= numSubCar/2 || kk >= subcarriersK-numSubCar/2+1
            counter = counter + 1;
            for uulocal = 1:P
                for ddlocal = 1:Nds
                    chanuu = squeeze(genieChanFreq{uulocal}(kk,:,:))* kron(DFTmtxInput(counter,1:weightLen),eye(Tx)); %Rx X Tx
                    recCoeffuudd = squeeze(RecFreq(:,kk,uulocal,ddlocal));
                    desiredPow = abs(recCoeffuudd'*chanuu*timePrecoderW(:,(uulocal-1)*Nds + ddlocal)).^2;
                    for uu = 1:P
                        for dd = 1:Nds
                            publicTerm(kk,uulocal,ddlocal) = publicTerm(kk,uulocal,ddlocal) + abs(recCoeffuudd' *chanuu * timePrecoderW(:,(uu-1)*Nds + dd)).^2;
                        end
                    end
                    interferencePow = publicTerm(kk,uulocal,ddlocal) - desiredPow;
                    sumrate = sumrate + log2(1+ desiredPow/(interferencePow + 1e-2*norm(recCoeffuudd,'fro').^2) );
                end
            end
        end
    end
    disp(sumrate);
    SumRate = [SumRate,sumrate];

end

end



