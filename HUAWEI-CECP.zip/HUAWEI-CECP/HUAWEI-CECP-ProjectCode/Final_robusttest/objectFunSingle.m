function [value] = objectFunSingle(T )
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
global  Rx subcarriersK SNR P Hdesired Qzf startPoint SysPara


P = SysPara.P;
dim = SysPara.SingleUserDim;
% global dim
Rx = dim;
    
F = dftmtx(subcarriersK);
value = 0;
for uu = 1:P
    Tuu = T((uu-1)*Rx+(1:Rx),:);
    Hdesireduu = Hdesired{uu};
    Qzfuu = Qzf{uu};
    for kk = 1:subcarriersK
        Fbar = kron(F(kk,startPoint),eye(Rx));
        % Heffectkk = Fbar * Hdesireduu * Qzfuu;
        Heffectkk = Fbar * Hdesireduu * Qzfuu * (Qzfuu'*Qzfuu)^(-1/2);
        value = value - real(log2(det(  eye(Rx) + 1/SNR*Heffectkk * Tuu * (Heffectkk * Tuu)' )));
    end
end

end



