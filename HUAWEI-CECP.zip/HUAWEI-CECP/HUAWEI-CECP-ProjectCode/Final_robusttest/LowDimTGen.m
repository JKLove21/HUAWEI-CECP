function [HtimeToep,HtimeToepImperfect,Hfreq,HfreqImperfect] = LowDimTGen(muMimoChanCell,SysPara)
    
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
dim = SysPara.SingleUserDim;  
P = SysPara.P;    % User Terminals
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
channEstError = SysPara.channEstError;

Htmp = zeros(dim*P,Tx,tapsN);
HtmpImperfect = zeros(dim*P,Tx,tapsN);
for uu = 1:P
    TimeChanRes = muMimoChanCell{uu};
    TimeChanReduced = ReduceChanDim(TimeChanRes,SysPara);
    for tt = 1:Tx
        for rr = 1:dim
            taps_tmp=squeeze(TimeChanReduced(:,rr,tt));
            Htmp((uu-1)*dim + rr,tt,:) = taps_tmp;
%             for ll=1:tapsN
%                 HtmpImperfect((uu-1)*dim + rr,tt,ll) = squeeze(Htmp((uu-1)*dim + rr,tt,ll)) + sqrt(0.5*norm(taps_tmp(ll))/tapsN*channEstError).*(randn(1) + 1i*randn(1));
% %                 HtmpImperfect((uu-1)*dim + rr,tt,ll) = squeeze(Htmp((uu-1)*dim + rr,tt,ll)) + sqrt(norm(taps_tmp(ll))*channEstError).*(randn(1) + 1i*randn(1));
%             end
            % HtmpImperfect((uu-1)*dim + rr,tt,:) = taps_tmp + channEstError(uu)*sqrt(0.5/tapsN).*(randn(tapsN,1) + 1i*randn(tapsN,1));

        end
    end
end


SysPara.Rx = dim;

[HtimeToep,HtimeToepImperfect,Hfreq,HfreqImperfect] = gen_channel_noise(Htmp,SysPara);
% Verification Part
%-------------------------------------------------------------
% Rx = dim;
% Hfreq2 = zeros(Rx * P,Tx,SysPara.subcarriersK);
% for ii = 1:Rx * P
%     for jj = 1:Tx
%         Hfreq2(ii,jj,:) = fft(Htmp(ii,jj,:),SysPara.subcarriersK);
%     end
% end
% loss = 0;
% for i = 1:1024
%     loss = loss+sum(abs(squeeze(HfreqO(:,:,i))).^2,'all')-sum(abs(squeeze(Hfreq2(:,:,i))).^2,'all');
% end
% disp('信道能量差：')
% loss
%----------------------------------------------
end