function [SumRate] = QNNMMSEBroadBand(SysPara,genieChanFreq,timePrecoderW)
% MMSE based ST-MIMO-OFDM
% A space time distributed precoding design
global RecFreq
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio
weightLen = SysPara.weightLen;
numRB = SysPara.numRB;
numSubCar = 12*numRB;
locFreq = [1:numSubCar/2,subcarriersK-numSubCar/2+1:subcarriersK];
DFTmtxInput = dftmtx(subcarriersK)./sqrt(subcarriersK);

SumRate = [];
MMSEIteration = [];
for blockIndx = 1:30
    disp(blockIndx);
    rng(blockIndx);
    %% Generate Training Data
    [pilotout] = nrSubFrm_transmitter(SysPara,blockIndx);
    %% DL forward
    yDL = zeros(subcarriersK,P,Rx);
    noise = zeros(subcarriersK,P,Rx);
    MSE = 0;
    for kk = 1:subcarriersK
        if kk <= numSubCar/2 || kk >= subcarriersK-numSubCar/2+1
            for uulocal = 1:P
                chanuukk = squeeze(genieChanFreq{uulocal}(kk,:,:))* kron(DFTmtxInput(kk,1:weightLen),eye(Tx)); %Rx X Tx
                for uu = 1:P
                    for dd = 1:Nds
                        Datadduu = pilotout{dd,uu};
                        yDL(kk,uulocal,:) = squeeze(yDL(kk,uulocal,:)) + chanuukk * timePrecoderW(:,(uu-1)*Nds + dd) * Datadduu(kk);
                    end
                end
                noise(kk,uulocal,:) = sqrt(1e-5) * (randn(Rx,1) + 1j*randn(Rx,1));
                yDL(kk,uulocal,:) = squeeze(yDL(kk,uulocal,:)) + squeeze(noise(kk,uulocal,:));
                if blockIndx >= 2
                    for ddlocal = 1:Nds
                        recCoeffuudd = squeeze(RecFreq(:,kk,uulocal,ddlocal));
                        pilotLocal = pilotout{ddlocal,uulocal};
                        MSE = MSE + abs( recCoeffuudd'*squeeze(yDL(kk,uulocal,:)) - pilotLocal(kk) ).^2;
                    end
                end
            end
        end
    end
    disp(MSE)
    %% Rx weight Space Time
    [RecFreq] = nrEqualizerSpaceTime(yDL,SysPara,pilotout);
    clear yDL;
    
    %% Euclidean Gradient Calculate
%     [timePrecoderW] = QNNBiSectionMethod(SysPara,genieChanFreq,RecFreq,timePrecoderW,pilotout);
    
    %% Manifold Optizimation

     [timePrecoderW,MMSEIterationblockIndx] = QNNManifoldOpt(SysPara,RecFreq,genieChanFreq,pilotout,noise,timePrecoderW,blockIndx);
     MMSEIteration = [MMSEIteration,MMSEIterationblockIndx(2:end)];
 
    
    %% SumRate Test
    sumrate = 0;
    publicTerm = zeros(subcarriersK,P,Nds);
    for kk = 1:subcarriersK
        if kk <= numSubCar/2 || kk >= subcarriersK-numSubCar/2+1
            for uulocal = 1:P
                for ddlocal = 1:Nds
                    chanuu = squeeze(genieChanFreq{uulocal}(kk,:,:))* kron(DFTmtxInput(kk,1:weightLen),eye(Tx)); %Rx X Tx
                    recCoeffuudd = squeeze(RecFreq(:,kk,uulocal,ddlocal));
                    desiredPow = abs(recCoeffuudd'*chanuu*timePrecoderW(:,(uulocal-1)*Nds + ddlocal)).^2;
                    for uu = 1:P
                        for dd = 1:Nds
                            publicTerm(kk,uulocal,ddlocal) = publicTerm(kk,uulocal,ddlocal) + abs(recCoeffuudd' *chanuu * timePrecoderW(:,(uu-1)*Nds + dd)).^2;
                        end
                    end
                    interferencePow = publicTerm(kk,uulocal,ddlocal) - desiredPow;
                    sumrate = sumrate + log2(1+ desiredPow/(interferencePow + 1e-5*norm(recCoeffuudd,'fro').^2) );
                end
            end
        end
    end
    disp(sumrate);
    SumRate = [SumRate,sumrate];

end

end

