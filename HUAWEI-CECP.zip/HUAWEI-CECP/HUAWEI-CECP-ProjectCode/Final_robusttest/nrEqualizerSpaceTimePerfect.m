function [wFreq] = nrEqualizerSpaceTimePerfect(SysPara,genieChanFreq,timePrecoderW)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
Tx = SysPara.Tx;  % Transmit Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
Rx = SysPara.Rx;  % Receive Antennas
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
numRB = SysPara.numRB;
weightLen = SysPara.weightLen;
numSubCar = 12*numRB;
% locFreq = [subcarriersK-numSubCar/2+1:subcarriersK,1:numSubCar/2];
locFreq = [1:numSubCar/2,subcarriersK-numSubCar/2+1:subcarriersK];
RecTapsQ = 4;

%% Equalization in time domain
disp('Spatial-time')
% DFTTrun = dftmtx(subcarriersK);
DFTTrun = dftmtx(numSubCar);
wFreq = zeros(Rx,subcarriersK,P,Nds);

for uu = 1:P
    for dd = 1:Nds
        counter = 0;
        autoCorr = 0;
        crossCorr = 0;
%         noiseCounter = 0;
        for kk = 1:subcarriersK
            if kk <= numSubCar/2 || kk >= subcarriersK-numSubCar/2+1
                counter = counter + 1;
                Fbarkk = kron(DFTTrun(counter,1:RecTapsQ),eye(Rx));
                Huukk = squeeze(genieChanFreq{uu}(kk,:,:));
                Huukkbar = Fbarkk'*Huukk;
                Wkkbar = kron(DFTTrun(counter,1:weightLen),eye(Tx))*timePrecoderW;
%                 noiseCounter = noiseCounter + Fbarkk'*1e-5*eye(Rx)*Fbarkk;
                autoCorr = autoCorr + Huukkbar * Wkkbar * Wkkbar' * Huukkbar' + Fbarkk'*1e-2*eye(Rx)*Fbarkk;
                crossCorr = crossCorr + Huukkbar * Wkkbar(:,(uu-1)*Nds + dd);
            end

        end
        wt = autoCorr\crossCorr;
        counter = 0;
        for kk = 1:subcarriersK
            if kk <= numSubCar/2 || kk >= subcarriersK-numSubCar/2+1
                counter = counter + 1;
                Fbarkk = kron(DFTTrun(counter,1:RecTapsQ),eye(Rx));
                wFreq(:,kk,uu,dd) = Fbarkk*wt;
            end
        end
    end

end

end

