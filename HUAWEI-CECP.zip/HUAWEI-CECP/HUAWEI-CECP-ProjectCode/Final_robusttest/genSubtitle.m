function subtTxt =genSubtitle(monteCarloNum,SysPara)
subtTxt = [' Tx =' num2str(SysPara.Tx) '  Rx =' num2str(SysPara.Rx)...
'  Users =' num2str(SysPara.P) '  Stream =' num2str(SysPara.Nds) '  Subcarriers =' num2str(SysPara.subcarriersK)...
 '  L =' num2str(SysPara.tapsN) ' chanDimPerUser =' num2str(SysPara.SingleUserDim)   ' channEstError = ' num2str(pow2db(1./SysPara.channEstError).')];


 end