function [pilotOutput] = PilotGeneCECP2(numRB,ExtendedPilotIdx)
%UNTITLED2 此处显示有关此函数的摘要
%   此处显示详细说明
pilotOutput = zeros(numRB*12,2,ExtendedPilotIdx*48); %[RBlength, double symbol, 24UE]


[r0,r1,r2] = PDSCH_dmrs(numRB);

if ExtendedPilotIdx == 1
    FreqOCC = hadamard(8);
    TimeOCC = hadamard(2);
    for nn = 1:numRB/2
        for uu = 1:ExtendedPilotIdx*48
            currentuuCDMGroup = floor((uu-1)/16); % 0,1,2 three groups
            realUUIdx = uu - currentuuCDMGroup*16;
            realUUIdxGroup = floor((realUUIdx-1)/8); % CDM interuser group 0,1
            wf = FreqOCC(realUUIdx - 8*realUUIdxGroup,:);
            wt = TimeOCC(realUUIdxGroup+1,:);
            if currentuuCDMGroup == 0
                deltaoffset = 0;
                for ll = 1:2
                    for kbar = 1:8
                        if kbar <=4
                            
                            pilotOutput(24*(nn-1) + deltaoffset + kbar,ll,uu) = wf(kbar)*wt(ll)*r0(8*(nn-1) + kbar);
                        else
                            pilotOutput(24*(nn-1) + deltaoffset + kbar + 8,ll,uu) = wf(kbar)*wt(ll)*r0(8*(nn-1) + kbar);
                        end
                    end
                end
                
            elseif currentuuCDMGroup == 1
                deltaoffset = 4;
                for ll = 1:2
                    for kbar = 1:8
                        if kbar <=4
                            
                            pilotOutput(24*(nn-1) + deltaoffset + kbar,ll,uu) = wf(kbar)*wt(ll)*r1(8*(nn-1) + kbar);
                        else
                            pilotOutput(24*(nn-1) + deltaoffset + kbar + 8,ll,uu) = wf(kbar)*wt(ll)*r1(8*(nn-1) + kbar);
                        end
                    end
                end
            else
                deltaoffset = 8;
                for ll = 1:2
                    for kbar = 1:8
                        if kbar <=4
                            
                            pilotOutput(24*(nn-1) + deltaoffset + kbar,ll,uu) = wf(kbar)*wt(ll)*r2(8*(nn-1) + kbar);
                        else
                            pilotOutput(24*(nn-1) + deltaoffset + kbar + 8,ll,uu) = wf(kbar)*wt(ll)*r2(8*(nn-1) + kbar);
                        end
                    end
                end
            end
        end
    end
else
    FreqOCC = hadamard(16);
    TimeOCC = hadamard(2);
    for nn = 1:numRB/4
        for uu = 1:ExtendedPilotIdx*48
            currentuuCDMGroup = floor((uu-1)/32); % 0,1,2 three groups
            realUUIdx = uu - currentuuCDMGroup*32;
            realUUIdxGroup = floor((realUUIdx-1)/16); % CDM interuser group 0,1
            wf = FreqOCC(realUUIdx - 16*realUUIdxGroup,:);
            wt = TimeOCC(realUUIdxGroup+1,:);
            if currentuuCDMGroup == 0
                deltaoffset = 0;
                for ll = 1:2
                    for kbar = 1:16
                        if kbar <=8
                            pilotOutput(48*(nn-1) + deltaoffset + kbar,ll,uu) = wf(kbar)*wt(ll)*r0(16*(nn-1) + kbar);
                        else
                            pilotOutput(48*(nn-1) + deltaoffset + kbar + 16,ll,uu) = wf(kbar)*wt(ll)*r0(16*(nn-1) + kbar);
                        end
                    end
                end
                
            elseif currentuuCDMGroup == 1
                deltaoffset = 8;
                for ll = 1:2
                    for kbar = 1:16
                        if kbar <=8
                            pilotOutput(48*(nn-1) + deltaoffset + kbar,ll,uu) = wf(kbar)*wt(ll)*r1(16*(nn-1) + kbar);
                        else
                            pilotOutput(48*(nn-1) + deltaoffset + kbar + 16,ll,uu) = wf(kbar)*wt(ll)*r1(16*(nn-1) + kbar);
                        end
                    end
                end
            else
                deltaoffset = 16;
                for ll = 1:2
                    for kbar = 1:16
                        if kbar <=8
                            pilotOutput(48*(nn-1) + deltaoffset + kbar,ll,uu) = wf(kbar)*wt(ll)*r2(16*(nn-1) + kbar);
                        else
                            pilotOutput(48*(nn-1) + deltaoffset + kbar + 16,ll,uu) = wf(kbar)*wt(ll)*r2(16*(nn-1) + kbar);
                        end
                    end
                end
            end
        end
    end
end

% temp = 0;
% for uu = 1:ExtendedPilotIdx*48-1
%     for uu2 = uu + 1 : ExtendedPilotIdx*48
%         a = squeeze(pilotOutput(:,1,uu));
%         a2 = squeeze(pilotOutput(:,1,uu2));
%         b = squeeze(pilotOutput(:,2,uu));
%         b2 = squeeze(pilotOutput(:,2,uu2));
%         temp = temp + a'*b + a2'*b2;
%     end
% end

end