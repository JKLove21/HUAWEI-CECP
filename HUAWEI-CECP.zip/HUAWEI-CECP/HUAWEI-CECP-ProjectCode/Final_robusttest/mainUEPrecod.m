clear all
clear global
%% Construct Parameters

[SysPara] = ConstructParameters;
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio

%% Test Part
SICapa = [];
FIRLenRange = length(ceil((tapsN-1)/(Tx/(P*Rx)-1))+1:10:ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 + 40); % Time domain FIR filter length range
MaximumEquivalentChannelLen = 2; % Compare the effect of equivalent channel length
MICapa = zeros(MaximumEquivalentChannelLen,FIRLenRange); % You can view the variation of channel capacity about MaximumEquivalentChannelLen and FIRLenRange

MonteCarloNum = 1;
for testNum = 1:MonteCarloNum
    %% Global Seed
    rng(testNum);
%     [muMimoChanCell,~] = muMimoChan_interface(SysPara,chanTime); % Accept time domain channel (size == [subcarriersK Rx Tx P])
    [muMimoChanCell,~] = muMimoChan_gen(SysPara); % Generate NRCDL Channel
    counter = 0;
    for weightLen = ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 :10:ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 + 50
        counter = counter + 1;
        SysPara.weightLen = weightLen;
        %% Aggregated Block Toeplitz Channel Matrix T Generation
%         [HtimeToep,Hfreq] = channelGen(SysPara);
        [HtimeToep,Hfreq] = AggreTGen(muMimoChanCell,SysPara); % Generate T based on NRCDL Channel
        %% User Precoding
        [EZFCapacity] = EZF(SysPara,Hfreq);
        [EZFCapacityUEPrecod,capacitySingle] = UserPrecoding(Hfreq,SysPara);
        SICapa = [SICapa, capacitySingle];
        MICapa(1,counter) = capacitySingle;
        clear Hdesired Qzf
    end
end
% plot([ceil((tapsN-1)/(Tx/(P*Rx)-1))+1:10:ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 + 40],SICapa);
% hold on;
plot(1:MaximumEquivalentChannelLen,MICapa(:,end));
hold on;
plot(1:MaximumEquivalentChannelLen,MICapa(:,end-1));
xlabel('Equivalent Channel Length')
ylabel('Channel Capacity bps/Hz')
title('Capacity v.s. Equivalent Channel Length')

plot(ceil((tapsN-1)/(Tx/(P*Rx)-1))+1:10:ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 + 40,MICapa(1,:));
hold on;
plot(ceil((tapsN-1)/(Tx/(P*Rx)-1))+1:10:ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 + 40,MICapa(MaximumEquivalentChannelLen,:));
xlabel('Time-domain FIR Filter Length')
ylabel('Channel Capacity bps/Hz')
title('Capacity v.s. Time-domain FIR Filter Length')