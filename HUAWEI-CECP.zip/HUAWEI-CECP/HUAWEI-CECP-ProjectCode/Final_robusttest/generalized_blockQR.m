function [Rfinal] = generalized_blockQR(T,M,P)
% Junkai Liu QR decomposition method for special complex block Toeplitz matrix

% R = chol(T*T');
%% input T,M,P 

TH=T'; % TH=MQ*NP
[row,col] = size(TH);
N = col/P;
Q = row/M;

T0=TH(1:Q,1*P);
u1=TH(1:Q,P+1:end)';
v1=TH(Q+1:end,1:P);
v2=TH(end-Q+1:end,1:end-P)';


tmp1 = TH(:,1:P);
R11 = chol(tmp1'*tmp1);

zH = (T(P+1:end,:)*tmp1*inv(R11))';

R1 = [zeros((N-1)*P,(N-1)*P);zH;v2'];
R2 = [zeros((N-1)*P,(N-1)*P);u1'];
R2(1:P,:) = [R11,zH(:,1:end-P)];
for kk = 1:N-1
    for pp = 1:P
        n = (kk-1)*P + pp;
        
        % household 1
        RT_temp=[R2(n,:);R2(end-Q+1:end,:)];
        [H] = complexHouse(RT_temp,1+Q,n);
        RT_new = H*RT_temp;
        R2(n,:)=RT_new(1,:);
        R2(end-Q+1:end,:)=RT_new(2:end,:);


        % household 2
        ZT_temp=R1((N-1)*P+1:end,:);
        [H]=complexHouse(ZT_temp,P+Q,n);
        ZT_new=H*ZT_temp;
        R1((N-1)*P+1:end,:)=ZT_new;
        tmpZT = ZT_new(:,n:end);


        r11 = R2(n,n);
        sinthetaephi = R1((N-1)*P+1,n)/r11;
        phi = -angle(sinthetaephi);
        theta = asin(abs(sinthetaephi));
        Givens = [cos(theta),-sin(theta)*exp(1i*phi);sin(theta)*exp(-1i*phi),cos(theta)];
        NewGiven = Givens';
        
        tmp2 = zeros(1,((N-1)*P - n +1));
        IDX = 1;
        % X
        for idx = n:(N-1)*P      
            tmp2(IDX) = (R2(n,idx)-NewGiven(1,2)*tmpZT(1,IDX))/NewGiven(1,1);
            IDX = IDX + 1;
        end
        concatMatrix = [tmp2;tmpZT(1,:)];
        
        % update X
        tmp3 = NewGiven*concatMatrix;
        R1((N-1)*P+1,n:end)= tmp3(2,:);
        R1(n,n:end) = concatMatrix(1,:);
        if kk < N-1
            R2(n+P,n+P:end) = R1(n,n:end-P);
        end
    end
end
%% ouput R
Rfinal = [[R11 zH];[zeros((N-1)*P,P) R1(1:(N-1)*P,:)]];
end

