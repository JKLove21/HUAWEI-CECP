function [capacityManifoldCGMethod,T] = MFGradDesMulti(Tinitial,SysPara)
%UNTITLED6 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
global pointSeq

Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per 

manifold = spherecomplexfactory(length(pointSeq)*Rx*P,Nds);
problem.M = manifold;
problem.cost  = @objectFunMulti;
problem.egrad = @EuclideanGradTMulti;
% checkgradient(problem);

iterNum = 2*SysPara.iterNum;
Operation.maxiter = iterNum;
[T,cost,info,options] = conjugategradient(problem,Tinitial,Operation);

capacityManifoldCGMethod = [];
for ii = 1:length(info)
    capacityManifoldCGMethod = [capacityManifoldCGMethod,abs(info(ii).cost)];
end
end

