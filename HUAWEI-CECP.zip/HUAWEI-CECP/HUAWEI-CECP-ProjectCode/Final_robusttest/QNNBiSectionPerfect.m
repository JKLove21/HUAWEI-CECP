function [timeWBiSec] = QNNBiSectionPerfect(SysPara,RecFreq,genieChanFreq)
global RecFreq
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
weightLen = SysPara.weightLen;
numRB = SysPara.numRB;
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
numSubCar = 12*numRB;

RtimeW = zeros(Tx*weightLen,Tx*weightLen,P,Nds);
crosstiemW = zeros(Tx*weightLen,P,Nds);


% DFTmtxInput = dftmtx(subcarriersK);
DFTmtxInput = dftmtx(numSubCar);
%% Euclidean Gradient
% for uulocal = 1:P
%     for ddlocal = 1:Nds
%         tmp1 = 0;
%         tmp2 = 0;
%         counter = 0;
%         for kk = 1:subcarriersK
%             if kk <= numSubCar/2 || kk >= subcarriersK-numSubCar/2+1
%                 counter = counter + 1;
%                 ChanneluulocalkkBar = squeeze(genieChanFreq{uulocal}(kk,:,:)) * kron(DFTmtxInput(counter,1:weightLen),eye(Tx)); %Rx X Tx
%                 recCoeffuulocalddlocal = squeeze(RecFreq(:,kk,uulocal,ddlocal));  
%                 for uu = 1:P
%                     ChanneluukkBar = squeeze(genieChanFreq{uu}(kk,:,:)) * kron(DFTmtxInput(counter,1:weightLen),eye(Tx)); %Rx X Tx           
%                     for dd = 1:Nds
%                         recCoeffuudd = squeeze(RecFreq(:,kk,uu,dd));
%                         tmp1 = tmp1 + ChanneluukkBar' * recCoeffuudd * recCoeffuudd' * ChanneluukkBar;
%                     end
%                 end
%                 tmp2 = tmp2 +  ChanneluulocalkkBar' * recCoeffuulocalddlocal;
%             end
%         end
%         RtimeW(:,:,uulocal,ddlocal) = tmp1;
%         crosstiemW(:,uulocal,ddlocal) = tmp2;
%     end
% end

crossVecUser = zeros(weightLen*Tx,Nds,P);
RautoMtx = 0;
for uu = 1:P
    counter = 0;
    for kk = 1:subcarriersK
        if kk <= numSubCar/2 || kk >= subcarriersK-numSubCar/2+1
            counter = counter + 1;
            ChanneluukkBar = squeeze(genieChanFreq{uu}(kk,:,:)) * kron(DFTmtxInput(counter,1:weightLen),eye(Tx));
            recCoeffuudd = squeeze(RecFreq(:,kk,uu,:));
            tmp1 = ChanneluukkBar' * recCoeffuudd;
            crossVecUser(:,:,uu) = crossVecUser(:,:,uu) + tmp1;
            RautoMtx = RautoMtx + tmp1 * tmp1';
        end
    end
end

lower = 0;
upper = 1e6;
errVal = 10;
while ((abs(errVal)>1e-1) && (upper >= 1e-10))
    lambdaVal = (lower + upper )/2;
    timeWBiSec = [];
%     for uulocal = 1:P
%         for ddlocal = 1:Nds
%             timeWBiSec = [timeWBiSec,(squeeze(RtimeW(:,:,uulocal,ddlocal)) + lambdaVal * eye(Tx*weightLen))\squeeze(crosstiemW(:,uulocal,ddlocal))];
%         end
%     end
     for uulocal = 1:P
        timeWBiSec = [timeWBiSec,(RautoMtx + lambdaVal * eye(Tx*weightLen))\squeeze(crossVecUser(:,:,uulocal))];
    end 
    errVal = norm(timeWBiSec,'fro') - 1;
    if errVal > 0
        lower = lambdaVal;
    else
        upper = lambdaVal;
    end
end

end

