function [R_final] = generalized_scalarQR(T)
% Junkai Liu QR decomposition method for special complex scalar Toeplitz matrix
TH=T';
[~,x]=qr(TH);
[M,N]=size(TH);
t0=TH(1,1);
v1=TH(2:end,1);
v2=TH(end,1:end-1)';
T0=TH(2:end,2:end);
u1=TH(1,2:end)';
r11 = sqrt(t0*t0' + v1'*v1);
z=(T(2:end,:)*[TH(1:end,1)])/r11; zH=z';

R2 = [zeros(N-1,N-1) ;u1'];
R1 = [zeros(N-1,N-1);zH;v2'];
R2(1,:) = [r11,zH(1:end-1)];

for ii=1:N-1
    [G1,y]=planerot([R2(ii,ii);R2(end,ii)]); %R2 Givens
    R2_r_t_new=G1*[R2(ii,:);R2(end,:)];
    R2(ii,:)=R2_r_t_new(1,:);
    R2(end,:)=R2_r_t_new(2,:);
    r11_G1=y(1);
    

    [Q1,y]=planerot([R1(end-1,ii);R1(end,ii)]); %R1 givens
    z_t_new=Q1*R1(end-1:end,:);
    R1(end-1:end,:)=z_t_new;

    sintheta_ephi=R1(end-1,ii)/R2(ii,ii);  % theta phi 
    phi = -angle(sintheta_ephi);
    theta = asin(abs(sintheta_ephi));
    Q2 = [cos(theta),sin(theta)*exp(1i*phi);-sin(theta)*exp(-1i*phi),cos(theta)];
    
    for jj=ii:N-1  % R1 iith row
        R1(ii,jj)=(R2(ii,jj)-Q2(1,2)*R1(end-1,jj))/Q2(1,1);
    end

    if ii ~=N-1    %R2 ii+1th update
        R2(ii+1,ii+1:end)=R1(ii,ii:end-1);
    end
    z_row=[R1(ii,:);R1(end-1,:)]; % R1 z row update
    temp=Q2*z_row;
    R1(end-1,:)=temp(2,:);   

end

R_final=[[r11 zH];[zeros(N-1,1) R1(1:N-1,:)]];
Q_fianl=TH/R_final;

end

