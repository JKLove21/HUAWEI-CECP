function [Htime_predict,A]=AR_predict_time(HL,SysPara)

Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
tapsN = SysPara.tapsN;
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
t_sample_num=size(HL,4);
%size(Hfreq) = (Rx,Tx,subcarriersK,t_sample_num)

HL=HL(:,:,1:tapsN,:);
Tf=7;
p=5;   % AR阶数
A=complex(rand(Rx,Tx,p),rand(Rx,Tx,p))/p*2;
% A=zeros(Rx,Tx,p);

%% LMS
miu=1.8;
iteration=15;
% Tf=7;  % symbol distance
mse=zeros(Rx,Tx,iteration);
% mse0=zeros(Rx,Tx,iteration);
counter=0;
record=zeros(Rx*Tx*iteration,1);
for rr=1:Rx
    for tt=1:Tx
        a_temp=squeeze(A(rr,tt,:));
        for n=1:iteration

            Hd=squeeze(HL(rr,tt,:,(n+p)*Tf-(Tf-1))).';
            H=squeeze(HL(rr,tt,:,(n+p-(1:p))*Tf-(Tf-1))).';
            e=Hd-a_temp'*H;                         % error
            a_temp=a_temp+miu*H*e'/tapsN;     % a updata

            mse(rr,tt,n)=norm(squeeze(HL(rr,tt,:,(n+p)*Tf-(Tf-1))) - squeeze(HL(rr,tt,:,(n+p-(1:p))*Tf-(Tf-1)))*a_temp,'fro');
            % mse0(rr,tt,n)=norm(squeeze(Hfreq(rr,tt,:,1)) - squeeze(Hfreq(rr,tt,:,n+p-(1:p)))*a_temp,'fro');
            counter=counter+1;
            record(counter)=Hd*Hd';
        end
        A(rr,tt,:)=reshape(a_temp,[1,1,p]);
    end
end


Htime_predict=zeros(Rx,Tx,tapsN);
for rr=1:Rx
    for tt=1:Tx
        Htime_predict(rr,tt,:)=squeeze(HL(rr,tt,:,(1+p-(1:p))*Tf-Tf+1))*squeeze(A(rr,tt,:));
    end
end

% plot mse

figure;
plot(squeeze(mse(1,1,:)))
% hold on
% plot(squeeze(mse0(1,1,:)))
xlabel('iteration', 'FontSize', 14) ;ylabel('mse', 'FontSize', 14);
title([ 'mse   阶数 p= ' num2str(p) '  步长 mu= ' num2str(miu)], 'FontSize', 14);






%% timetaps plot
% plot after p symbol
% H1=squeeze(HL(:,:,:,(1+p)*Tf-Tf+1));
% H2=Htime_predict;
% H0=squeeze(HL(:,:,:,1));
% H1_plot=zeros(1,tapsN);
% H2_plot=zeros(1,tapsN);
% H0_plot=zeros(1,tapsN);
% for kk=1:tapsN
%     H1_plot(kk)=trace(H1(:,:,kk)*H1(:,:,kk)');
%     H2_plot(kk)=trace(H2(:,:,kk)*H2(:,:,kk)');
%     H0_plot(kk)=trace(H0(:,:,kk)*H0(:,:,kk)');
% end
% figure
% plot(H1_plot);
% hold on
% plot(H2_plot);
% hold on
% plot(H0_plot);
% xlabel('subcarrier', 'FontSize', 14);
% legend('ture channel','predicted channel','without predict');
% title(['energy on  timetap  阶数 p=' num2str(p) '  步长 mu=' num2str(miu) '  after  ' num2str(p) ' symbol'], 'FontSize', 14);
%
% % plot after sample time
H_p=HL(:,:,:,(iteration+p+1-(1:p))*Tf-(Tf-1));
for ii = 1:floor((t_sample_num-((p+iteration)*Tf-(Tf-1)))/Tf)
    for rr=1:Rx
        for tt=1:Tx
            Htime_predict(rr,tt,:)=squeeze(H_p(rr,tt,:,:))*squeeze(A(rr,tt,:));
        end
    end
    H_p(:,:,:,2:p)=H_p(:,:,:,1:p-1);
    H_p(:,:,:,1)=Htime_predict;
end
%
% H3=squeeze(HL(:,:,:,t_sample_num-rem(t_sample_num+Tf-1,Tf)));
% H4=Htime_predict;
% H5=squeeze(HL(:,:,:,1));
% H3_plot=zeros(1,tapsN);
% H4_plot=zeros(1,tapsN);
% H5_plot=zeros(1,tapsN);
% for kk=1:tapsN
%     H3_plot(kk)=trace(H3(:,:,kk)*H3(:,:,kk)');
%     H4_plot(kk)=trace(H4(:,:,kk)*H4(:,:,kk)');
%     H5_plot(kk)=trace(H5(:,:,kk)*H5(:,:,kk)');
% end
% figure
% plot(H3_plot);
% hold on
% plot(H4_plot);
% hold on
% plot(H5_plot);
% xlabel('timetaps', 'FontSize', 14);
% legend('ture channel','predicted channel','without predict', 'FontSize', 12);
% title(['energy on each timetap  阶数 p=' num2str(p) '  步长 mu=' num2str(miu) '  after 20ms'], 'FontSize', 14);





end
