function [mimoChanCell2,genieChanFreq] = muMimoChan_interface(SysPara,chanTime)
% size(chanTime) == [subcarriersK Rx Tx P]
P = SysPara.P;    % User Terminals
subcarriersK = SysPara.subcarriersK; % Subcarriers Number

mimoChanCell2 = cell(P,1);
genieChanFreq = cell(P,1);
tapsN = max(mod(find(chanTime),subcarriersK));

for uu = 1:P
    pulseOutput = chanTime;
    mimoChanCell2{uu} = pulseOutput(1:tapsN,:,:,uu);
    [chanFreq] = getgenieChanFreq(SysPara,pulseOutput(:,:,:,uu));
    genieChanFreq{uu} = chanFreq;
end

end

