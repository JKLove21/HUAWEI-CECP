function [gradT] = EuclideanGradTMulti(T)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
global Rx subcarriersK SNR P Hdesired Qzf pointSeq


% F = dftmtx(subcarriersK);
% gradT = zeros(size(T));
% for uu = 1:P
%     value = 0;
%     Tuu = T((uu-1)*length(pointSeq)*Rx+[1:length(pointSeq)*Rx],:);
%     Hdesireduu = Hdesired{uu};
%     Qzfuu = Qzf{uu};
%     for kk = 1:subcarriersK
%         Fbar = kron(F(kk,pointSeq),eye(Rx));
%         Heffectkk = Fbar * Hdesireduu * Qzfuu;
%         Mpk = SNR*eye(size(Tuu,2))+( Heffectkk * Tuu )'* Heffectkk * Tuu ;
%         value = value - Heffectkk' * Heffectkk * Tuu / Mpk;
%     end
%     gradT((uu-1)*length(pointSeq)*Rx+[1:length(pointSeq)*Rx],:) = value;
% end
F = dftmtx(subcarriersK);
gradT = zeros(size(T));
for uu = 1:P
    value = 0;
    Tuu = T((uu-1)*length(pointSeq)*Rx+(1:length(pointSeq)*Rx),:);
    Hdesireduu = Hdesired{uu};
    Qzfuu = Qzf{uu};
    for kk = 1:subcarriersK
        Fbar = kron(F(kk,pointSeq),eye(Rx));
        % Heffectkk = Fbar * Hdesireduu * Qzfuu;
        Heffectkk = Fbar * (Qzfuu'*Qzfuu)^(-1/2);
        eqchanneluukk = Heffectkk * Tuu;
        combinertemp = inv(eqchanneluukk'*eqchanneluukk+SNR*eye(Rx))*eqchanneluukk';
        Heffectkk = combinertemp * Heffectkk;

        Mpk = SNR*eye(size(Tuu,2))+( Heffectkk * Tuu )'* Heffectkk * Tuu ;
        value = value - Heffectkk' * Heffectkk * Tuu / Mpk;
    end
    gradT((uu-1)*length(pointSeq)*Rx+(1:length(pointSeq)*Rx),:) = value;
end
end

