function [ACColChunk] = ACColChunkGen(Htmp,SysPara,l,Q)

Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
% K = SysPara.subcarriersK;
K = 500;

% HtmpRow1 = flip(Htmp,3);
% HtmpRow2 = reshape(HtmpRow1,[P*Rx,Tx*tapsN]);
% HcirculantFirstRow = circshift(HtmpRow2,[0,Tx]);
tic;
HcircRowK = reshape(flip(Htmp,3),[P*Rx,Tx*tapsN]);% The Kth row of Hcirc
HcircRow0 = circshift(HcircRowK,[0,Tx]);% The first row of Hcirc

ACCol0 = zeros((2*tapsN-1)*P*Rx,P*Rx);% The first column of autocorrelation of Hcirc
ACColChunk = zeros((2*tapsN-1)*P*Rx,Q*P*Rx);% Tagert chunk of autocorrelation of Hcirc

ACCol0(1:P*Rx,:) = HcircRow0*HcircRow0';
HcircRowTmp = HcircRow0;
for tidx = 1:tapsN-1
    HcircRowTmp(:,1:Tx) = zeros(P*Rx,Tx);
    HcircRowTmp = circshift(HcircRowTmp,[0,Tx]);
    HACtmp = HcircRowTmp*HcircRow0';
    ACCol0(1+tidx*P*Rx:(tidx+1)*P*Rx,:) = HACtmp;
    ACCol0((2*tapsN-tidx-1)*P*Rx+1:(2*tapsN-tidx)*P*Rx,:) = HACtmp';
end

ACColl = circshift(ACCol0,[l*P*Rx,0]);% The lth column of autocorrelation of Hcirc
for qidx = 0:Q-1
    ACColChunk(:,1+qidx*P*Rx:(qidx+1)*P*Rx) = circshift(ACColl,[qidx*P*Rx,0]);
end


t1 = toc

%% verify
% tic
% HtmpCol = reshape(permute(Htmp,[1,3,2]),[P*Rx*tapsN,Tx]);   % 2D Column Chunk
% HcircZeroCol = cat(1,HtmpCol,zeros((K-tapsN)*P*Rx,Tx));
% Hcirc = zeros(K*P*Rx,K*Tx);
% for tidx = 0:K-1
%     Hcirc(:,1+tidx*Tx:(tidx+1)*Tx) = circshift(HcircZeroCol,tidx*P*Rx);
% end
% Autocorrelation = Hcirc*Hcirc';
% ACColChunk1 = Autocorrelation(:,l*P*Rx+1:(l+Q)*P*Rx);
% t2 = toc
% 
% H1 =(abs(Hcirc)<0|abs(Hcirc)>0);
% figure
% subplot(2,1,1);
% imshow(H1)
% hold on
% H2 =(abs(Autocorrelation)>0|abs(Autocorrelation)<0);
% subplot(2,1,2);
% imshow(H2)
end