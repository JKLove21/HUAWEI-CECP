function [SINR]=SINR_calculate(a,b,c,v,Rnn,k)

desired=a(k,:)*v;
temp=0;
for ii=1:length(v)
    temp=temp+squeeze(b(k,:,ii))*v;
end
Undesired=temp-squeeze(b(k,:,k))*v;

Noise=sum(c.*(v.^2))*Rnn(k);

SINR=desired/(Undesired+Noise);

end