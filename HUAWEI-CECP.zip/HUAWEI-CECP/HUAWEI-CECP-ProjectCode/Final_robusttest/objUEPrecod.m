function [value] = objUEPrecod(T)
%UNTITLED3 此处显示有关此函数的摘要
%   此处显示详细说明
global  Tx Rx subcarriersK SNR Hfrequu QUE 

F = dftmtx(subcarriersK);
value = 0;

for kk = 1:subcarriersK
    Huukk = squeeze(Hfrequu(:,:,kk));
    Fbar = kron(F(kk,1:QUE),eye(Rx));
    Tkk = Fbar * T;
    value = value - real(log2(det(  eye(Tx) + 1/SNR*Huukk' * Tkk * (Huukk' * Tkk)' )));
end


end

