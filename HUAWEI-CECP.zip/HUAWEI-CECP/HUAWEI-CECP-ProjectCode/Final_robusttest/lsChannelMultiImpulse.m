function [NMSEMultiImpulse,NMSEMultiImpulseTimeDenoise,HfreqMultiImpulseEstInpoDenoise,HfreqMultiImpulse] = lsChannelMultiImpulse(SysPara,impulseShapeMulti,pointSeq,totalL)
%UNTITLED6 此处显示有关此函数的摘要
%   此处显示详细说明
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
weightLen = SysPara.weightLen; % ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 minimum FIR Length
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio
ExtendedPilotIdx = SysPara.ExtendedPilotIdx;

F = dftmtx(subcarriersK);
HfreqMultiImpulse = cell(P,subcarriersK);
for uu = 1:P
    extractImpulseuu = [];
    for nn = 1:length(pointSeq)
        extractImpulseuu = [extractImpulseuu;impulseShapeMulti{uu}((pointSeq(nn)-1)*Rx*P + 1 + (uu-1)*Rx : (pointSeq(nn)-1)*Rx*P + uu*Rx,:)]; % Extract Desired Channels
    end
    extractImpulseuutail = [];
    for mm = pointSeq(end)+1:weightLen + tapsN -1
        extractImpulseuutail = [extractImpulseuutail;impulseShapeMulti{uu}((mm-1)*Rx*P + 1 + (uu-1)*Rx : (mm-1)*Rx*P + uu*Rx,:)];
    end
    extractImpulseuuhead = [];
    for bb = 1:pointSeq(1) -1
        extractImpulseuuhead = [extractImpulseuuhead;impulseShapeMulti{uu}((bb-1)*Rx*P + 1 + (uu-1)*Rx : (bb-1)*Rx*P + uu*Rx,:)];
    end
    shiftedEffcChan = [extractImpulseuu;extractImpulseuutail;extractImpulseuuhead];
    for kk = 1:subcarriersK
        Fbar = kron(F(kk,1:weightLen + tapsN -1),eye(Rx));
        HfreqMultiImpulse{uu,kk} = Fbar * shiftedEffcChan;
    end
end


%% LS Est
if ExtendedPilotIdx == 1    
    baseNum = 2;
    [pilotOutput] = PilotGeneCECP2(subcarriersK/12,ExtendedPilotIdx);
    [HfreqMultiImpulseEst] = LSChannelEst2(SysPara,pilotOutput,HfreqMultiImpulse);
    % HfreqMultiImpulseEst = zeros(P,subcarriersK/12/baseNum,Rx,Nds);
    % [pilotOutput] = PilotGeneCECP(subcarriersK/12); %[subcarriersK,2,24] extend double
    % for uu = 1:P
    %     for kkidx = 1:subcarriersK/12/baseNum
    % 
    %         currentbaseNumber = floor((uu-1)/24); %% UserGroup Idx 0,1,...
    %         currentRealUUNumber = uu - currentbaseNumber*24;
    %         [locseq,wf,wt] = LSChannelEst(currentRealUUNumber);
    %         for ii = 1:length(locseq)
    %             pilot1 = squeeze(pilotOutput(locseq(ii) + (kkidx-1)*12,1,currentRealUUNumber));
    %             pilot2 = squeeze(pilotOutput(locseq(ii) + (kkidx-1)*12,2,currentRealUUNumber));
    %             noiseGene = 1/sqrt(2)*sqrt(SNR)*( (randn(Rx,Nds) + 1j*randn(Rx,Nds)) .* wt(1)./pilot1 + (randn(Rx,Nds) + 1j*randn(Rx,Nds)) * wt(2)./pilot2 )/2;
    %             currentChan = HfreqMultiImpulse{uu,locseq(ii) + currentbaseNumber*12 + (kkidx-1)*12*baseNum};
    %             HfreqMultiImpulseEst(uu,kkidx,:,:) = squeeze(HfreqMultiImpulseEst(uu,kkidx,:,:)) + currentChan + noiseGene .* wf(ii);
    %         end
    %         HfreqMultiImpulseEst(uu,kkidx,:,:) = squeeze(HfreqMultiImpulseEst(uu,kkidx,:,:))./length(locseq);
    %     end
    % end    
elseif ExtendedPilotIdx == 2
    baseNum = 4;
    [pilotOutput] = PilotGeneCECP2(subcarriersK/12,ExtendedPilotIdx);
    [HfreqMultiImpulseEst] = LSChannelEst2(SysPara,pilotOutput,HfreqMultiImpulse);
    % HfreqMultiImpulseEst = zeros(P,subcarriersK/12/baseNum,Rx,Nds);
    % [pilotOutput] = PilotGeneCECP(subcarriersK/12); %[subcarriersK,2,24] extend double
    % for uu = 1:P
    %     for kkidx = 1:subcarriersK/12/baseNum
    % 
    %         currentbaseNumber = floor((uu-1)/24); %% UserGroup Idx 0,1,...
    %         currentRealUUNumber = uu - currentbaseNumber*24;
    %         [locseq,wf,wt] = LSChannelEst(currentRealUUNumber);
    %         for ii = 1:length(locseq)
    %             pilot1 = squeeze(pilotOutput(locseq(ii) + (kkidx-1)*12,1,currentRealUUNumber));
    %             pilot2 = squeeze(pilotOutput(locseq(ii) + (kkidx-1)*12,2,currentRealUUNumber));
    %             noiseGene = 1/sqrt(2)*sqrt(SNR)*( (randn(Rx,Nds) + 1j*randn(Rx,Nds)) .* wt(1)./pilot1 + (randn(Rx,Nds) + 1j*randn(Rx,Nds)) * wt(2)./pilot2 )/2;
    %             currentChan = HfreqMultiImpulse{uu,locseq(ii) + currentbaseNumber*12 + (kkidx-1)*12*baseNum};
    %             HfreqMultiImpulseEst(uu,kkidx,:,:) = squeeze(HfreqMultiImpulseEst(uu,kkidx,:,:)) + currentChan + noiseGene * wf(ii);
    %         end
    %         HfreqMultiImpulseEst(uu,kkidx,:,:) = squeeze(HfreqMultiImpulseEst(uu,kkidx,:,:))./length(locseq);
    %     end
    % end
end

%% NMSE

HfreqMultiImpulseEstTime = ifft(HfreqMultiImpulseEst,floor(subcarriersK/12)/baseNum,2);
HfreqMultiImpulseEstInpoDenoise = fft(HfreqMultiImpulseEstTime(:,1:totalL,:,:),subcarriersK,2);

for ll=1:size(HfreqMultiImpulseEstTime,2)
    for uu=1:P
        eqtimechannelest_energy(uu,ll)=norm(squeeze(HfreqMultiImpulseEstTime(uu,ll,:,:)),'fro').^2;
    end
end
% eq1=impulseShapeMulti{1};
% for ll=1:size(eq1,1)/Rx/P
%     eqtimechannel_energy(ll)=norm(eq1((ll-1)*Rx*P+[1:Rx],:),'fro').^2;
% end
% bar(eqtimechannel_energy)
NMSEMultiImpulseTimeDenoise = 0;
for uu = 1:P
    for kk = 1:subcarriersK
       NMSEMultiImpulseTimeDenoise =  NMSEMultiImpulseTimeDenoise + norm(squeeze(HfreqMultiImpulseEstInpoDenoise(uu,kk,:,:))-HfreqMultiImpulse{uu,kk},'fro').^2/norm(HfreqMultiImpulse{uu,kk},'fro').^2;
    end
end

clear HfreqMultiImpulseEstTime HfreqMultiImpulseEstInpo

HfreqMultiImpulseEstTime = ifft(HfreqMultiImpulseEst,floor(subcarriersK/12)/baseNum,2);
HfreqMultiImpulseEstInpo = fft(HfreqMultiImpulseEstTime,subcarriersK,2);

NMSEMultiImpulse = 0;
for uu = 1:P
    for kk = 1:subcarriersK
       NMSEMultiImpulse =  NMSEMultiImpulse + norm(squeeze(HfreqMultiImpulseEstInpo(uu,kk,:,:))-HfreqMultiImpulse{uu,kk},'fro').^2/norm(HfreqMultiImpulse{uu,kk},'fro').^2;
    end
end

%% Test
% OriginalChan = zeros(subcarriersK,1);
% for kk = 1:subcarriersK
%     OriginalChan(kk) = HfreqMultiImpulse{1,kk}(1,1);
% end
% 
% plot(abs(OriginalChan));
% hold on;
% plot(abs(squeeze(HfreqMultiImpulseEstInpo(1,:,1,1))))

 end