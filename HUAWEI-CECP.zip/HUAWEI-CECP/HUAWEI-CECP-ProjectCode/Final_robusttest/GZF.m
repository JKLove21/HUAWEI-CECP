function [EZFCapacity,EZFEquiChan,EZFCapacityImperfect,EZFEquiChanImperfect] = GZF(SysPara,Hfreq,HfreqImperfect)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Rati

% Hfreq = 1/sqrt(2)*(randn(Rx*P,Tx,subcarriersK) + 1j*randn(Rx*P,Tx,subcarriersK));
% SNR = 1/db2pow(10*log10(20.5));
tmpFreq = zeros(subcarriersK,P);
EZFEquiChan = cell(P,subcarriersK);
EZFEquiChanImperfect = cell(P,subcarriersK);
EZFCapacity = 0;
EZFCapacityImperfect = 0;
EZFOriginal = 0;
for kk = 1:subcarriersK
    ezfPrecoder = zeros(Tx,P*Rx);
    Hv = [];
    for uu = 1:P
        channeluukk = squeeze(Hfreq((uu-1)*Rx + [1:Rx],:,kk));    
        Hv = [Hv;channeluukk];
    end
    temp = Hv'*inv(Hv*Hv');
    ezfPrecoder = temp/norm(temp,'fro');
    for uu = 1:P
        channeluukk = squeeze(Hfreq((uu-1)*Rx + [1:Rx],:,kk)); % Perfect Channel
        ezfPrecoderuu = ezfPrecoder(:,(uu-1)*Rx + [1:Rx]);
        tmpChanEqui = channeluukk*ezfPrecoderuu;
        EZFEquiChan{uu,kk} = tmpChanEqui;
        InterUserdet = 0;
        for uubar = 1:P
            if uubar ~= uu
                ezfPrecoderuubar = ezfPrecoder(:,(uubar-1)*Rx + [1:Rx]);
                InterUserdet = InterUserdet + channeluukk * ezfPrecoderuubar * (channeluukk * ezfPrecoderuubar)';
            end
        end
        EZFCapacity = EZFCapacity + log2(det( eye(Rx) + 1/SNR*(channeluukk*ezfPrecoderuu*ezfPrecoderuu'*channeluukk'+InterUserdet) )/det(eye(Rx) + 1/SNR*InterUserdet ));
        EZFOriginal = EZFOriginal + log2(det( eye(Rx) + 1/SNR*channeluukk*ezfPrecoderuu*ezfPrecoderuu'*channeluukk' ));
    end
    %% Imperfect Channel Capacity
    for uu = 1:P
        channeluukk = squeeze(HfreqImperfect((uu-1)*Rx + [1:Rx],:,kk)); % Imperfect Perfect Channel
        ezfPrecoderuu = ezfPrecoder(:,(uu-1)*Rx + [1:Rx]);
        tmpChanEquiImperfect = channeluukk*ezfPrecoderuu;
        EZFEquiChanImperfect{uu,kk} = tmpChanEquiImperfect;
        InterUserdet = 0;
        for uubar = 1:P
            if uubar ~= uu
                ezfPrecoderuubar = ezfPrecoder(:,(uubar-1)*Rx + [1:Rx]);
                InterUserdet = InterUserdet + channeluukk * ezfPrecoderuubar * (channeluukk * ezfPrecoderuubar)';
            end
        end
        EZFCapacityImperfect = EZFCapacityImperfect + log2(det( eye(Rx) + 1/SNR*(channeluukk*ezfPrecoderuu*ezfPrecoderuu'*channeluukk'+InterUserdet) )/det( eye(Rx) + 1/SNR*InterUserdet));
    end

end

end