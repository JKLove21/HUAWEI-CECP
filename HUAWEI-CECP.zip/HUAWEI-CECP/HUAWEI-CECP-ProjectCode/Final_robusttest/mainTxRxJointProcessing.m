clear all
clear global
warning off;
%% Construct Parameters

[SysPara] = ConstructParameters;
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio

MonteCarloNum = 1;
for testNum = 1:MonteCarloNum
    rng(testNum);
    %% Generate 5GNRCDL Channel
    [~,genieChanFreq] = muMimoChan_gen(SysPara);

    
    [muMimoChanCell,~] = muMimoChan_gen(SysPara); % Generate NRCDL Channel
    [HtimeToep,Hfreq,HtimeToepImperfect, HfreqImperfect] = AggreTGen(muMimoChanCell,SysPara); % Generate T based on NRCDL Channel
    [EZFCapacity,EZFEquiChan,EZFCapacityImperfect,EZFEquiChanImperfect] = EZF(SysPara,Hfreq,HfreqImperfect);
    genieChanFreq2 = cell(P,1);
    for uu =1:P
        tmp = zeros(subcarriersK,Rx,Tx);
        for kk =1:subcarriersK
            tmp(kk,:,:) = Hfreq((uu-1)*Rx + [1:Rx],:,kk); 
        end
        genieChanFreq2{uu} = tmp;
    end
    % load('genieChanFreq.mat')
    for weightLen = 15
        SysPara.weightLen = weightLen;
        %% A Quasi Neural Network Scheme
        [SumRate] = QNNBroadBand(SysPara,genieChanFreq2);
    end
end


