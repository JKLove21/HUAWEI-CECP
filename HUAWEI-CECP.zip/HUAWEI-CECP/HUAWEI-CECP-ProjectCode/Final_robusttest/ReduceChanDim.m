function HtimeLowDim = ReduceChanDim(TimeChanRes,SysPara)

Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
subcarriersK = SysPara.subcarriersK;
tapsN = SysPara.tapsN;
dim = SysPara.SingleUserDim;

Hfreq = zeros(subcarriersK,Rx,Tx);
HfreqLowDim = zeros(subcarriersK,dim,Tx);
HtimeLowDim = zeros(subcarriersK,dim,Tx);

%% correlation matrix sum ver
for ii = 1:Rx
    for jj = 1:Tx
        Hfreq(:,ii,jj) = fft(TimeChanRes(:,ii,jj),subcarriersK);
    end
end
CorrMat = zeros(Rx,Rx);
% Calculate Hfreq
for kk = 1:subcarriersK
    HfreqTmp = squeeze(Hfreq(kk,:,:));
    CorrMat = CorrMat+HfreqTmp*HfreqTmp';
end
[~, ~, v] = svd(CorrMat);
PrecodMat = v(:,1:dim)';
for kk = 1:subcarriersK
    HfreqLowDim(kk,:,:) = PrecodMat*squeeze(Hfreq(kk,:,:)); 
end
% Calculate HtimeLowDim
for ii = 1:dim
    for jj = 1:Tx
        HtimeLowDim(:,ii,jj) = ifft(HfreqLowDim(:,ii,jj),subcarriersK);
    end
end

HtimeLowDim = HtimeLowDim(1:tapsN,:,:);
%% channel matrix sum ver
% for ii = 1:Rx
%     for jj = 1:Tx
%         Hfreq(:,ii,jj) = fft(TimeChanRes(:,ii,jj),subcarriersK);
%     end
% end
% HfreqSum = zeros(Rx,Tx);
% % Calculate Hfreq
% for kk = 1:subcarriersK
%     HfreqTmp = squeeze(Hfreq(kk,:,:));
%     HfreqSum = HfreqSum+HfreqTmp;
% end
% CorrMat = HfreqSum*HfreqSum';
% [~, ~, v] = svd(CorrMat);
% PrecodMat = v(:,1:dim)';
% for kk = 1:subcarriersK
%     HfreqLowDim(kk,:,:) = PrecodMat*squeeze(Hfreq(kk,:,:)); 
% end
% % Calculate HtimeLowDim
% for ii = 1:dim
%     for jj = 1:Tx
%         HtimeLowDim(:,ii,jj) = ifft(HfreqLowDim(:,ii,jj),subcarriersK);
%     end
% end
% 
% HtimeLowDim = HtimeLowDim(1:tapsN,:,:);
end