function [mimoChanCell2,mimoChanCell_predict] = muMimoChan_gen_new(SysPara)
%
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
mimoChanCell = cell(P,Tx);
T_select=2;
mimoChanCell2 = cell(P,3);
mimoChanCell_predict = cell(P,1);
genieChanFreq = cell(P,1);
singularValueCell = cell(P,1);
T0=1/(SysPara.fsHz/subcarriersK)*SysPara.fsHz;       %T_length for one symble  =subcarrierK
T=40*14*T0;
t_last=T/SysPara.fsHz;  %mimoChan.SampleRate = SysPara.fsHz;

% chanMtx = zeros(subcarriersK,Rx,Tx,P);
for uu = 1:P
    userSeed = 7*SysPara.Seed+42*uu+66;
    % pulseInput = zeros(T,Tx);
    [mimoChan] = channel_gen(SysPara,userSeed);
    mimoChanCell(uu,:) = repmat({mimoChan},1,Tx);
    nrCDL = mimoChan;

    cdlinfo = info(nrCDL);
    Delay = cdlinfo.PathDelays;
    % s_in = complex(randn(T,Tx),randn(T,Tx));
    % s_in = ones(T,Tx);
    s_in = zeros(T,Tx);
    s_in(1,1) = 1;
    % s_in(1,:) = ones(1,Tx);
    [s_out,PathGains,sampletimes] = nrCDL(s_in);
    % pathgains = squeeze(sum(PathGains,2));

    sinc_L = 40;              %sinc采样抽头数
    SR = nrCDL.SampleRate;    %采样速率
    t_sample_num=length(sampletimes);
    HL = zeros(Rx,Tx,sinc_L,t_sample_num);
    for t = 1:t_sample_num
        for fl = 1:sinc_L
            for p = 1:size(PathGains,2)
                HL(:,:,fl,t) = HL(:,:,fl,t) + squeeze(PathGains(t,p,:,:)).'*sinc(fl-1-Delay(p)*SR);            %计算出每个时刻上各个抽头的系数
            end
        end
    end
    HL_energy=zeros(t_sample_num,sinc_L);
    for tt=1:t_sample_num
        for fl = 1:sinc_L
            HL_energy(tt,fl)=trace(HL(:,:,fl,tt)*HL(:,:,fl,tt)');
        end
    end
    
    % predict
    Tf=7;      %Interval length for predict
    [Htime_predict,A]=AR_predict_time(HL,SysPara);
    % chanFreq = zeros(Rx,Tx,subcarriersK,t_sample_num);
    % for tt=1:t_sample_num
    %     for ii = 1:Rx
    %         for jj = 1:Tx
    %             % Htime_seq=squeeze(pulseOutput(:,ii,jj));
    %             Htime_seq=squeeze(HL(ii,jj,:,tt));
    %             if length(Htime_seq)~=subcarriersK
    %                 Htime_seq=[Htime_seq ;zeros(subcarriersK-length(Htime_seq),1)];
    %             end
    %             chanFreq(ii,jj,:,tt) = fft(Htime_seq,subcarriersK);
    %         end
    %     end
    % end
    % [Hfreq_predict,A]=AR_predict_freq(chanFreq,SysPara);
    % % mesh OFDM time-varying
    % HL_fenergy=zeros(t_sample_num,subcarriersK);
    % for tt=1:t_sample_num
    %     for kk=1:subcarriersK
    %         HL_fenergy(tt,kk)=trace(chanFreq(:,:,kk,tt)*chanFreq(:,:,kk,tt)');
    %     end
    % end
    % figure;
    % [X, Y] = meshgrid(1:size(HL_fenergy,1), 1:size(HL_fenergy,2));
    % mesh(X, Y, HL_fenergy.');
    % xlabel("OFDM symbol ");ylabel('carrier');
    % %Hfreq
    % Htime_predict=zeros(Rx,Tx,subcarriersK);
    % for ii = 1:Rx
    %     for jj = 1:Tx
    %         % Htime_seq=squeeze(pulseOutput(:,ii,jj));
    %         Hfreq_seq=squeeze(Hfreq_predict(ii,jj,:));
    %         Htime_predict(ii,jj,:) = ifft(Hfreq_seq,subcarriersK);
    %     end
    % end
    Htimetaps_predict=zeros(1,tapsN);
    for kk=1:tapsN
        Htimetaps_predict(kk)=trace(Htime_predict(:,:,kk)*Htime_predict(:,:,kk)');
    end
    % figure
    % plot(Htimetaps_predict);
    %% short length
    % s_out2 = zeros(size(s_out));
    % HL0 = zeros(Rx,Tx,sinc_L,T);
    % t_point_num=round((sampletimes(2)-sampletimes(1))*SR);
    % for tt = 1:t_sample_num
    %     if tt<t_sample_num
    %        HL0(:,:,:,(tt-1)*t_point_num+(1:t_point_num))=repmat(HL(:,:,:,tt),[1,1,1,t_point_num]);
    %     else
    %        HL0(:,:,:,((tt-1)*t_point_num+1):end,:)=repmat(HL(:,:,:,tt),[1,1,1,T-(tt-1)*t_point_num]);
    %     end
    % end
    %
    % s_in2 = [zeros(tau,Tx);s_in(1:T-tau,:)];
    % for t = 7:T
    %     for l = 1:sinc_L
    %         if t-(l-1)>0
    %             s_out2(t,:) = s_out2(t,:)+s_in2(t-(l-1),:)*HL0(:,:,l,t).';                                     %卷积
    %         end
    %     end
    % end
    %% long length
    tau = cdlinfo.ChannelFilterDelay;
    s_out3 = zeros(size(s_out));
    s_in3 = [zeros(tau,Tx);s_in(1:T-tau,:)];
    for t = 7:100
        for l = 1:sinc_L
            if t-(l-1)>0
                s_out3(t,:) = s_out3(t,:)+s_in3(t-(l-1),:)*HL(:,:,l,1).';                                     %卷积
            end
        end
    end


    %%
    % figure
    % % plot(time(1:T-tau),abs(s_out(1+tau:end,2)),'o-','LineWidth',1.5);hold on;
    % time = nrCDL.InitialTime+ ((0:(T-1))).' / SR;
    % plot(time(1:100),abs(s_out(1:100,1)),'o-','LineWidth',1.5);hold on;
    % % plot(time(1:100),abs(s_out2(1:100,1)),'o-','LineWidth',1.5);
    % plot(time(1:100),abs(s_out3(1:100,1)),'o-','LineWidth',1.5)
    % legend('MATLAB函数运算的结果','根据多径增益及时延sinc插值得到结果')
    % xlabel('时间(秒)')
    % ylabel('幅度')

    % Htemp=squeeze(HL(:,:,:,1));
    % Htime_taps=zeros(1,sinc_L);
    % for ll=1:sinc_L
    %     Htime_taps(ll)=trace(Htemp(:,:,ll)'*Htemp(:,:,ll));
    % end
    %
    % figure
    % stem(Htime_taps);
    % T_period=floor(t_sample_num/T_select);
    Henergy_taps_temp=zeros(3,tapsN);
    for ii=1:3
        % Htime_taps_temp=squeeze(HL(:,:,:,(ii-1)*T_period+1));
        if ii==1
            Htime_taps_temp=squeeze(HL(:,:,:,1));
        elseif  ii == 2
            Htime_taps_temp=squeeze(HL(:,:,:,t_sample_num-rem(t_sample_num+Tf-1,Tf)));
        elseif  ii==3
            Htime_taps_temp=Htime_predict(:,:,1:tapsN);
        end

        for ll=1:tapsN
            Henergy_taps_temp(ii,ll)=trace(Htime_taps_temp(:,:,ll)*Htime_taps_temp(:,:,ll)');
        end
        mimoChanCell2{uu,ii} = permute(Htime_taps_temp(:,:,1:tapsN),[3,1,2]);

    

    end
    mimoChanCell_predict{uu} = permute(Htime_predict(:,:,1:tapsN),[3,1,2]);

    figure
    bar(Henergy_taps_temp.');
    legend('without predict','ture channel','predicted channel');


    % chanSingularValue = zeros(subcarriersK,min(Rx,Tx));
    % [chanFreq] = getgenieChanFreq(SysPara,pulseOutput);
    % for ll = 1:subcarriersK
    %     [~,S,~]=svd(reshape(chanFreq(ll,:,:),Rx,Tx));
    %     chanSingularValue(ll,:) = diag(S);
    % end
    % genieChanFreq{uu} = chanFreq;
    % singularValueCell{uu} = chanSingularValue;

end

end

