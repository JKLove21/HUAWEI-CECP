function [gradT] = EuclideanGradTUEPrecod(T)
%UNTITLED 此处显示有关此函数的摘要
% Heffectkk = Hbarpk Vp = Tuu
global Nds subcarriersK SNR P Hdesired Qzf startPoint
F = dftmtx(subcarriersK);
gradT = zeros(size(T));
for uu = 1:P
    value = 0;
    Tuu = T((uu-1)*Nds+[1:Nds],:);
    Hdesireduu = Hdesired{uu};
    Qzfuu = Qzf{uu};
    for kk = 1:subcarriersK
        Fbar = kron(F(kk,startPoint),eye(Nds));
        Heffectkk = Fbar * Hdesireduu * Qzfuu;
        Mpk = SNR*eye(size(Tuu,2))+( Heffectkk * Tuu )'* Heffectkk * Tuu ;
        value = value - Heffectkk' * Heffectkk * Tuu / Mpk;
    end
    gradT((uu-1)*Nds+[1:Nds],:) = value;
end

end