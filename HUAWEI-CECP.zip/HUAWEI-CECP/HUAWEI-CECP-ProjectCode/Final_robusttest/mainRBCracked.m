clear all
clear global
%% Construct Parameters

[SysPara] = ConstructParameters;
Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio

RBCrackedPos = [1:192,400:591,1600:1791,1857:2048];
%% Test Part
SICapa = [];
FIRLenRange = length(ceil((tapsN-1)/(Tx/(P*Rx)-1))+1:10:ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 + 40); % Time domain FIR filter length range

MonteCarloNum = 1;
for testNum = 1:MonteCarloNum
    %% Global Seed
    rng(testNum);
%     [muMimoChanCell,~] = muMimoChan_interface(SysPara,chanTime); % Accept time domain channel (size == [subcarriersK Rx Tx P])
    [muMimoChanCell,~] = muMimoChan_gen(SysPara); % Generate NRCDL Channel
    counter = 0;
    for weightLen = 32:8:60
        counter = counter + 1;
        SysPara.weightLen = weightLen;
        %% Aggregated Block Toeplitz Channel Matrix T Generation
        [HtimeToep,Hfreq] = channelGen(SysPara);
%         [HtimeToep,Hfreq] = AggreTGen(muMimoChanCell,SysPara); % Generate T based on NRCDL Channel     
        %% RB Cracked Precoding
        [capacityEZF,capacityRBCracked,RBCrackedPrecoderTime] = RBCrackedPrecoding(SysPara,Hfreq,RBCrackedPos);
        SICapa = [SICapa, capacityRBCracked];
        MICapa(1,counter) = capacityRBCracked;
        clear Hdesired Qzf
    end
end
% plot([ceil((tapsN-1)/(Tx/(P*Rx)-1))+1:10:ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 + 40],SICapa);
% hold on;
plot(1:MaximumEquivalentChannelLen,MICapa(:,end));
hold on;
plot(1:MaximumEquivalentChannelLen,MICapa(:,end-1));
xlabel('Equivalent Channel Length')
ylabel('Channel Capacity bps/Hz')
title('Capacity v.s. Equivalent Channel Length')

plot(ceil((tapsN-1)/(Tx/(P*Rx)-1))+1:10:ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 + 40,MICapa(1,:));
hold on;
plot(ceil((tapsN-1)/(Tx/(P*Rx)-1))+1:10:ceil((tapsN-1)/(Tx/(P*Rx)-1))+1 + 40,MICapa(MaximumEquivalentChannelLen,:));
xlabel('Time-domain FIR Filter Length')
ylabel('Channel Capacity bps/Hz')
title('Capacity v.s. Time-domain FIR Filter Length')