function [timePrecoderW,MMSEIteration] = QNNManifoldOpt(SysPara,RecFreq,genieChanFreq,pilotout,noise,timePrecoderWInput,blockIndx)

Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
Nds = SysPara.Nds; % Data Streams per User
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)
subcarriersK = SysPara.subcarriersK; % Subcarriers Number
SNR = SysPara.SNR; % Signal to Noise Ratio
weightLen = SysPara.weightLen;
numRB = SysPara.numRB;
numSubCar = 12*numRB;
locFreq = [1:numSubCar/2,subcarriersK-numSubCar/2+1:subcarriersK];

global subcarriersK Tx Rx Nds P weightLen numSubCar genieChanFreq pilotout RecFreq noise


manifold = spherecomplexfactory(weightLen*Tx,P*Nds);
problem.M = manifold;
problem.cost  = @objFunQNN;
problem.egrad = @QNNEuclideanGrad;
problem.approxhess = approxhessianFD(problem);
% checkgradient(problem);
% [timePrecoderW,cost,info,options] = conjugategradient(problem,timePrecoderWInput,Operation);
% [timePrecoderW,cost,info,options] = rlbfgs(problem,timePrecoderWInput,Operation);
% [timePrecoderW,cost,info,options] = trustregions(problem, timePrecoderWInput, Operation);

if blockIndx <= 2
    Operation.maxiter = 1;
    Operation.tolgradnorm = 5;
    [timePrecoderW,cost,info,options] = conjugategradient(problem,timePrecoderWInput,Operation);
else
    Operation.maxiter = 1;
%     Operation.tolgradnorm = 0.9;
    [timePrecoderW,cost,info,options] = conjugategradient(problem,timePrecoderWInput,Operation);
end

MMSEIteration = [];
for ii = 1:length(info)
    MMSEIteration = [MMSEIteration,abs(info(ii).cost)];
end


end

