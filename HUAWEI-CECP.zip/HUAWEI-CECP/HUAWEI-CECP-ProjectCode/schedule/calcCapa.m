function [capacity] = calcCapa(chan,SysPara,chanType)
%%
P = SysPara.P;
Rx = SysPara.Rx;
SNR = SysPara.SNR;
[Dim,Tx,subcarriersK] = size(chan);
Dim = Dim/P;
eyeSize = min(Dim,Tx);
SingularValue = zeros(min(Rx,Tx),subcarriersK);
%%
capacity = 0;
if chanType == 'freq'
    for kk = 1:subcarriersK
        for uu = 1:P
            channeluukk = squeeze(chan((uu-1)*Dim + [1:Dim],:,kk));
            capacity = capacity + log2(det( eye(eyeSize) + 1/SNR*channeluukk*channeluukk' ));
        end
    end
elseif chanType == 'time'
    chanFreq = zeros();
end
capacity = real(capacity);
end