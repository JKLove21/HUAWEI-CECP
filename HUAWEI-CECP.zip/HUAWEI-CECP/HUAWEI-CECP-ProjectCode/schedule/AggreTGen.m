function [HtimeToep,Hfreq] = AggreTGen(muMimoChanCell,SysPara)

Tx = SysPara.Tx;  % Transmit Antennas
Rx = SysPara.Rx;  % Receive Antennas
P = SysPara.P;    % User Terminals
tapsN = SysPara.tapsN; % channel taps (Randomly Generated)



Htmp = zeros(Rx*P,Tx,tapsN);
for uu = 1:P
    TimeChanRes = muMimoChanCell{uu};
    for tt = 1:Tx
        for rr = 1:Rx
            Htmp((uu-1)*Rx + rr,tt,:) = squeeze(TimeChanRes(:,rr,tt));
        end
    end
end
   
[HtimeToep, Hfreq] = gen_channel_noise(Htmp,SysPara);
end

