function [R] = blockQR(T,M,P)
% Junkai Liu QR decomposition method for special complex block Toeplitz matrix

%% just for verification
R = chol(T'*T);

%% Algorithm 3 (I'm lazy, the code efficiency is not high. But, the code is right)
[row,col] = size(T);
Q = col/P;
L = row/M + 1 - Q;
tmp1 = T(:,1:P);
R11 = chol(tmp1'*tmp1);
T0 = T(M+1:end,P+1:end);
v = T(M+1:end,1:P);
zH = inv(R11')*v'*T0;

R1 = [zeros((Q-1)*P,(Q-1)*P)];
R2 = zeros((Q-1)*P,(Q-1)*P);
R2(1:P,:) = [R11,zH(:,1:end-P)];
for kk = 1:Q-1
    for pp = 1:P
        n = (kk-1)*P + pp;
 
        [H] = complexHouse(zH,P,n);
        zH = H*zH;
        tmpzH = zH(:,n:end);
        
        r11 = R2(n,n);
        sinthetaephi = tmpzH(1,1)/r11;
        phi = -angle(sinthetaephi);
        theta = asin(abs(sinthetaephi));
        Givens = [cos(theta),-sin(theta)*exp(1i*phi);sin(theta)*exp(-1i*phi),cos(theta)];
        NewGiven = Givens';
        tmp2 = zeros(1,((Q-1)*P - n +1));
        IDX = 1;
        [~,COL2] = size(R2(n,:));
        for idx = n:COL2      
            tmp2(IDX) = (R2(n,idx)-NewGiven(1,2)*tmpzH(1,IDX))/NewGiven(1,1);
            IDX = IDX + 1;
        end
        concatMatrix = [tmp2;tmpzH(1,:)];
        tmp3 = NewGiven*concatMatrix;
        zH(1,n:end) = tmp3(2,:);
        R1(n,n:end) = concatMatrix(1,:);
        if kk < Q-1
            R2(n+P,n+P:end) = R1(n,n:end-P);
        end
    end
end

Rfinal = [[R2(1:P,:),zeros(P,P)];[zeros((Q-1)*P,P),R1]];
end

